var j = jQuery.noConflict();

function quickJump() {
  var id = j("#idsString").val();
  id = id.replace(/^\s+|\s+$/g, ''); //trim
  var apps = j("input[type=hidden][name=applications]").val();
  if (apps === "objectId") {
    if (validateJumpId(id)) {
      var appServerRootUrl = j("#app_server_root_url").val() + "/sf/go/" + id;
      var jumpToIdActiveInQuickSearch = j("input[type=hidden][name=jumpToIdActiveInQuickSearch]").val();
      if (jumpToIdActiveInQuickSearch === "true") {
        appServerRootUrl = appServerRootUrl + "?qkSrchApp=objectId";
      }
      if (window.top != window.self) {
        parent.location.href = appServerRootUrl;
      } else {
        self.document.location = appServerRootUrl;
      }
    } else {
      j("#jumpToErrorDialog").modal('toggle');
    }
  } else if (id === "" || id === searchStr) {
    j("#searchKeywordsErrorDialog").modal('toggle');
  } else {
    var searchForm = j("#quickJumpForm");
    searchForm.attr("action", j("#app_server_root_url").val() + "/sf/search/do/search");
    searchForm.attr("onsubmit", "");
    j('<input>').attr({type: 'hidden', name:'qkSrchApp', value: apps}).appendTo(searchForm);
    j('<input>').attr({type: 'hidden', name:'term', value: id}).appendTo(searchForm);
    j('<input>').attr({type: 'hidden', name:'projects', value:''}).appendTo(searchForm);
    j('<input>').attr({type: 'hidden', name:'currentVersionsOnly', value:'true'}).appendTo(searchForm);
    searchForm.submit();
  }
  return false;
}

function validateJumpId(id) {
  // keep in sync with WikiTranslator.OBJECT_KEY_PATTERN
  // also split into two blocks, since one long ( | | ) or clause was causing issue for testing
  var iaRegExp = new RegExp("^(" + getIntegratedAppPrefixes() + ")_.+", "i");
  return id.match(/^(artf|cmmt|doc|frs|news|post|report|forum|pkg)\d{4,}$/i) ||
         id.match(/^(rel|docr|docf|topc|tracker|user|proj|plan|reps|wiki|page|srch|team)\d{4,}$/i) ||
         id.match(/^(artf)\d{4,}#\d+$/i) || 
         id.match(iaRegExp);
}

jQuery(document).ready(function() {
    var isIE7 = j.browser.msie && parseInt(j.browser.version) < 8;
    j("#idsString").focus(function(){
      var jumpValue = j(this).val();
      j(this).removeClass("jumpToFieldInactive");
      //only select the values if we are standing
      //on a valid object
      if (jumpValue === jumpDefaultExample || jumpValue === searchStr) {
        j(this).val("");
      } else {
        j("#idsString").select();  
      }
      return false;
    });
    
    j("#idsString").blur(function(){
      if (j(this).val() === "") {
        if (j("input[type=hidden][name=applications]").val() === "objectId") {
          j(this).val(jumpExample);
        } else {
          j(this).val(searchStr);
        }
        j(this).addClass("jumpToFieldInactive");
      }
      return false;
    });
    
    //this prevents text deselecting bug on chrome and 
    //weird behaviour in firefox (sometimes works, sometimes not)
    j("#idsString").mouseup(function(e){
        e.preventDefault();
    });

    // Change the 'jump to id' dropdown label with selected option text
    j("a[id=searchableApp]").click(function() {
      j("#jumpFieldLabel").text(j(this).children("span").text());
      var tfUrlBase = j("#app_server_root_url").val();
      var searchapp = j(this).attr("name");
      j("input[type=hidden][name=applications]").attr('value', searchapp);
      j("#searchableApp i").removeClass("icon-ok");
      // Prefix check mark for selected item
      j(this).find("i").addClass("icon-ok");

      var jumpValue = j("#idsString").val();
      if (jumpValue === jumpDefaultExample || jumpValue === searchStr) {
        j("#idsString").val(searchapp === "objectId" ? jumpExample : searchStr);
      }
    });

    j("#showPath").click(function() {
    	document.cookie='showPathDivFlag=true;path=/';
    	j("#parentProjectsPath").css('display', 'inline');
    	j("#showPath").hide();
    	if (isIE7) {
    		j("div:has(#parentPathBreadCrumb) > span").each(function () {
    			j(this).parent().width(j(this).width()); 
    		});
    	}
    });

    j("#hidePath").click(function() {
    	document.cookie='showPathDivFlag=false;path=/';
    	j("#showPath").css('display', 'inline');
    	j("#parentProjectsPath").hide();
    	if (isIE7) {
    		j("div:has(#parentPathBreadCrumb)").each(function () {
    			j(this).width(j(this).parent().width());
    		});
    	}
    });

    if (isIE7) {
    	if (showPathDiv != "undefined" && showPathDiv) {
    		j("div:has(#parentPathBreadCrumb) > span").each(function () {
    			j(this).parent().width(j(this).width());
    		});
    	} else {
    		j("div:has(#parentPathBreadCrumb)").each(function () {
    			j(this).width(j(this).parent().width());
    		});
    	}
    }
});

/**
 * Dropdown menu items of topnav links are broken in IAF pages.
 * Add scrollbar to those menus when user is in IAF pages.
 */
function addScrollbarToTopnavMenus() {
  var ctfDocHt = jQuery(document).height();
  j("#project-divider").css({"margin" : "0px"});
  j(".dropdown-menu").css({"padding" : "4px 0"});
  j(".dropdown-menu > li > a").css({"padding" : "2px 20px 1px"});
  j("#myprojects-submenu").addClass("iaf-topnav-dropdown-menu").css({"max-height" : ctfDocHt - 58});
  j("#recentlyviewed-submenu").addClass("iaf-topnav-dropdown-menu").css({"max-height" : ctfDocHt - 58});
  j("#recentlyedited-submenu").addClass("iaf-topnav-dropdown-menu").css({"max-height" : ctfDocHt - 84});
  j("#sitewide-links").addClass("iaf-topnav-dropdown-menu").css({"max-height" : ctfDocHt - 59});
  j("#quick-search-dropdown").addClass("iaf-topnav-dropdown-menu").css({"max-height" : ctfDocHt - 62});
}
