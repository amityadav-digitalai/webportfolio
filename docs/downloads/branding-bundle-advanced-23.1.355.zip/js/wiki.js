var storeCount = 0;
function storeCaret() {
  var textBoxEl = document.getElementById("PageSourceBox");
  if (textBoxEl.createTextRange) {
    var range = document.selection.createRange();
    textBoxEl.caretPos = range.duplicate();
  }
}

/**
       * This is a helper class for doing text formatting in a text area.
       */
function WikiIeHelper() {
  this.getSelection = function() {
    var textBoxEl = document.getElementById("PageSourceBox");
    return textBoxEl.caretPos;
  }

  this.isHighlight = function() {
    var sel = this.getSelection();
    return sel.text != null && sel.text.length > 0;
  }

  this.isCursorAfterNewLine = function() {
    var textBoxEl = document.getElementById("PageSourceBox");
    var sel = this.getSelection();

    // If we are at the start of the page, then we are effectively behind a newline.
    if (textBoxEl.value.indexOf(sel.text) == 0) {
	return true;
    }

    sel.moveStart("character", -1);
    var result = sel.text.length > 0 && sel.text.substring(0, 1) == "\n";
    sel.moveStart("character", 1);

    return result;
  }

  this.isCursorBeforeNewLine = function() {
    var textBoxEl = document.getElementById("PageSourceBox");
    var sel = this.getSelection();

    // If we are at the end of the page, then we are effectively in front of a newline.
    var boxValue = textBoxEl.value;
    if (boxValue.indexOf(sel.text) == (boxValue.length - sel.text.length)) {
        return true;
    }
    sel.moveEnd("character", 1);
    var result = sel.text.length > 0 && sel.text.substring(sel.text.length - 1) == "\n";
    sel.moveEnd("character", -1);

    return result;
  }

  this.insertTextAtCursor = function(text, cursorOffset) {
    var sel = this.getSelection();
    sel.text = text;
    sel.moveStart("character", 0 - cursorOffset);
    sel.moveEnd("character", 0 - cursorOffset);
    sel.select();
  }

  this.getSelectedText = function() {
    return this.getSelection().text;
  }
}

/**
 * This is a helper class for doing text formatting in a text area.
 */
function WikiNetscapeHelper(textBoxEl) {
  this.textBoxEl = textBoxEl;

  this.isHighlight = function() {
    return this.textBoxEl.selectionStart != this.textBoxEl.selectionEnd;
  }

  this.isCursorAfterNewLine = function() {
    return this.textBoxEl.value.substring(this.textBoxEl.selectionStart - 1, this.textBoxEl.selectionStart) == "\n"
  }

  this.isCursorBeforeNewLine = function() {
    var pos = this.textBoxEl.selectionEnd;
    return this.textBoxEl.value.substr(pos, pos + 1) == "\n";
  }

  this.insertTextAtCursor = function(text, cursorOffset) {
    var startString = this.textBoxEl.value.substring(0, this.textBoxEl.selectionStart);
    var endString = this.textBoxEl.value.substring(this.textBoxEl.selectionEnd);

    this.textBoxEl.value = startString + text + endString;
    this.textBoxEl.selectionEnd = startString.length + text.length - cursorOffset;
    this.textBoxEl.selectionStart = this.textBoxEl.selectionEnd;
  }

  this.getSelectedText = function() {
    return this.textBoxEl.value.substring(this.textBoxEl.selectionStart, this.textBoxEl.selectionEnd);
  }
}

/**
 * Set the initial height of the wiki text area.
 */
function setInitialWikiTextAreaHeight(height) {
  var heightSelectEl = document.getElementById("editBoxHeightSelect");
  for (var i = 0; i < heightSelectEl.options.length; i++) {
    if (height == heightSelectEl.options[i].value) {
      heightSelectEl.selectedIndex = i;
      wikiAdjustEditBoxHeight();
      return;
    }
  }
}

/**
	     * Adjust the height of the wiki page edit box.
	     */
function wikiAdjustEditBoxHeight(wikiEditorTextBoxId) {
  var selectBox = document.getElementById("editBoxHeightSelect");
  var newHeight = selectBox.options[selectBox.selectedIndex].value;

  var textBoxEl = document.getElementById(wikiEditorTextBoxId);
  textBoxEl.rows = newHeight;
}

var wiki_helper = null;

/**
       * Append the given wiki syntax to the buffer.  If no text is highlighted, the string is appended on the end.
       * If a region is highlighted, The element is wrapped in the given syntax.
       */
function wikiAppend(appendStart, appendEnd) {
  var textBoxEl = document.getElementById("PageSourceBox");
  if (textBoxEl.value == null) {
    textBoxEl.value = "";
  }

  if (wiki_helper == null) {
    if (document.selection != null) {
      wiki_helper = new WikiIeHelper(textBoxEl);
    } else {
      wiki_helper = new WikiNetscapeHelper(textBoxEl);
    }
  }

  var isHighlight = wiki_helper.isHighlight();
  var cursorOffset = 0;

  // See if we are tacking on something that requires its own line.
  if (appendEnd == null) {
    var isHorizontalRule = ("----" == appendStart);

    if (!wiki_helper.isCursorAfterNewLine()) {
      appendStart = "\n" + appendStart;
    }

    if (isHorizontalRule || (isHighlight && !wiki_helper.isCursorBeforeNewLine())) {
      appendEnd = "\n";
    } else {
      appendEnd = "";
    }
  } else if (!isHighlight) {
    cursorOffset = appendEnd.length;
  }

  // Insert the text
  var scrollHeight = textBoxEl.scrollTop;
  var selectedText = wiki_helper.getSelectedText();
  wiki_helper.insertTextAtCursor(appendStart + selectedText + appendEnd, cursorOffset);
  textBoxEl.scrollTop = scrollHeight;

  textBoxEl.focus();
}

