if (typeof CTF == "undefined" || !CTF) {
  var CTF = {};
}

var inconsistencyMessage = "Refresh your view to get the latest changes.";
var showMore = "Show more results...";
var contextualMenuHeight;

function setInconsistencyMessage(message) {
  inconsistencyMessage = message;
}

function setMoreResultMessage(message) {
  showMore = message;
}

function initCTF() {
  // Drag and drop handles for all the elements.
  CTF.DTDrags = {};
  // List of all the artifacts retrieved
  CTF.allArtifacts = {};
  // The cache of all the requests made
  CTF.childArtifactsCache = {};
  // Key: artifact that has children; Value: children artifacts
  CTF.dndArtifactsFamilies = {};
  // List of alien artifacts
  CTF.aliens = {};
  // Number of rows to render
  CTF.numRows = 0;
  // All the functions to rebuild all the move constraints
  CTF.moveConstraints = [];
  // The number of ajax calls in progress
  CTF.DNDAjaxCalls= 0;
  //global counter (for first level artifacts)
  CTF.counter=0;
  //number of pages currently displayed
  CTF.numberPages=0;
  //whether there are additional pages to display
  CTF.hasNextPage=false;
  //data for the tree
  CTF.baseTree = {};
  var jqBrowser = jQuery.browser;

  
  // some older browsers are slower when it comes to dom manipulation, so avoid certain display features for them
  CTF.domLiteOnly = jqBrowser.msie && (jqBrowser.version == "7.0" || jqBrowser.version == "6.0");

  CTF.beforeAndAfterCache = {};
}

function initialLoadURL() {
  return CTF.mode == "rank" ? "/sf/planning/do/viewPlanningFolderRankJSON/" : "/sf/planning/do/viewPlanningFolderSortedJSON/";
}

function childrenLoadURL() {
  return CTF.mode == "rank" ? "/sf/planning/do/listChildrenByRankJSON/" : "/sf/planning/do/listChildrenSortedJSON/";
}

function falseFunction() {
  return false;
}

function isDNDUnLocked() {
  return CTF.DNDAjaxCalls === 0;
}

//some of this vars will be used and updated if needed on 
//table_scroll.js for planning folder sort / rank mode
var ffTableHeaderPostionTop = 0;
var artifactTableScrollCurrentPosition = 0;
var isChildRender = false;

function renderArtifacts(data, insertAt, before, idPrefix, folderPath, display, nextPageNumber, cacheKey) {

  CTF.beforeAndAfterCache = {};
  var referenceCell = $j(insertAt);
  var rowNum;

  if (CTF.dndArtifactsFamilies[idPrefix] === undefined) {
    CTF.dndArtifactsFamilies[idPrefix] = [];
  }

  var counter = 0;
  var fistLevel = false;
  if (idPrefix == 'row_') {
    counter = CTF.counter;
    firstLevel = true;
  }
  var toExpand = [];
  for (rowNum in data.values) {
    var row = data.values[rowNum].row;
    var artifactId = data.values[rowNum].artifactId;
    var rowId = idPrefix + artifactId;
    var isAlien = data.values[rowNum].isAlien;
    CTF.allArtifacts[idPrefix + artifactId] = true;
    if (display) {
      CTF.dndArtifactsFamilies[idPrefix][counter] = idPrefix + artifactId;
      counter++;
      var domRow = document.createElement("tr");
      domRow.setAttribute("class", "sortHandle tbl-row treeview");
      // Workaround for IE6 and IE7
      domRow.setAttribute("className", "treeview");
      var cellNum;
      var domText;
      var numRows = 0;
      for (cellNum in row) {
        var cell = row[cellNum];
        var domCell = document.createElement("td");
        if (cell.type == "checkbox") {
          ++numRows;
          var fs = $j("<fieldset>");
          var lg = $j("<legend>");
          lg.attr("class", "legend-overwrite");
          var ck = $j("<input>").attr("name", cell.name).attr("type", "checkbox");
          if (cell.onclick !== undefined) {
            ck.click(new Function("eval(\"" + cell.onclick + "\")"));
          }
          ck.attr("value", cell.value);
          if (cell.headers !== undefined) {
            domCell.setAttribute("headers", cell.headers);
          }
          if (cell.title !== undefined) {
            ck.attr("title", cell.title);
          }
          if (cell.classCkName !== undefined) {
            ck.attr("class", cell.classCkName);
            ck.attr("className", cell.classCkName); // for older IE
          }
          if (cell.id !== undefined) {
            ck.attr("id", cell.id);
          }
          var lb = $j("<label>").attr("for", cell.id).attr("class", "custom-label").attr("name", "labelFor_listItem");
          var sp = $j("<span>").attr("class", "sr-only").text("emptyLabel");
          lg.appendTo(fs);
          ck.appendTo(lg);
          lb.appendTo(lg);
          sp.appendTo(lb);
          fs.appendTo(domCell);
        } else if (cell.type == "text") {
          ++numRows;
          if (cell.columnName == 'description') {
            domText = document.createTextNode(cell.value.replace( /(<([^>]+)>)/g, ''));
          } else {
            domText = document.createTextNode(cell.value);
          }
          if (cell.align !== undefined) {
            domCell.setAttribute("align", cell.align);
          }
          if (cell.className !== undefined) {
              domCell.setAttribute("class", cell.className);
              domCell.setAttribute("className", cell.className); // for older IE
          }
          if (cell.headers !== undefined) {
            domCell.setAttribute("headers", cell.headers);
          }
          if (cell.link !== undefined) {
            var domA = document.createElement("a");
            domA.appendChild(domText);
            domA.setAttribute("href", cell.link);
            domA.setAttribute("target", "_self");
            domCell.appendChild(domA);
          } else {
            domCell.appendChild(domText);
          }
        } else if (cell.type == "image") {
          ++numRows;
          var domImage = document.createElement("img");
          if (cell.src !== undefined) {
            domImage.setAttribute("src", cell.src);
          }
          if (cell.border !== undefined) {
            domImage.setAttribute("border", cell.border);
          }
          if (cell.idName !== undefined) {
            domImage.setAttribute("id", cell.idName);
          }
          if (cell.title !== undefined) {
            domImage.setAttribute("title", cell.title);
            domImage.setAttribute("alt", cell.alt);
          }
          if (cell.headers !== undefined) {
            domCell.setAttribute("headers", cell.headers);
          }
          domCell.appendChild(domImage);
        } else if (cell.type == "html") {
          ++numRows;
          if (cell.className !== undefined) {
            domCell.setAttribute("class", cell.className);
            domCell.setAttribute("className", cell.className); // for older IE
          }
          if (cell.headers !== undefined) {
            domCell.setAttribute("headers", cell.headers);
          }
          domCell.innerHTML = cell.value;
        } else {
          ++numRows;
          domText = document.createTextNode(cell.value);
          domCell.appendChild(domText);
        }
        
        
        if (typeof allowedToEditColumnFields == 'function') {
	      //inline edit, add the edit class for editable columns
	        if(allowedToEditColumnFields(cell.headers)){
	        	
	        	$j(domCell).addClass("edit");
	        	
	        	if (isNumericField(cell.headers)) {
	        		$j(domCell).addClass("numeric");
	        	}
	        }
        
        }
        
        domRow.appendChild(domCell);
      }
      CTF.numRows = numRows;
      domRow.setAttribute("id", rowId);
      if (before) {
        referenceCell.before(domRow);
      } else {
        referenceCell.after(domRow);
        referenceCell = $j("#" + rowId);
      }
      //Close the contextual menu if the artifact loses the hovered state. 
      $j(domRow).hover(function(){
             // 
      }, function(){
            $j("li.contextual-menu").removeClass("open"); 
      });
      domA = null;
      domCell = null;
      domImage = null;
      domRow = null
      domText = null;
    }
    if (isNodeExpanded(rowId, folderPath)) {
      toExpand.push({
        artifactId : artifactId,
        rowId : rowId.substring(4)
      });
    }
  }
  
  var inExpansion;
  for (inExpansion in toExpand) {
    expandNodeTreeView(folderPath, toExpand[inExpansion].artifactId,
        toExpand[inExpansion].rowId, display);
  }
  if (display) {
    rebuildConstraints();
    if (!CTF.domLiteOnly) {
      $j("#ArtifactListTable tr.treeview:odd").removeClass("EvenRow").addClass("OddRow");
      $j("#ArtifactListTable tr.treeview:even").removeClass("OddRow").addClass("EvenRow");
    }
    if (dndEnabled) {
      // remove our "wait" cursor and revert all the rows back to a draggable "move"
      $j("#ArtifactListTable").removeClass("dndWait").addClass("dndEnabled");
    }
    if (firstLevel) {
      CTF.counter = counter;
    }
  }

  if (display && firstLevel && nextPageNumber >= 2) {
    var key = '';
    if (!dndEnabled) {
      key = cacheKey;
    }
    //insert a row showing that there are more items
    $j("#treeFooter").before("<tr id='moreMsg'><td class='showMoreResults' colspan='" + CTF.numRows + "'><a  href=\"\" OnClick=\"javascript:getNextItems(" + nextPageNumber + ",'" + key + "','" + folderPath + "');return false;\">" + showMore + "</a></td></tr>");

  }
  if (display && nextPageNumber == -1 && data.limitMsg != undefined && data.limitMsg != '') {
    //Show msg limit reached cannot be shown
     $j("#treeFooter").before("<tr id='footerMsg'><td colspan='" + CTF.numRows + "'>"+ data.limitMsg +"</td></tr>");
  }

  if (display && firstLevel) {
	  if ($j("#editMode") != undefined && CTF.mode.indexOf("sort") == 0 && toExpand.length == 0) {
		  setButtonState("_SfButton_inLineEditModeButton", "enabled");
	  }
  }
  
}

function getNextItems(nextPageNumber, cacheKey, folderPath) {
  $j("#moreMsg").remove();
  $j("#treeFooter").before("<tr id='loadId'><td colspan='" + CTF.numRows + "'><img align='middle' src='/sf-images/masthead/loadingIndicator.gif' alt='loading'/></td></tr>");
  loadPage(folderPath, cacheKey, nextPageNumber);
}

/**
 * Rebuild the d&d constraints for all the rows.
 */
function rebuildConstraints() {
  var r;
  for (r in CTF.moveConstraints) {
    CTF.moveConstraints[r]();
  }
  r = null;
}

/**
* Artifacts being processed for drag and drop contains the whole hierarchy of ids eg, ParentID_ChildID_GrandChildId....
* The actual artifactID being dropped is present at the end, for certain tasks we need the last one only. For such cases
* truncate the hierarchy and provide actual artifactId.
*/
function getLastArtifactId (artifactIdWithHierarchy) {
  return artifactIdWithHierarchy.indexOf("_") != -1 ? 
    artifactIdWithHierarchy.substring(artifactIdWithHierarchy.lastIndexOf("_") + 1) : artifactIdWithHierarchy;
}

// Initialize drag and drop logic
function initJqDND() {
    var jquery = jQuery.noConflict();

    jquery(document).ready(function() {

        var fixHelperModified = function(event, ui) {
            var $children = ui.children();
            var $childrenClone = ui.clone();

            $childrenClone.children().each(function(index) {
                jquery(this).width($children.eq(index).width())
            });

            return $childrenClone;
        };

        var startHelper = function(event, ui) {
            ui.item.data('start_pos', ui.item.index());
        };

        var stopHelper = function(event, ui) {
            var start_pos = ui.item.data('start_pos');
            var pattern = new RegExp("^artf(\\d){4,}$");

            if (ui.item.index() -1 != -1 && start_pos != ui.item.index()) {
                jquery("#ArtifactListTableData tbody tr").each(function() {
                    var $tr = jquery(this);
                    $tr.removeClass('Dropped');
                });

                ui.item.addClass("Dropped");

                var srcId = ui.item.attr("id").substring(4);
                var previousArtifact = ui.item[0].previousElementSibling.id.substring(4);
                var nextArtifact = ui.item[0].nextElementSibling.id.substring(4);

                srcId = getLastArtifactId(srcId);
                previousArtifact = getLastArtifactId(previousArtifact);
                nextArtifact = getLastArtifactId(nextArtifact);

                if (!previousArtifact.match(pattern)) {
                    previousArtifact = null;
                }

                if (!nextArtifact.match(pattern)) {
                    nextArtifact = null;
                }
                var handlerURL = "/sf/planning/do/rankArtifactJSON/"
                              + globalFolderPath
                              + "?fromUrlKey="
                              + fromUrlKey
                              + "&r="
                              + Math.floor(Math.random() * 10000);

                var message = {
                    "previous" : previousArtifact,
                    "actual" : srcId,
                    "next" : nextArtifact
                };

                jquery.getJSON(handlerURL, message, function(data) {
                    if (data.action === undefined) {
                        // We had an issue.
                        alert(inconsistencyMessage);
                    } else if (data.action == "render" || data.action == "refresh") {
                    } else {
                        // Handle error and other cases.
                        alert(data.message);
                    }
                });
            } else {
                jquery(this).sortable('cancel');
            }
        };

        jquery("#ArtifactListTableData tbody").sortable({
            helper: fixHelperModified,
            start: startHelper,
            stop: stopHelper
        }).disableSelection();

        jquery("#ArtifactListTableData tbody tr").not('.sortHandle').mousedown(function(event){
            event.stopImmediatePropagation();
        });

    });
}


function loadPage(folderPath, cacheKey, pageNumber) {
  CTF.DNDAjaxCalls++;
  // first we get a json response for the output of the expanded rows
  var handlerURL;
  //In case of list artifacts from team
  if (folderPath.indexOf("teamId") !== -1) {
   handlerURL = "/sf/teams/do/viewTeamSortedJSON/" + folderPath + "&fromUrlKey=" + fromUrlKey  + "&r=" + Math.floor(Math.random() * 10000);
  } else {
   handlerURL = initialLoadURL() + folderPath
      + "?fromUrlKey=" + fromUrlKey + "&r="
      + Math.floor(Math.random() * 10000);
  }
  if (cacheKey !== undefined) {
    handlerURL += "&treeDataListKey=" + cacheKey;
  }

  if (pageNumber != null && pageNumber > 0) {
    handlerURL += "&_pagenum=" + pageNumber;
  }


  jQuery(document).ajaxError(function(event, request, settings) {
	
	 // if we are on in line edit mode, skip this
	if (fieldNameIds != null){
		return;
	}

    alert(inconsistencyMessage);
  });

  $j.getJSON(handlerURL, function(data) { 
    if (data.action === undefined) {
      // We had an issue.
      alert(inconsistencyMessage);
    } else if (data.action == "render") {
      //TODO: would be good to find another way to do that since pageNumber is in the closure
      CTF.baseTree[pageNumber] = data;

      if (pageNumber == null || pageNumber == '' || pageNumber <=1) {
        // Delete all the rows that have a class = "treeview"
        $j(".treeview").remove();
      } else {
        //delete only the loading gif
        $j("#loadId").remove();
      }

      CTF.numberPages = data.pageNumber;
      CTF.hasNextPage = data.hasNextPage;
      if (data.treeDataListKey != null &&  data.treeDataListKey != '') {
        cacheKey =  data.treeDataListKey;
      }
      var nextPageNumber = -1;
      if (CTF.hasNextPage) {
        nextPageNumber = CTF.numberPages + 1;
      }
      renderArtifacts(data, "#treeFooter", true, "row_", folderPath, false, nextPageNumber, cacheKey);
      renderArtifacts(data, "#treeFooter", true, "row_", folderPath, true, nextPageNumber, cacheKey);

      if(typeof setFloatingComponentsData == 'function') {
    	  //this call is for the planning folder view
    	  if(typeof setInLineEditor == 'function') {
    		  setInLineEditor(null);
    	  }
    	  setFloatingComponentsData(true);
    	  doTheHeaderRender();
    	  setInterval("checkWidthAndHeight()" , 100);

      }
    } else {
      alert(inconsistencyMessage);
    }
    CTF.DNDAjaxCalls--;
  });
}

// Loads the rank tree and displays it in the table
function loadInitialRankTree(folderPath, cacheKey) {
  CTF.mode = "rank";
  initCTF();
  initJqDND();
  loadPage(folderPath, cacheKey, 1);
}

//Loads the rank tree and displays it in the table
function loadInitialSortedTree(folderPath, cacheKey) {
  CTF.mode = "sort";
  initCTF();
  loadPage(folderPath, cacheKey, 1);
}


function expandNodeTreeView(folderPath, artfId, rowId, display) {
  if (display === undefined) {
    display = true;
  }
  if (display) {
    var imgId = "img_" + rowId;
    var image = document.getElementById(imgId);
    if (image == null) {
    	removeNodeFromCookie("row_" + rowId, folderPath);
    } else {
    	
	    image.onclick = function() {
	      collapseNodeTreeView(folderPath, artfId, rowId);
	    };
	    // Change the image
	    image.src = image.src.replace("plus", "minus");
    }

    if (CTF.childArtifactsCache[rowId] !== undefined) {
    	isChildRender = true;
      renderArtifacts(CTF.childArtifactsCache[rowId], "#row_" + rowId,
          false, "row_" + rowId + "_", folderPath, display, -1, null);
      inlineEditChildArtifactRefresh(artfId);
      //Hiding contextual menu while inline mode is enabled
    if(typeof editMode !== "undefined" && editMode){
       hideContextualMenu();
    }
      updateOnResize(true);
      return;
    }

    addNodeToCookie("row_" + rowId, folderPath);
  }
  CTF.DNDAjaxCalls++;

  // Check if we already have this artifact in the page
  var handlerURL = childrenLoadURL() + folderPath
      + "?fromUrlKey=" + fromUrlKey + "&rowId=" + rowId + "&artfId="
      + artfId + "&r=" + Math.floor(Math.random() * 10000);

  $j.ajax( {
    url : handlerURL,
    dataType : 'json',
    success : function(data) {
      if (data.action === undefined) {
        // We had an issue.
        alert(inconsistencyMessage);
      } else if (data.action == "render") {
        CTF.childArtifactsCache[rowId] = data;
        isChildRender = true;
        renderArtifacts(data, "#row_" + rowId, false, "row_" + rowId + "_", folderPath, display, null);
        isChildRender = false;
        inlineEditChildArtifactRefresh(artfId);
      } else {
        // Handle error and other cases.
        alert(inconsistencyMessage);
      }
      CTF.DNDAjaxCalls--;
    },
    async : false
  });
//Hiding contextual menu while inline mode is enabled
   if(typeof editMode !== "undefined" && editMode){
	hideContextualMenu();
   }
  updateOnResize(true);
  
}

function inlineEditChildArtifactRefresh(artfId) {
	if(typeof handleChildArtifactOnPlanningFolder == 'function') {
    		  handleChildArtifactOnPlanningFolder(artfId);
    }
} 

/**
 * Hide the contextual menu
 */
function hideContextualMenu(){
    $j("li.contextual-menu").attr("style", "visibility: hidden");
}

/**
 * if user wants to collapse a child and it has changed let him know and decide
 * wheter to keep it expanded or losing the changes.
 * @param artfId
 * */
function userReallyWantsToCollapseRow(artfId) {
	var defaultResponse = true;
	
	if(typeof handleChildArtifactOnPlanningFolder == 'function') {
    		  if (editMode) {
    			  
    			  if (artifactHasEditedChildrens(artfId)) {
    				  
    				  var userResponse = window.confirm(COLLAPSE_CHILD_ALERT);
    				  
    				  if (userResponse) {
    					  removeArtifactsThatWereEditedAndAreBeingCollapsed(artfId);
    				  }
    				  
    				  return userResponse;
    			  }
    		  }
    }
	return defaultResponse;
} 

function collapseNodeTreeView(folderPath, artfId, rowId) {
  
  //only for inline edit, alert user before collapsing the node	
  if (!userReallyWantsToCollapseRow(artfId)) {
	  return;
  }
  
  var imgId = "img_" + rowId;
  var image = document.getElementById(imgId);
  image.onclick = function() {
    expandNodeTreeView(folderPath, artfId, rowId, undefined);
  };
  image.src = image.src.replace("minus", "plus");
  // Remove the children
  var artifactId;
  var toRemove = {};
  for (artifactId in CTF.allArtifacts) {
    if (artifactId.indexOf("row_" + rowId + "_") == 0) {
      $j("#" + artifactId).remove();
      toRemove[artifactId] = true;
    }
  }
  removeNodeFromCookie("row_" + rowId, folderPath);
  delete CTF.dndArtifactsFamilies["row_" + rowId + "_"];
  for (artifactId in toRemove) {
    delete CTF.allArtifacts[artifactId];
  }
  if (!CTF.domLiteOnly) {
    $j("#ArtifactListTable tr.treeview:odd").removeClass("EvenRow").addClass("OddRow");
    $j("#ArtifactListTable tr.treeview:even").removeClass("OddRow").addClass("EvenRow");
  }
  updateOnResize(true);
}

var expandedNodes = {};
var expandedNodesInited = false;

function addNodeToCookie(id, folderPath) {
  if (!expandedNodesInited) {
    initExpandedNodes(folderPath);
  }
  expandedNodes[id] = true;
  storeCookie(expandedNodes, folderPath);
}

function removeNodeFromCookie(id, folderPath) {
  if (!expandedNodesInited) {
    initExpandedNodes(folderPath);
  }
  var node;
  for (node in expandedNodes) {
    if (node.indexOf(id) == 0) {
      delete expandedNodes[node];
    }
  }
  storeCookie(expandedNodes, folderPath);
}

function isNodeExpanded(id, folderPath) {
  if (!expandedNodesInited) {
    initExpandedNodes(folderPath);
  }
  return expandedNodes[id];
}

function initExpandedNodes(folderPath) {
  expandedNodesInited = true;
  var cookieValues = readCookie(folderPath);
  if (cookieValues === null) {
    return;
  }
  var nodes = cookieValues.split("&");
  var node;
  for (node in nodes) {
    expandedNodes[nodes[node]] = true;
  }
}

function storeCookie(nodes, folderPath) {
  var expirationDate = new Date();
  expirationDate.setDate(expirationDate.getDate() + 1);
  var cookieValue = [];
  var node;
  for (node in nodes) {
    cookieValue.push(node);
  }
  document.cookie = folderPath + "=" + cookieValue.join("&") + ";expires="
      + expirationDate.toGMTString() + ";path=/sf";
}

function readCookie(name) {
  var nameEQ = name + "=";
  var ca = document.cookie.split(';');
  for ( var i = 0; i < ca.length; i++) {
  var c = ca[i];
  while (c.charAt(0) === ' ') {
    c = c.substring(1, c.length);
  }
  if (c.indexOf(nameEQ) == 0)
    return c.substring(nameEQ.length, c.length);
  }
  return null;
}

function removeParentArtifact(artifactPath, parentArtifactId, returnUrl, submitUrl) {
    var removeForm = document.getElementById('removeParent');
    removeForm.action = "/sf/tracker"+ artifactPath;
    removeForm._listItem.value=parentArtifactId;
    removeForm.followLink.value=returnUrl;
    removeForm._submitterURL.value=submitUrl;
    removeForm.sfsubmit.value="remove";
    removeForm.submit();
}

// Add click event to the contextual menu icon and handle the  collision detection.
function openMenuAboveOrBelow(artifactId) {       
    if (contextualMenuHeight == undefined) {
        contextualMenuHeight = $j("li.contextual-menu ul").height();
    }
    var iconEl = $j("#icon-for-" + artifactId);
    var windowHeight = $j(window).height();
    var artfTop = $j(iconEl).offset().top;
    if ((artfTop + contextualMenuHeight + 40) > (windowHeight + $j(window).scrollTop())) {
        $j(iconEl).parents("li.contextual-menu").addClass("dropup");
    } else {
        $j(iconEl).parents("li.contextual-menu").removeClass("dropup");
    }   
}
