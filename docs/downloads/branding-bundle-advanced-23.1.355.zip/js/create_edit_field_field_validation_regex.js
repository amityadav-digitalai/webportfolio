// Global variables used by the field validation sources
var _REGEX_PATTERN = $j('input[name="pattern"]').text();
var _TEST_STRING = $j('textarea[name="testString"]').text();
var _REQUEST_SENT = false;

// There are three variables set in the including file:
//   1. REGEX_EMPTY_MATCH
//   2. REGEX_NO_MATCH
//   3. REGEX_NO_PATTERN

// The jQuery way to run something when the document is ready
$j(function(){
  // Bind a change handler to the useFieldValidation checkbox to toggle
  // the visibility of the pattern validation form.
  // note 'change' event isn't thrown in IE8 until after the elements has lost focused. so use 'propertychange' instead
  var isIE8 = $j.browser.msie && $j.browser.version.indexOf("8") == 0? true : false;
  $j('input[name="useFieldValidation"]').bind(isIE8? 'propertychange' : 'change', function() {
    $j('#FieldValidationTable').toggle();
  });

  // Bind change/keyup handlers to the field validation pattern input and the field
  // validation test string input so that any changes to them will invoke the
  // code below.
  $j('input[name="pattern"],textarea[name="testString"]').bind('change keyup', $j.debounce(250, function() {
    var regexPattern_obj = $j('input[name="pattern"]');
    var regexPattern = regexPattern_obj.val();
    var testString_obj = $j('textarea[name="testString"]');
    var testString = testString_obj.val();

    // If both values are unchanged, return as there is nothing to do
    if (_REGEX_PATTERN == regexPattern && _TEST_STRING == testString) {
      return;
    }

    // Persist the new values
    _REGEX_PATTERN = regexPattern;
    _TEST_STRING = testString;

    // If the regex is empty, display the greeting
    if (regexPattern == null || regexPattern == "") {
      $j('#FieldValidationResults').text(REGEX_NO_PATTERN);
      $j('#FieldValidationResults').css('font-style', 'italic');
      return;
    }

    // If there is a current request in place do not resend a new request just yet
    if (_REQUEST_SENT) {
      return;
    }

    // Use AJAX to make a request to /sf/tracker/do/regexTester
    $j.ajax({
      url: '/sf/tracker/do/regexTester',
      data: regexPattern_obj.serialize() + "&" + testString_obj.serialize(),
      dataType: 'json',
      beforeSend: function(xhr) {
        _REQUEST_SENT = true;
      },
      error: function(xhr, text, err) {
        // Handle the error by putting something into the right panel
        $j('#FieldValidationResults').text('There was an error contacting the server (' + xhr.status + '): ' + xhr.statusText + '.');
        $j('#FieldValidationResults').css('font-style', 'italic');
      },
      success: function(data) {
        var html = "";

        // Handle the success and update the right panel
        if (data.error != undefined) {
          html = data.error;
        } else if (data.match == null) {
          html = REGEX_NO_MATCHES;
        } else if (data.match.length == 0) {
          html = REGEX_EMPTY_MATCH;
        } else {
          var testString = $j('textarea[name="testString"]').val();
          var match = data.match;

          // The code below takes the string returned from the RegexTesterAction and surrounds it with a span tag.
          // To avoid some rendering issues, we use the jQuery .text().html() approach to encode most HTML/XHTML
          // entities and finally, we manually replace spaces with the &nbsp;.
          var matchesHtml = testString.replace(match, '<span class="FieldValidationMatch">' + $j('<div/>').text(match).html().replace(new RegExp('\\s', 'g'), '&nbsp;') + '</span>');

          // The code below replaces the newline character with a line break HTML
          // tag to allow for multi-line test strings and matches.
          html = matchesHtml.replace(new RegExp('\\n', 'g'), '<br />');
        }

        $j('#FieldValidationResults').html(html);

        var fieldValidationResultsText = $j('#FieldValidationResults').text();

        if (fieldValidationResultsText == REGEX_NO_MATCHES || fieldValidationResultsText == REGEX_EMPTY_MATCH || fieldValidationResultsText == REGEX_NO_PATTERN) {
          $j('#FieldValidationResults').css('font-style', 'italic');
        } else {
          $j('#FieldValidationResults').css('font-style', 'normal');
        }
      },
      complete: function(xhr, text) {
        _REQUEST_SENT = false;
      }
    });
  }));
});
