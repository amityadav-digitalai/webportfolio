/* functions for initializing tinyMCE - start */

tinyMCE.init({
  language : getLanguage(),
  mode : "exact",
  theme : "advanced",
  browsers : "msie,gecko,opera,safari",
  plugins : "table,advimage,advlink,iespell,inlinepopups,insertdatetime,print,paste,directionality,noneditable,contextmenu",
  theme_advanced_buttons1 : "bold,italic,underline,strikethrough,justifyleft,justifycenter,justifyright,justifyfull,fontsizeselect,removeformat,separator,forecolor,backcolor,separator,bullist,numlist,outdent,indent,separator,visualaid,separator,help,code",
  theme_advanced_buttons2 : "tablecontrols,separator,undo,redo,link,unlink,image,anchor,separator",
  theme_advanced_buttons3 : "",
  theme_advanced_toolbar_location : "top",
  theme_advanced_toolbar_align : "left",
  theme_advanced_statusbar_location : "bottom",
  plugin_insertdate_dateFormat : "%Y-%m-%d",
  plugin_insertdate_timeFormat : "%H:%M:%S",
  file_browser_callback : "fileBrowserCallBack",
  accessibility_warnings : false,
  paste_use_dialog : false,
  custom_links : "",
  theme_advanced_resizing : true,
  theme_advanced_resize_horizontal : true,
  table_styles : "axial=axial;grid=grid",
  table_row_styles : "a=a;b=b",
  content_css : "/css/saturn_specific.css?_=20240322120535",
  apply_source_formatting : true,
  relative_urls : true,
  document_base_url : "$container.getBaseURL()",
  convert_urls : false,
  valid_elements : "*[*]"
});

function getLanguage() {
  //  Obtain language preference and parse it
  // for tineMCE specific types

  var navLang = requestLocale;
  var lan = "en";
  if(navLang.match("en") != null) {
      lan = "en";
  } else if (navLang.match("ja") != null) {
      lan ="ja";
  } else if (navLang.match("ko") != null) {
      lan = "ko";
  } else if (navLang.match("zh") != null ) {
      lan = "zh";
  }
  return lan;
}
function fileBrowserCallBack(field_name, url, type, win) {
  var fileBrowserWindow = new Array();

  var cmsURL = document.getElementById('attachmentIdString').value;
  if (cmsURL.indexOf("?") < 0) {
      //add the type as the only query parameter
      cmsURL = cmsURL + "?type=" + type;
  }
  else {
      //add the type as an additional query parameter
      cmsURL = cmsURL + "&type=" + type;
  }

tinyMCE.activeEditor.windowManager.open({
      file : cmsURL,
      width : 485,
      height : 130,
      resizable : "yes",
      inline : "yes",  // This parameter only has an effect if you use the inlinepopups plugin!
      close_previous : "no"
  }, {
      window : win,
      input : field_name
  });

return false;
}
/* functions for initializing tinyMCE - end */
function changePageEditor(selectedOption, editorId) {
  if (selectedOption == "plain" && tinyMCE.getInstanceById(editorId)) {
    tinyMCE.execCommand('mceFocus', false, editorId);
    tinyMCE.execCommand('mceRemoveControl', false, editorId);
  } else {
    tinyMCE.execCommand('mceAddControl', false, editorId);
  }
}

function checkContentRequired(fieldId, errorMsg) {
  var content;
  var selectedOption =  document.getElementById("editorPrefSelect").value;
  if (selectedOption == "plain") {
      content =   document.getElementById(fieldId).value;
  } else {
      content = tinyMCE.get(fieldId).getContent(); // get the content
  }
  if(content == "") {
    alert(errorMsg);
    return false;
  }
  return true;
}

