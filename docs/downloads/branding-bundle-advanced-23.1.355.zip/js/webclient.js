/*@COPYRIGHT
*TeamForgeForge(r) Enterprise Edition
*Copyright 2013 CollabNet, Inc. All rights reserved.
*http://www.collab.net
*COPYRIGHT@
*/

/**
 * Fixes for broken JQuery functions
 */

(function($j) {
   if ($j['ui']) {
      var sortable = $j['ui']['sortable'];

      /**
       * Intersection tests with containers fail badly when the containers 'overlap' due to
       * the presence of scrollbars. Sortable uses only the position of the sortable elements
       * to identify the appropriate drop target, causing the target to jump from container
       * to container.
       * This fixes that by doing an intersection test with the container before doing the
       * nearest neighbor search.
       * 
       * 
       * Whenever dragging an artifact card in the sortable list, 
       * We need to do a Collapse If the Dragged card has Child's in it.
       * as the childContainer of artifact card is positioned relatively, 
       * the collapse has no effect as the relative position object keeps it's initial placement.
       * 
       * Fix
       * Added a custom event 'customBeforeStart' that will get invoked BEFORE the actual drag process starts (i.e. before the START event is fired).
       * Whenever dragging an element the 'customBeforeStart' will get triggered so that We can perform the hide of 'childContainer' thus
       * makes the only visual parent artifact being dragged is the collapsed DIV.

       */
      $j.extend(sortable.prototype, {
               _oldIntersectsWithPointer: sortable.prototype._intersectsWithPointer,
               _intersectsWithPointer: function(item) {
                  if (this._intersectsWith(item.instance.containerCache)) {
                     return this._oldIntersectsWithPointer(item);
                  }

                  return false;
               },
               _oldMouseStart: sortable.prototype._mouseStart,
               _mouseStart: function(event, overrideHandle, noActivation) {
                   this._trigger("customBeforeStart", event, this._uiHash());
                   return this._oldMouseStart.apply(this, [event, overrideHandle, noActivation]);
               }
            });
   }
})(jQuery);

/**
 * Function that will render Bootstrap style modal window
 * with give options.
 */

(function($j){  
    $j.fn.bootstrap_dialog = function(options,messages) {
        var title, content, save, cancel, remove, hide_close, ok;
        var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };
     
        if(typeof options == "string"){
          switch(options){
            case "close":
              $j(this).data("current_dialog").hide();
              $j("#modal_background").hide();
              $j("#modal").hide();
              break;
            case "destroy":
              $j(this).data("current_dialog").remove();
              $j("#modal_background").remove();
              $j("#modal").remove();
              break;
          }
          return $j(this);
        }
        if(options) {
          title=options.title;
          content=options.content;
          hide_close=options.hide_close;
          if(options.save)
            save=__bind(options.save,this);
          if(options.cancel)
            cancel=__bind(options.cancel,this);
          if(options.remove)
            remove=__bind(options.remove,this);
          if(options.ok)
              ok=__bind(options.ok,this);
        }
        else {
          title="";
        }
        if($j("#modal_background").length==0){
          $j("body").append("<div class='modal-backdrop fade in' id='modal_background'>");
          $j("#modal_background").show();
        }
        $j("#modal_background").show();
        current_dialog=$j("<div class='modal hide fade in form-popup-window' tabindex='-1' role='dialog' aria-hidden='true'></div>").appendTo("body").attr("style","display: block;");
        
        $j('body').on('keydown', function (keyDownEvent) {
          if (keyDownEvent.which === 27) {
            current_dialog.remove();
            $j("#modal_background").hide();
          }
        });

        if (options.modalSize =="small"){
        	current_dialog.addClass("modal-small");
    	} else{
    		current_dialog.addClass("modal-large");
    	}		
        
        $j(this).data("current_dialog",current_dialog);
        if(options.hide_close) {
          $j("<div class='modal-header'/>").appendTo(current_dialog).append("<h3>"+title+"</h3");
        } else {
            $j("<div class='modal-header'/>").appendTo(current_dialog).append("<a href='#' class='close'  aria-hidden='true' data-dismiss='modal'><span style='display:none;'>.</span></a>").append("<h3>"+title+"</h3");
        }
        if(options.content) {
          $j("<div class='modal-body popup-middle-section'>").appendTo(current_dialog).append(options.content);
        } else {
          $j("<div class='modal-body popup-middle-section'>").appendTo(current_dialog).append($j(this));
        }    
        if(save || cancel || remove || ok) {
          var footer = $j("<div class='modal-footer'>").appendTo(current_dialog);
          var alignRight = $j("<div class='AlignRight'>").appendTo(footer);
          if(ok) {
              $j("<div class='ButtonSpace'></div>").appendTo(alignRight);
              $j("<div class='Button'><div class='Middle'><a href='#'>"+messages['button.ok']+"</a></div></div>").appendTo(alignRight).click(function(e){ e.preventDefault(); ok();});
          }
          if(cancel) {   
              $j("<div class='Button'><div class='Middle'><a href='#'>"+messages['button.cancel']+"</a></div></div>").appendTo(alignRight).click(function(e){ e.preventDefault(); cancel();});
          }
          if(save) {
              $j("<div class='ButtonSpace'></div>").appendTo(alignRight);
              if(options.action=="create"){
            	  $j("<div class='Button'><div class='Middle'><a href='#'>"+messages['button.submit']+"</a></div></div>").appendTo(alignRight).click(function(e){ e.preventDefault(); save();}); 
              }else{
            	  $j("<div class='Button'><div class='Middle'><a href='#'>"+messages['button.update']+"</a></div></div>").appendTo(alignRight).click(function(e){ e.preventDefault(); save();});
          	}
          }          
          if(remove) {
              $j("<div class='ButtonSpace'></div>").appendTo(alignRight);
              $j("<div class='Button'><div class='Middle'><a href='#' class='btn btn-danger'>"+messages['button.delete']+"</a></div></div>").appendTo(alignRight).click(function(e){ e.preventDefault(); remove();});
          }
          
        }
        $j(current_dialog.find(".modal-header a.close")).click(function(){
          current_dialog.remove();
          $j("#modal_background").hide();
        });
        return $j(this);
      };
 })(jQuery);

/**
 * Modules
 **/

WebClient = new WebClientHandler();

/**
 * Contains general utility/convenience methods, and javascript for components common to most pages.
 */

function WebClientHandler() {
  
   this.onStop = null;     

   var me = this;

   /**
    * Make a copy of an object.
    *
    * @param map map or object to copy
    */
   this.clone = function(map) {
      return $j.extend({}, map);
   };

   /**
    * Return the current page (minus parameters).
    *
    * Used for generating URLs, and for tests.
    */
   this.getPagePath = function() {
      return document.location.pathname;
   };

   /**
    * Convert all end-of-line characters in text to HTML break characters.
    *
    * Useful for formatted text as in descriptions or comments.
    * @param text input
    * @returns doctored text
    */
   this.breakLines = function(text) {
      return text.replace(/\r?\n|\r/g,'<br/>');
   };

   /**
    * Rounds a number to a given number of digits.
    * @param number the number to round
    * @param toDigits the number of digits to keep
    * @returns {Number} the rounded number
    */
   this.round = function(number, toDigits) {
      if (number === null || number === undefined) {
         return null;
      }

      var multiplier = Math.pow(10, toDigits);
      return Math.round(number * multiplier) / multiplier;
   };

   var escapedCharacters = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&#034;',
      "'": '&#039;',
      '/': '&#047;'
   };

   /**
    * Replaces characters in string for rendering.
    *
    * @param input text to clean
    */
   this.replaceHTML = function(input) {
      if (input == undefined) {
         return input;
      }

      function replace(val) {
         return escapedCharacters[val];
      }

      return input.replace(/[&<>"'\/]/g, replace);
   };

   /**
    * Creates a copy of the input where the string fields
    * of the input objects are sanitized for displaying and adding to html snippets.
    *
    * @param input text to clean
    */
   this.sanitizeStringFields = function(input) {
      var result = {};

      for (property in input) {
        result[property] = (typeof(input[property]) === 'string')
          ? this.replaceHTML(input[property])
          : input[property];
      }
      return result;
   };

   /**
    * Perform an action when the page has finished loading.
    */
   this.onPageDone = function(callback) {
      var called = false;

      var done = function() {
                     $j(document).ready(function() {
                        if (!me.ajaxPending) {
                           if (!called) {
                              called = true;
                              callback();
                           }
                        }
                     });
                  };

      this.onStop = done;

      done();
   };



   /**
    * Arrange for the component to fill the page and stay that way (resize() events are handled)
    *
    * @param selector the selector for the areas that can be scrolled
    * @param padding optional - extra space at the bottom (eg, for scrollbars)
    * @param fill optional - make the last child fill the remaining space (defaults to false)
    */
   this.fitElementToWindow = function(selector, padding, fill) {
      var min = $j(selector).css('min-height');
      var originalMinHeight = min ? parseInt(min) : undefined;

      var resize = this.getResizeFunction(selector, originalMinHeight, padding, fill);

      this.onResize(resize);

      return resize;
   };

   /**
    * Function to fill available space.
    *
    * Grow the last child of the give jQuery object(s) to fill the space available.
    * Mostly useful for drop targets in drag and drop.
    *
    */
   this.getGrowFunction = function() {
      var minHeight = undefined;
      var chromeMarginError = 6; // The top margin on the first item sticks out of the parent, throwing off height?

      return function(containers, availableY) {
         var targets = [];
         var height = [];

         containers.each(function(index, element) {
            var parent = $j(element);
            var child = parent.find('.ui-sortable').first();
            if (child.length > 0) {
               if (minHeight === undefined) {
                  minHeight = parseInt(child.css('min-height'));
               }

               var parentTop = parent.offset().top;
               var childTop = child.offset().top;
               var top = childTop - parentTop;
               var childHeight = availableY - top - chromeMarginError;

               targets.push(child);
               height.push(Math.max(childHeight, minHeight));
            }
         });

         for (var i = 0, length = targets.length; i < length; i++) {
            targets[i].css('min-height', height[i]);
         }
      }
   };

   /**
    * Returns the function used to resize elements to window.
    * @param selector the selector for the element to resize
    * @param originalMinHeight the original minimum height of the element
    * @param padding optional - any padding to add at the bottom (eg, for scrollbar)
    * @param fill optional - make the last child fill the remaining space (defaults to false)
    * @returns {function} to resize the selectors element
    */
   this.getResizeFunction = function(selector, originalMinHeight, padding, fill) {
      if (padding === undefined) {
         padding = 0;
      }

      var fillFunction = fill ? this.getGrowFunction() : function() {};

      return function() {
         var targets = me.getAsJquery(selector);

         if (targets.length > 0) {
            var elementPadding = me.getElementPadding(targets);
            var availableY = $j(window).height() - elementPadding.y - padding;

            var footerHeight = me.getAsJquery('.footer').outerHeight(true);
            var heightMinusFooter = availableY - footerHeight;
            var min = Math.max(originalMinHeight, heightMinusFooter);

            fillFunction(targets, availableY);

            targets.css('min-height', min);
            me.forceHeight(targets, availableY);
         }
      };
   };

   /**
    * Execute the given function on window Resize events.
    *
    * @param resize the target function
    * @param invokeNow make a resize action happen now (defaults to true)
    */

   this.onResize = function(resize, invokeNow) {
      var timeout;

      $j(window).resize(function() {
                          if (timeout !== undefined)
                             clearTimeout(timeout);

                          timeout = setTimeout(resize, 100); // limit fast repaints on window drag
                       });

      if (invokeNow != false) {
         $j(window).resize();
      }
   };

   /**
    * Returns a jQuery Deferred object.
    */
   this.getDeferred = function() {
      return jQuery.Deferred();
   };

   /**
    * Returns a deferred object for a group of Deferred objects.
    *
    * Used for performing an action after all of a set of Deferreds have finished.
    * Also useful for unit tests.
    *
    * @param deferreds an array of deferred values
    */
   this.after = function(deferreds) {
      var deferred = this.getDeferred();
      var count = deferreds.length;

      var decrement = function() {
         if (--count == 0) {
            deferred.resolveWith();
         }
      };

      for (var i = 0, length = deferreds.length; i < length; i++) {
         if (deferreds[i]) {
            deferreds[i].then(decrement, decrement);
         } else {
            decrement();
         }
      }

      return deferred.promise();
   };

   /**
    * Returns a JS Interval id
    * @param callback
    * @param period
    */
   this.setInterval = function(callback, period) {
      return setInterval(callback, period);
   };


   /**
    * Wrapper for JSON calls to do some extra work.
    * Cache Validation:
    * Some browsers, notably IE, do not properly honor the cache hints on XHR requests, always returning the original
    * answer.  Use this method to avoid that problem.
    *
    * Error handler:
    * Allows an optional 3rd parameter for dealing with error cases on JSON calls.
    * @param url
    * @param success Function to call in case of success.
    * @param failure Function to call in case of failure, or message name to display
    * @param showMessage if true then no need to clear the existing message
    */
   this.getJSON = function(url, success, failure, showMessage) {
      var settings = {  type: 'GET',
                        dataType: 'json',
                        cache: false,
                        url: url,
                        context: document.body
                     };
      if(!showMessage) {
    	  settings.beforeSend = me.beforeSendHandler();
      }
      return this.ajax(settings).done(success).
         fail(this.createJSONFailureCallback(failure));
   };

   /**
    * Wrapper for JSON POST calls to do some extra work.
    *
    * Error handler:
    * Allows an optional 4th parameter for dealing with error cases on JSON calls.
    * @param url post destination
    * @param data JSON object to send to the server
    * @param success Function to call in case of success.
    * @param failure Function to call in case of failure, or message to display
    */
   this.postJSON = function(url, data, success, failure) {
      var settings = {  type: 'POST',
                        url: url,
                        contentType: 'application/json; charset=utf-8',
                        context: document.body,
                        beforeSend: me.beforeSendHandler()
                     };

      if (data) {
         settings.data = JSON.stringify(data);
      }

      return this.ajax(settings).done(success).fail(this.createJSONFailureCallback(failure));
   };

   /**
   * Returns the function that handles any pre processing before invoking ajax request
   * @returns the function that handles any pre processing on beforeSend
   */
   this.beforeSendHandler = function() {
      return function () {
          // Removes existing notifaction messages
          $j(this).find('#messagesDiv').empty();
      }
   };

   /**
    * Wrapper for JSON calls for Unit testing
    *
    * @param settings Ajax settings object (see jQuery.ajax())
    */
   this.ajax = function(settings) {
      return $j.ajax(settings);
   };
   
   /**
    * Wrapper for jQuery GET calls for Unit testing.
    *
    * @param url the URL to load
    */
   this.get = function(url) {
      var settings = {  type: 'GET',
                        cache: false,
                        url: url
                     };

      return this.ajax(settings);
   };

   /**
    * Wrapper for the jQuery load function to handle error checking.
    *
    * Make .load look somewhat like .ajax() or .get()
    * The distinction is that load() populates the given container, using some complex regexp patterns in the process.
    * When mocking, be sure to account for this (ie, call html() or append() with the mock)
    *
    * @param container the container to load the data into
    * @param href the URL to load.  Supports load() formatting (with selector appended)
    * @return Deferred for the results
    */
   this.load = function(container, href) {
      var deferred = this.getDeferred();

      var handler = this.getLoadHandler(deferred);

      container.load(href, handler);

      return deferred.promise();
   };

   /**
    * Returns the handler function for the load() function.
    * @param container {jQuery} the container to load the data into
    * @param deferredRequest the deferred request
    * @return {Function} the handler function for the response.
    */
   this.getLoadHandler = function(container, deferredRequest) {
      return function(responseText, textStatus, xhr) {
         if (me.isErrorStatus(textStatus)) {
            deferredRequest.rejectWith(container, [xhr]);
         } else {
            deferredRequest.resolveWith(responseText);
         }
      };
   };

   /**
    * Returns true if the status is one of the jQuery error statuses.
    *
    * @param textStatus a jQuery textStatus
    * @return <code>true</code> if the status represents an error type
    */
   this.isErrorStatus = function(textStatus) {
      return textStatus == "timeout" || textStatus == "error" || textStatus == "parsererror";
   };

   /**
    * Create a failure handler for AJAX requests.
    *
    * Overloaded function.  When the argument is:
    *  1) a function - the function will be called.
    *  2) a string - The error dialog will show the localized Message for that string.
    *
    *  Otherwise, The error dialog will display, with the default error message.
    *
    * @param failure takes a failure behavior (see above)
    */
   this.createJSONFailureCallback = function(failure) {
      if ($j.isFunction(failure) || $j.isArray(failure)) {
         return failure;
      } else {
         return function(error, var2, var3) {
            me.showErrorForRequest(error, failure);
         };
      }
   };


   /**
    * Change the text data in an element.
    *
    * @param parent containing the target element(s)
    * @param elementSelector selector pattern to find the target element(s)
    * @param text new text to display, or null to do nothing (empty string wipes field)
    * @param title alt text to display (optional)
    * @returns modified element(s)
    */
   this.setElementText = function(parent, elementSelector, text, title) {
      var editElement = parent.find(elementSelector);

      if (text != null) {
         editElement.empty().append(encodeHtmlAttribute(text));
      }

      if (title != null) {
         editElement.attr('title', title);
      }

      return editElement;
   };

   /**
    * Change the selection state of a checkbox
    *
    * @param parent containing jQuery DOM element
    * @param elementSelector selector pattern to find the target element
    * @param checked boolean status - checked or not checked
    * @returns modified element
    */
   this.setCheckbox = function(parent, elementSelector, checked) {
      var editElement = parent.find(elementSelector);
      if (checked) {
         editElement.prop('checked', true);
      } else {
         editElement.removeAttr('checked');
      }

      return editElement;
   };

   /**
    * Check all check boxes for the given parent.
    *
    * @param parent selector pattern for parent containing the check boxes.
    * @return all the items that were previously unchecked.
    */
   this.checkAll = function(parent) {
      var unchecked = this.getAsJquery(parent).find('input[type=checkbox]').not(':checked');
      return unchecked.prop('checked', true);
   };

   /**
    * Uncheck all check boxes for the given parent.
    *
    * @param parent selector pattern for parent containing the check boxes.
    * @return all the items that were previously checked.
    */
   this.uncheckAll = function(parent) {
      var checked = this.getAsJquery(parent).find('input[type=checkbox]:checked');
      return checked.removeAttr('checked');
   };
   
   /**
    * Fills a field with the specified data.
    *
    * @param fieldID the ID of the field to fill
    * @param data the data to put into the field
    * @param finder {function} to provide the jquery object from the field ID
    * @return the DOM element that was updated
    */
   this.addDataToField = function(fieldID, data, finder) {
      var newField = finder(fieldID);
      newField.val(data);

      return newField;
   };
   
   /**
    * Fills a field with the specified attribute data.
    *
    * @param fieldID the ID of the field to fill
    * @param data the data to put into the attribute of the field
    * @param attrName the attribute name
    * @param finder {function} to provide the jquery object from the field ID
    * @return the DOM element that was updated
    */
   this.addAttributeToField = function(fieldID, attrName, data, finder) {
      var newField = finder(fieldID);
      newField.attr(attrName, data);

      return newField;
   };

   /**
    * Sets the inner HTML for an element.
    *
    * @param elementID the ID of the element to add inner HTML to.
    * @param html the HTML to be set for the element
    * @param finder {function} to provide the jquery object from the element ID
    * @return the DOM element that was updated
    */
   this.addHtmlToElement = function(elementID, html, finder) {
      var element = finder(elementID);
      element.html(html);

      return element;
   };

   /**
    * Fills in a select with the passed in options.
    *
    * @param selectID the ID of the select
    * @param options the options to populate
    * @param selectedOption the option which should be selected
    * @param finder finds the select element by the selectID
    * @return the DOM element that was updated
    */
   this.addDataToSelect = function(selectID, options, selectedOption, finder) {
      var select = finder(selectID);

      for (var i = 0; i < options.length; i++) {
         var optionText = options[i];
         var optionElement = $j('<option/>');
         optionElement.text(optionText);
         optionElement.val(optionText);
         select.append(optionElement);
      }

      select.val(selectedOption);

      return select;
   };
   
   /**
    * Fills in a select with the passed in options.
    *
    * @param selectID the ID of the select
    * @param options the options to populate with Text and Value.
    * @param selectedOption the option which should be selected.
    * @param finder finds the select element by the selectID
    * @return the DOM element that was updated
    */
   this.addDataToSelectWithOptionValue = function(selectID, options, selectedOption, finder) {
      var select = finder(selectID);

      for (var i = 0; i < options.length; i++) {
         var option = options[i];         
         var optionElement = $j('<option/>');
         optionElement.text(option.text);
         optionElement.val(option.value);
         select.append(optionElement);
      }      
      select.val(selectedOption);
      return select;
   };
   
   
   
   /**
    * Fills in a select with the passed in options.
    * Entries the existing options and replaces with new options.
    * Also triggers a change event to make sure multiple hierarchy's are handled. 
    * i.e., Grand Parent -> Parent -> Child., Changing the GrandParent value in turn Changes
    * it's Grant Child's Value as it's Child Value is getting changed which is the Parent.
    *
    * @param selectID the ID of the select
    * @param options the options to populate with Text and Value.
    * @param selectedOption the option which should be selected.
    * @param finder finds the select element by the selectID
    * @return the DOM element that was updated
    */
   this.changeDataToSelectWithOptionValue = function(selectID, options, selectedOption, finder) {
      var select = finder(selectID);
      select.empty();
      select.prop('disabled', false);
      for (var i = 0; i < options.length; i++) {
         var option = options[i];
         if (option.visible === true) {
           var optionElement = $j('<option/>');
           optionElement.text(option.name);
           optionElement.val(option.id);
           select.append(optionElement);
         }
      }
      select.val(selectedOption.id).change();
      return select;
   };
   
   /**
    * Fills the select with default option value.
    * and makes the field disabled.
    * 
    * @param selectID the ID of the select
    * @param defaultOption the option which should be selected.        
    * @param finder finds the select element by the selectID 
    * @param isDisabled true if disabled.
    * @param triggerChangeEvent fires the change event.
    * @return the DOM element that was updated
    */
   this.addDefaultOptionToSelect = function(selectID, defaultOption, finder, isDisabled, triggerChangeEvent) {
       var select = finder(selectID);   
       select.empty();
       var optionElement = $j('<option/>');
       optionElement.text(defaultOption);
       optionElement.val('');
       select.append(optionElement);       
       select.prop('disabled', isDisabled);
       if (triggerChangeEvent) {
           select.val(optionElement).change(); 
       } else {
           select.val(optionElement);
       }
       return select;
    };

    /**
     * Sets the nobody user data for validation
     */
    this.setNobodyUser = function(nobodyUser) {
        me.nobodyUser = nobodyUser;
    }

   /**
    * Returns the selected value from the drop down options.
    *
    * @param dropDownOptions the options for the drop down.
    * @param selectedText the selected text in the drop down.
    * @returns the value corresponding to the selected text.
    */
   this.getValueForSelectedText = function(dropDownOptions, selectedText) {
       var selectedValue = '';
       $j.each(dropDownOptions, function (index, option) {
          if (option.text === selectedText) {
              selectedValue = option.value;
          }
       });

       return selectedValue;
   }

   /**
    * Retrieve an ID from the given DOM element, removing the prefix.
    * Example:  'foo_1234' => '1234'
    *
    * @param element the DIV representing the task on the taskboard
    * @returns the id attribute suffix, after the first underscore
    */
   this.findIDFromElement = function(element) {
      var elementID;

      if (element) {
         var attribute = element.attr('id');
         if (attribute) {
            elementID = attribute.split('_')[1];
         }
      }

      return elementID;
   };

   /**
    * Set up form fields to automatically submit their parent forms on change() events.
    * Looks for input fields with the 'auto-submit' class and wires up the associated forms.
    *
    * @param container optional top level component (as jQuery object) to wire.  defaults to 'body'
    */
   this.enableAutoSubmitForms = function(container) {
      if (!container) {
         container = $j('body');
      }

      container.delegate('.auto-submit', 'change',
                        function() {
                           $j(this).closest('form').submit();
                        });
   };

   /**
    * Adds the original values to the form fields as data.
    * Only records data for input and select fields.
    * 
    * @param form {jQuery} the form to remember fields for
    */
   this.rememberFormFields = function(form) {
      var formFields = form.find('input, select');
      formFields.each(function(index, value){
         var field = $j(value);
         field.data('originalValue', field.val());
      });
   };
   
   /**
    * Determines if the form fields have changed from their original values.
    * Only records data for input and select fields.
    * 
    * @param container {jQuery} the container to search
    */
   this.inputFieldsHaveChanged = function(container) {
      var formFields = container.find('input, select');
      var hasChanged = false;
      
      formFields.each(function(index, value){
         var field = $j(value);
         if (field.data('originalValue') != field.val()) {
            hasChanged = true;
         }
      });
      return hasChanged;
   };
   
   /**
    * Given a form element, locate its label.
    *
    * @param element the jquery element to get the label of
    */
   this.findLabelFor = function(element) {
      var form = element.parents('form');
      var elementId = element.attr('id');

      var label = form.find('label[for="' + elementId + '"]');
      return label;
   };

   /**
    * Attach an error indication to a form field.
    *
    * @param field form field to associate error to.
    * @message the error message to display.
    */
   this.markError = function(field, message) {
       
        var errorText = field.closest('.settings-column-row').next('.error-label');
        var error = me.getErrorWidget(message);
        if (field.parents().hasClass('settings-column-row')) {
            field.parents('.settings-column-row').css('padding-bottom', '0px');
            if (errorText.length == 0) {
                field.parents('.settings-column-row').after(error);
            } else {
                errorText.find('.errorMsg').text(message);
            }       
        } else {
            if (errorText.length == 0) {
                field.after(error);
            } else {
                errorText.find('.errorMsg').text(message);
            }
        }          
        field.focus();
   };
   
   /**
    * Hightlights the Accordion widget of parent element.
    * 
    * @param element the element to find error.
    */
   this.highLightAccordionWidget = function(parent) {       
       var accordionWidget = parent.find('.ui-accordion');          
       var childrens = accordionWidget.children('.ui-accordion-content');
       
       childrens.each(function(accordionIndex, widget) {           
          if ($j(widget).find('.error-label').length > 0) {                            
              accordionWidget.accordion('option', 'active', accordionIndex);
              $j(widget).find('.error-label:first').prev().find('.inputfield').focus();
              return false;
          }
       });     
   }
   
   /**
    * Attach an error indication to a form field.
    *
    * @param form form fields to un-annotate.  Looks for all associated labels.
    */
   this.clearErrors = function(editor) {
       editor.find('.error-label').remove();       
       editor.find('.settings-column-row').removeAttr('style'); 
   };

   /**
    * Sets the input hints on an input field
    *   
    * @param input the input field (does not have to be an 'input' element)
    * @param hint the hint to display when the content of the input field is empty.
    * @param finder the finder function to search for fields
    */
   this.setInputHints = function(input, hint, finder) {

      var hintSpan = this.getAsJquery('<span class="hint">' + hint + '</span>');
      hintSpan.hide();

      var inputField = finder(input);

      var showHint = function() {
         if (inputField.val().length == 0) {
            hintSpan.show();
         }
      };

      var hideHintWhenFieldFocused = function() {
         hintSpan.hide();
      };

      inputField.blur(showHint).focus(hideHintWhenFieldFocused);

      var hideHintWhenHintClicked = function() {
         hideHintWhenFieldFocused();
         inputField.focus();
      };
      hintSpan.click(hideHintWhenHintClicked);

      inputField.before(hintSpan);
      showHint();
   };

   /**
    * Displays a modal dialog containing the error message and title.
    *
    * @param message the message to display (String or String[])
    * @param title the title of the dialog to display
    * @param onClose function to run when the alert is dismissed
    */
   this.alert = function(message, title, onClose) {
       var data = [];
       data.push('<div id="projectBoardErrorDialog" class="modal hide fade" tabindex="-1" role="dialog" aria-hidden="true">');
       data.push('<div class="modal-body">');
       data.push('<div class="errorMessage">', message, '<a class="close" data-dismiss="modal" aria-hidden="true">&nbsp;</a></div>');
       data.push('</div>');
       data.push('</div>');
       var div = this.getAsJquery(data.join(''));

       var close = function() {
           div.unbind('hidden');
           div.remove();
           if (onClose) {
               onClose();
           }
       };

       div.bind('hidden', close);
       div.modal('toggle');
   };

   /**
    * Displays a modal dialog containing the loading image and message.
    *
    * @param message the message to display
    */
   this.displayProgress = function(message) {
       var data = [];
       data.push('<div class="artlifact-editor-loading-progress">');
       data.push(message);
       data.push('</div>');

       return data.join('');
   };

   /**
    * Shows a modal dialog.
    * @param {html} div the div to show as a dialog.
    * @param {[{button}]} buttons the array of buttons to show
    * @param {function} onClose the functionality to perform on dialog close
    */
   this.showDialog = function(div, buttons, onClose, customizations) {
      
      var configuration = {
            resizable: false,
            modal: true,
            buttons: buttons,
            width: 300,
            open: function() {
               $j('.yes-button').blur();
               $j(buttons[0]).blur();
               $j('.cancel-button, .no-button').focus();
            },
            close: function() {
               if (onClose) {
                  onClose();
               }
               div.dialog('destroy').remove();
            }
         };
      
      $j.extend(configuration, customizations);

      var dialog = div.dialog(configuration);
      this.fixDialog(dialog);
   };

   
   /**
    * Builds the HTML for a confirmation box.
    * 
    * @param title the title of the window
    * @param message the message in the window
    * @returns {jQuery} object that can display as a dialog.
    */
   this.getConfirmHTML = function(title, message) {
      var data = [];
      data.push('<div id="dialog-confirm" class="confirmation-dialog" title="', title, '">');

      data.push('<p>');

      if ($j.isArray(message)) {
         data.push(message.join('</p><p>'));
      } else {
         data.push(message);
      }

      data.push('</p>');
      data.push('</div>');

      return this.getAsJquery(data.join('')); 
   };
   

   /**
    * Displays a busy message.
    *
    * @param message the message to display while loading
    * @param title the title for the dialog
    * @param ajax the ajax call this dialog is displayed for. Optional.
    *    If specified, the dialog is closed automatically once the call finished.
    * @returns {Function} a function which closes the dialog.
    */
   this.busy = function(message, title, ajax) {
      var image = this.baseURL + '/sf-images/masthead/loadingIndicator.gif';
      var data = [
         '<div id="dialog-loading" title="', title, '">',
            '<div class="loading-content">',
               '<img class="loading-image" alt="Loading" src="', image, '"/>',
               message,
            '</div>',
         '</div>'
         ];

      var div = this.getAsJquery(data.join(''));

      var dialog = div.dialog({
         resizable: false,
         modal: false,
         width: 200
         });

      this.fixDialog(dialog);

      var closeFunction = function() {
                             dialog.dialog('destroy').remove();
                          };

      if (ajax && ajax.then) {
         ajax.then(closeFunction, closeFunction);
      }

      return closeFunction;
   };

   /**
    * Show a full screen, modal popup.
    *
    * @param {jQuery} content object to display in the overlay
    */
   this.showOverlay = function(content) {
      var configuration = {
                              draggable: false,
                              zIndex: 10000,
                              position: 'center',
                              width: 'auto',
                              dialogClass: 'overlay drop-shadow'
                          };

      this.showDialog(content, [], null, configuration);
   };

   /**
    * Returns the passed in html or selector wrapped in delicious jquery goodness.
    * 
    * @param contentOrSelector the text html to wrap or the selector to find
    * @param context the context for the element (optional)
    * @returns the html wrapped in jquery
    */
   this.getAsJquery = function(contentOrSelector, context) {
      return $j(contentOrSelector, context);
   };

   /**
    * Deal with display bugs in jquery dialogs.
    *
    * @param dialog
    */
   this.fixDialog = function(dialog) {
      if ($j.browser.msie && $j.browser.version <= 7 ) {
         var widget = dialog.dialog('widget');
         var contentPane = widget.find('.ui-dialog-content');
         dialog.dialog('option', 'width', contentPane.outerWidth());
         dialog.dialog('option', 'position', 'center');
         widget.find('.ui-dialog-titlebar-close').hide().show();
      }
   };

   /**
    * Show the dialog box associated with the given edit pane Element.
    *
    * @param editPane
    */
   this.dialogTakeFocus = function(editPane) {
      if (editPane.dialog('isOpen')) {
         editPane.dialog('moveToTop');
         if (editPane.offset().top > $j(window).height()) {
            editPane.dialog('option', 'position', 'center');
         }
      }
   };

   /**
    * Force the component to take the given height.  Try twice if necessary.
    * Useful especially for IE, which lies consistently (but differently by version).
    *
    * @param element sample jQuery element to perform the calculation upon
    * @param newHeight the height to set
    */
   this.forceHeight = function(element, newHeight) {
      if (isNaN(this.correction)) {
         var actualHeight = element.height(newHeight).height();
         this.correction = newHeight - actualHeight;
      }

      element.height(newHeight + this.correction);
   };

   /**
    * Calculate the area between the outside of the element and the body.
    *
    * Useful for space-filling algorithms.
    *
    * @param element the target element to calculate upon
    */

   this.getElementPadding = function(element) {
      return {
         x: element.outerWidth(true) - element.width(),
         y: element.outerHeight(true) - element.height()
      };
   };

   /**
    * Return a map containing the top, bottom, left and right offset coordinates of the DOM element.
    * Useful for calculating overlap of components.
    *
    * @param element
    * @param offset or null.  Uses element.offset() if not set
    * @returns a map { top, bottom, left, right }
    */

   this.getExtents = function(element, offset) {
      if (!offset) {
         offset = element.offset();
      }

      return {top: offset.top,
         bottom: offset.top + element.height(),
         left: offset.left,
         right: offset.left + element.width()};
   };

   /**
    * Determine if two rectangles overlap.
    *
    * @param extents1 rectangle 1
    * @param extents2 rectangle 2
    * @see getExtents()
    * @returns true if the two extents overlap (or touch), false otherwise
    */
   this.areOverlapping = function(extents1, extents2) {
      var leftRightOverlap = extents1.left <= extents2.right && extents1.right >= extents2.left;
      var topBottomOverlap = extents1.top <= extents2.bottom && extents1.bottom >= extents2.top;

      return leftRightOverlap && topBottomOverlap;
   };

   /**
    * Handle the tab bar configuration.
    * Used to highlight the tab for the currently loaded page.
    * @param currentProductKey
    */
   this.setupTabs = function(currentProductKey) {
      var currentPathName = document.location.pathname;

      $j('#tab-bar .links>li>a').each(function(i, element) {
             var href = element.href;

             if (href.indexOf(currentPathName) > -1) {
              $j(element).addClass("active-tab");
             }
      });
   };
   

   /**
    * Adds the open and close event listeners to a selector.
    * 
    * Show or hide the selector if:
    * 1) the user clicks on the header for the selector
    * 2) If the user clicks outside of the selector (click-away)
    *
    * @param rootElement {jQuery} the root element of the selector
    * @param pickerSelector {String} the selector expression to find the selector's "picker" element
    * @param headerSelector {String} the selector expression to find the selector's header
    * @param onClose optional method to call on closing the selector
    * @return the selector's toggle function.
    */
   this.addSelectorListener = function(rootElement, pickerSelector, headerSelector, onClose) {
      var open = false;
      var timeout = null;

      var doClose = function() {};

      if (onClose) {
         doClose = function() {
            timeout = window.setTimeout(function() {
                                          onClose();
                                          return true;
                                       }, 1);
         };

         $j(window).bind('beforeunload', function(eventObject) {
                                          if (timeout) {
                                             window.clearTimeout(timeout);
                                          }
                                        });
      }

      var toggleSelector = function() {
         open = !open;
         rootElement.find(pickerSelector).toggle();
         rootElement.find('> ' + headerSelector).toggleClass('drop-shadow');

         if (!open) {
            doClose();
         }
      };

      var onClick = function(eventObject) {
         var targetElement = eventObject.target;

         if ($j(targetElement).closest(headerSelector).length != 0) {
            toggleSelector();
         }

         return true;
      };

      var clickAway = function(eventObject) {
         var targetElement = eventObject.target;

         if (open && !jQuery.contains(rootElement[0], targetElement)) {
            toggleSelector();
         }

         return true;
      };

      rootElement.delegate(headerSelector, 'click', onClick);
      $j('body').delegate('*', 'click', clickAway);
      
      return toggleSelector;
   };
   
  
   /**
    * Provides the standard UI element for displaying a validation error.
    * @param message the error message to display.
    * 
    * @returns {String} HTML of the widget
    */
   this.getErrorWidget = function(message) {
      return '<div class="error-label">' + message + '</div>';
   };
   
   this.getInfoMessage =function(message) {
	   return '<div class="workflowInfo instruction-header"><span class="infoIcon"/><span class="infoMsg">' + message + '</span></div>';
   }
   
   /**
    * Provides the standard UI element for indicating required field.
    * 
    * @returns {String} HTML for widget
    */
   this.getRequiredField = function() {
       return '<span class="required">*</span>';
   }

   /**
    * Disables the specified buttons of an editor.
    *
    * @param {jQuery} editor the editor
    * @param buttonSelector the selector expression to find the button(s)
    * @returns the buttons which were disabled.
    */
   this.disableEditorButton = function(editor, buttonSelector) {
      var buttons = editor.parent().find(buttonSelector);
      buttons.button('disable');
      return buttons;
   };

   /**
    * Disables the enabled buttons of an editor.
    *
    * @param {jQuery} editor the editor
    * @returns the buttons which were disabled.
    */
   this.disableEnabledEditorButtons = function(editor) {
      return this.disableEditorButton(editor, '.ui-button:not(.ui-button-disabled)').
         removeClass('ui-state-hover');
   };

   /**
    * Returns the attribute to be used to make the input element disabled
    * @param field {jQuery} the input element
    * @return the name of the attribute to use
    */
   this.getDisabledAttributeForInput = function(field) {
      return (field.is("textarea") || field.is('input[type!=checkbox]'))  ? 'readonly' : 'disabled';
   };
   
   /**
    * Scrolls the target container
    * 
    * @param sortable event event to handle
    * @param ui sortable ui element
    * @param widgetHeight the height of the draggable widgets
    * @param scrollContainerSelector Unique selector of scroll container
    */
   this.scroll = function(event, ui, widgetHeight, scrollContainerSelector) {
       var scrollSpeed = 60;
       var scrollSensitivity = widgetHeight / 2;
       var scrollContainer = ($j(ui.placeholder).closest(scrollContainerSelector))[0];
       var overflowOffset = $j(scrollContainer).offset();

       if((overflowOffset.top + scrollContainer.offsetHeight) - event.pageY < scrollSensitivity) {

           scrollContainer.scrollTop = scrollContainer.scrollTop + scrollSpeed;
           
       } else if(event.pageY - overflowOffset.top < scrollSensitivity) {

           scrollContainer.scrollTop = scrollContainer.scrollTop - scrollSpeed;
           
       }
       
       if((overflowOffset.left + scrollContainer.offsetWidth) - event.pageX < scrollSensitivity) {
       
           scrollContainer.scrollLeft = scrollContainer.scrollLeft + scrollSpeed;
           
       } else if(event.pageX - overflowOffset.left < scrollSensitivity) {
       
           scrollContainer.scrollLeft = scrollContainer.scrollLeft - scrollSpeed;

       }
   };

   /**
    * Returns the default drag and drop configuration for the page, merged with the given customizations.
    *
    * @param pageHandler the page
    * @param widgetHeight the height of the draggable widgets
    * @param scrollContainerSelector scroll container selector
    * @param updatePoller optional Poller object for background updating of the page
    */
   this.getDragAndDropConfiguration = function(pageHandler, widgetHeight, scrollContainerSelector, updatePoller) {

      var configuration = {
         dropOnEmpty: true,
         cursor: 'move',
         scroll: false,
         cancel: '.pending',
         refreshPositions: false,
         tolerance: "pointer",
         placeholder: 'highlight',
         items: "> div",
         customBeforeStart: function(event, ui) {
             var childContainer = ui.item.find('.childContainer').first();
             var expander = ui.item.find('.artifact-expander').first();
             if(childContainer.find('.item').length > 0) {
                 childContainer.hide();
                 expander.text("+");
                 pageHandler.removeExpandedParentSettings(ui.item);
             }   
         },
         start: function(event, ui) {
            ui.placeholder.height(ui.item.find('.artifact').height());
            pageHandler.rememberLocation(ui.item);
            
            // Add keydown event handler to respond to Esc to cancel the sort action
            $j('body').on('keydown', { sortableEvent : event }, function(keyDownEvent){
				if(keyDownEvent.which === 27) {
					$j(keyDownEvent.data.sortableEvent.target).sortable('cancel');
				}
			});
         },
         stop: function(event, ui) {
        	 // Remove the keydown handler that was added at the starting of sort operation
        	 $j('body').off('keydown');
        	 
            if (pageHandler.isValidDropTarget(event, ui) && ((event.originalEvent) && (event.originalEvent.type = 'mouseup'))) {
               pageHandler.handleDropRequest(event, ui);
            } else {
               return false;
            }
         },
         change: function(event, ui) {
        	 pageHandler.handleSortListChange(event, ui);
         },
         out: function(event, ui){
        	 pageHandler.handleSortListOut(event, ui);
         },
         sort: function(event, ui) {
        	 // Scroll the container explicitly as sortable's scroll isn't working in case of multiple sort lists
        	 me.scroll(event, ui, widgetHeight, scrollContainerSelector);
         }
      };
      
      return configuration;
   };
   
   /**
    * Returns the default configuration for an editor, merged with the given customizations.
    * 
    * @param editorHandler the editor handler
    * @param editor the editor
    * @param customizations {Object} custom settings for the editor
    */
   this.getEditorConfiguration = function(editorHandler, editor, customizations) {
      var configuration = {
         dialogClass: 'drop-shadow',
         width: 475,
         minWidth: 475,
         height: 'auto',
         minHeight: 470,
         autoOpen: false,
         open: function(event, ui) {
            me.fixDialog(editor);
         },
         close: function() {
            editor.dialog('destroy').remove();
         },
         resize: function() {
            me.fitEditorToDialog(editor);
         },
         resizeStop: function() {
            me.fitEditorToDialog(editor);
         }
      };

      return $j.extend(configuration, customizations);
   };

   /**
    * Returns the default configuration for an accordion, merged with the given customizations.
    * 
    * @param editor the editor
    * @param customizations {Object} custom settings for the accordion
    */
   this.getAccordionConfiguration = function(editor, customizations) {
      var height = undefined;
      
      var configuration = {
         header: 'h3',
         animate: false,
         collapsible: true,
         autoHeight: false,
         active: true,
         changestart: function(event, ui) {
            height = editor.height();
         },
         change: function(event, ui) {
            me.fitEditorToDialog(editor, height);
         }
      };
      
      return $j.extend(configuration, customizations);
   };

   /**
    * Fit the description field to the display area for the given editor.
    *
    * @param editor the DOM element containing a task editor
    * @param height (optional) resize the editor window to the given height.  Retain current height if unset.
    */
   this.fitEditorToDialog = function (editor, height) {
      if (height == undefined) {
         height = editor.height();
      }
   
      var desc = editor.find('textarea[name=description]');      
      var last = editor.find('<div/>').last();
      var editorBottom = Math.round(editor.offset().top + editor.height());
      var lastBottom = Math.round(last.offset().top + last.height());
      var sizeChange = editorBottom - lastBottom;
   
      this.forceHeight(desc, desc.height() + sizeChange);      
      this.forceHeight(editor, height);
   };
   
   /**
    * Returns the id of the data a widget represents on the page
    *
    * @param widget {jQuery} the widget
    */
   this.getItemId = function(widget) {
       var widgetId = widget.attr('data-id');
           return typeof(widgetId) != 'undefined' ? widgetId : null;
   };
   
   /**
    * Returns the version of the widget represents on the page
    *
    * @param widget {jQuery} the widget
    */
   this.getItemVersion = function(widget) {
       var artifactVersion = widget.attr('data-version');
           return typeof(artifactVersion) != 'undefined' ? artifactVersion : null;
   };
   
     /**
    * Set the version of the widget represents on the page
    *
    * @param widget {jQuery} the widget
    * @param version the updated artifact version
    */
   this.setItemVersion = function(widget, version) {
   	widget.attr('data-version', version);
   
   };
   
   /**
    * Clones event handlers from source element to target element. If isSourceTargetsChild
    * is true then the event handlers for the target element will be removed.
    * 
    * Note that the implementation will unbind source element event handlers if the
    * source is a child of target element
    * 
    * @param sourceElement Source element whose event handlers need to be copied
    * @param targetElement Target element to set event handlers
    */
   this.cloneEventHandlers = function(sourceElement, targetElement) {
		// Get the event handlers registered
		var events = $j._data(sourceElement[0],"events");
		
		// Iterate over
		$j.each(events, function(eventType, eventArray) {
			
			$j.each(eventArray, function(index, event) {
				
				// Add event handler to the target element
				targetElement.bind(eventType.toString(), event.handler);
				
				// If target is a child element of the source element then remove the handler
				// as we dont want multiple handlers to associate with the source element
				var findChild = targetElement.find(sourceElement)
				if((findChild !== undefined) && (findChild !== null)) {
					sourceElement.unbind(eventType.toString());
				}
			});
		});
   };
   
   /**
    * Validates an editor's content based on the given rules.
    * 
    * @param editor {jQuery} the editor
    * @param rules {[{selector, rule, message}]} the rules the validate the editor content with.
    * @returns true if the editor content is valid.
    */
   this.validateEditor = function(editor, rules) {
      var hasErrors = this.validate(rules, editor);      
      if (hasErrors) { 
          me.highLightAccordionWidget(editor);
          return false;
      } else {
         return true;
      }
   };
   
   
   /**
    * Validates input fields based on the given rules. Returns error messages if any of the fields are invalid.
    * This function will not return duplicate messages.
    *
    * @param parent the parent element to perform the validations upon
    * @param rules an array of objects with the following fields:
    *    id - the id of the element to validate. the rule is not applied if the element is not found.
    *    rule - a predicate which determines whether the value of the element is valid
    *    message - the key of the message to be displayed if the element value is invalid
    *
    * @returns true if there is error.
    */
   this.validate = function(rules, parent) {      
      this.clearErrors(parent);
      var hasErrors = false;
      for (var i = 0; i < rules.length; i++) {
         var rule = rules[i];
         var value;
         var element = parent.find(rule.selector);
         var originalValue= element.attr('originalvalue');         
         if (originalValue) {
        	value = originalValue;
         } else {
         	value = element.val();
         }
         if (value !== undefined && !rule.rule(value)) {
             if (!hasErrors && !element.is(':disabled')) {
                hasErrors = true;
             }
             //Do not add error to disabled fields.
             if(!element.is(':disabled')) {
                 this.markError(element, rule.message);     
             }
         }
      } 
      return hasErrors;
   };

   
   /**
    * Returns the validation rule for empty text.
    */
   this.getNotEmptyValidationRule = function() {
      return function(text) { return $j.trim(text).length > 0; };
   };
   
   /**
    * Returns the validation rule for the maximum length of title fields.
    */
   this.getMaxTitleLengthValidationRule = function() {
      return function(title) { return title.length <= 255; };
   };

   /**
    * Returns the validation rule for description not equal to default description value.
    */
   this.getDescNotSameAsDefaultValidationRule = function(descDefValue) {
      return function(descValue) { 
         if (descDefValue !== undefined && descValue !== undefined) {
             return descDefValue !== descValue.replace(/\n/g, "\r\n");
         } else {
             return true;
         }

      };
   }; 
   
   /**
    * Returns the validation rule for positive integer fields.
    * 
    * @returns {Function} function for validating the positive integer.
    */
   this.getPositiveIntegerValidationRule = function() {
      return function(numValue) {
          return !!numValue.match(/^ *([0-9]*\.?[0-9]+)? *$/); };
   };
   
   /**
    * Returns the validation rule for positive integer fields.
    * 
    * @returns {Function} function for validating the positive integer.
    */
   this.getPositiveNonDecimalIntegerValidationRule = function() {
      return function(numValue) {          
          return !!numValue.match(/^ *([0-9]*?[0-9]+)? *$/); };
   };

    /**
     * Returns the validation rule for positive integer fields.
     *
     * @returns {Function} function for validating the positive integer.
     */
    this.getTrackerBaseUnitValidationRule = function(trkUnitMultiplier) {
       return function(numValue) {
         if (trkUnitMultiplier != 1) {
            return true;
         } else if (trkUnitMultiplier == 1 && numValue.toString().indexOf('.') > -1) {
           var tmpValue = numValue.toString().split('.');
           if (tmpValue[1] == 0) {
             return true;
           }
         } else  if (trkUnitMultiplier == 1) {
            return ($j.trim(numValue).length > 0 && numValue > 0);
         }
         return false;
       };
    };
   
   /**
    * Returns the validation rule for non zero positive integers.
    * 
    * @returns {Function} function for validating the non zero positive integer.
    */
   this.getNonZeroPositiveIntegerValidationRule = function() {
       return function(numValue) {           
           return ($j.trim(numValue).length > 0 && numValue > 0); };       
   };
   
   /**
    * Returns the validation rule for tracker unit  fields.
    * 
    * @returns {Function} function for validating the tracker unit length.
    */
   this.getTrackerUnitLengthValidationRule = function() {
      return function(numValue) {         
    	  return ($j.trim(numValue).length > 0 && $j.trim(numValue).length <=6 ); };
   };
   
   /**
    * Returns the validation rule to check that a select option is not empty.
    * @returns {Function} function for validating a select option.
    */
   this.getOptionSelectedValidationRule = function() {
      return function(option) { return !!option; };
   };

   /**
    * Returns the validation to check the selected value for assignedTo field is not none
    */
   this.getAssignedToFieldValidationRule = function() {
       return function(option) {
           if (me.nobodyUser &&
                   me.nobodyUser.id == option) {
               return false;
           }
           return !!option;
       };
   }
   /**
    * Returns the validation rule result for the regex field.
    * @param result the true/false vlaue store in the validation map for the field.
    * 
    * @returns {Function} function returns the validated regex result.
    */
   this.getRegExValidationRule = function(result) {      
       return function(value) {return result; };
   };

   /**
    * Handles the user logout action.
    */
   this.handleLogout = function() {
	   window.location.reload();
   }
   
   /**
    * The methods formats the i18n message with argument vlaues.
    * 
    * @message the message to be formatted.
    * @arguments the argument list to be replaced with.
    */
   this.formatMessage = function(message, arguments) {
       
       for(var i= 0; i<arguments.length; i++) {          
           message = message.replace('{'+i+'}', arguments[i])
       }
       return message;
   };
   /**
    * The methods displays the success message.
    * 
    * @message the message to be displayed.
    */
   this.successMessage = function(successMessage) {
   
	   var message = ['<div class="greenText"><a class="close" data-dismiss="alert" href="#">&nbsp;</a>',
                  successMessage,'</div>'];
	   $j('#messagesDiv').html(message.join(''));
   
   };
   
   /**
    * The methods removes the success message.
    * 
    */
   this.removeMessageContainer =function() {
   if($j('#messagesDiv').is(':visible')) {
	   $j('#messagesDiv').html('');
	  }
   }
   
   /**
    * The methods check if the key present in source.
    * @source the source
    * @key the key value
    * 
    */
   this.isKeyExist =function(source,key) {
	 
	   return source.search(key) == -1 ? false :true;
	  
   }

  
}

