/*
 * @depends map.js
 * 
 * This code snippet prevents users to leave the artifact summary view with unsaved
 * form elements. The solution is based on the following discussion:
 * 
 * http://stackoverflow.com/questions/140460/client-js-framework-for-unsaved-data-protection
 * 
 * @author Marcello de Sales (mdesales@collab.net)
 */

    // the pristine hash map with the field name -> value when the page loads.
    var pristineValues = new Map();

    // the set of the current fields
    var currentFields = new Array();

    // the map of attachment files by field name -> value
    var attachedFiles = new Map();

    // register an attachment file field name
    function registerFileField(fileFieldName) {
        attachedFiles.put(fileFieldName, "");
    }

    // verify if there is any file attached in the multiple attachments
    function IfThereAreFilesAttached() {
        if (attachedFiles.size() == 1 && attachedFiles.get("file[1]") == "") {
            // if the first attachment field is still clean.
            $j('body').removeAttr('onbeforeunload');
            return false;

        } else {
            var fileAttachNames = attachedFiles.valSet();
            for (var i = 0; i < fileAttachNames.length; i++) {
                var fileValue = fileAttachNames[i];
                if (fileValue != "") {
                    window.onbeforeunload = alertUserOfPossibleUnsavedData;
                    return true;
                }
            }
            $j('body').removeAttr('onbeforeunload');
            return false;
        }
    }

    // remove an attachment file field name
    function removeFileField(fileFieldName) {
        attachedFiles.remove(fileFieldName);
        if (!IfThereAreFilesAttached()) {
            // if the changed field did not change, still verify if any other field still has changed value.
            if (hasAnyPristineFieldChanged()) {
                window.onbeforeunload = alertUserOfPossibleUnsavedData;
                return;
            }
            // if this was reached, it means that the document no changes were found. So remove the attribute.
            $j('body').removeAttr('onbeforeunload');
        }
    }

    // set the alert for the window if the file attachment finished.
    function alertUserIfFilePristineChanged(fileField) {
        if (fileField != null && fileField.value != null) {
            attachedFiles.put(fileField.name, fileField.value);
            window.onbeforeunload = alertUserOfPossibleUnsavedData;
        }
    }

    // verify if the user has changed the value of the given formElement.
    function hasGivenFormElementChanged(formElement) {
        // for the case when user picker is clicked for the assignedTo user field.
        if (formElement == undefined) {
            return false;
        }
        var formName = formElement.name == "" ? formElement.id : formElement.name;
        if (formName == "estimatedEff") {
            formName = "estimatedEffort";
        }
        if (formName == "remainingEff") {
            formName = "remainingEffort";
        }
        if (formName == "actualEff") {
            formName = "actualEffort";
        }
        var formValue = formElement.type == "checkbox" ? formElement.checked : formElement.value;
        // since Assigned to is made as angular, added the below condition
        if (formName == "assignedTo_value" ) {
            formName = "assignedUser";
            formValue = document.getElementById(formName).value;
        }
        return pristineValues.get(formName) != formValue;
    }

    // verify if any of the current form fields has a changed value.
    // and register the alert for the window before unload.
    function hasAnyPristineFieldChanged() {
        for (var i = 0; i < currentFields.length; i++) {
            var f = currentFields[i];
            var t = currentFields[i].type;
            var v = f.type == "checkbox" ? f.checked : f.value;
            if (pristineValues.get(f.name) != v) {
                window.onbeforeunload = alertUserOfPossibleUnsavedData;
                return true;
            }
        }
        // if this was reached, it means that the document no changes were found. So remove the attribute.
        $j('body').removeAttr('onbeforeunload');
        return false;
    }

    /**
     * The traversal of all the valid elements on the form we care about.
     * @param handler is the handler closure to deal with the field.
     */
    function traverseAllValidFormElements(handler) {
        var form = document.viewArtifactForm;
        for(var i = 0; i < form.elements.length; i++) {
            var field = form.elements[i];
            if (field.name != "") {
                handler(field);
            }
        }
    }

    // Register all the pristine values using the closure function.
    function registerPristineValues() {
        traverseAllValidFormElements(function (field) {
            if (field.type == "checkbox") {
                pristineValues.put(field.name, field.checked);
            } else {
                pristineValues.put(field.name, field.value);
            }
            currentFields.push(field);
        });
    }

    // Alert the user if there is any pristine element, considering the change
    // of the given formElement.
    // @param formElement is the html form element that changed its state.
    function alertUserIfAnyPristineChanged(formElement) {
        // verifying if the field has changed its value compared to the pristine, as well as the others.
        // if the changed field did not change, still verify if any other field still has changed value.
        if (hasGivenFormElementChanged(formElement) || hasAnyPristineFieldChanged() || IfThereAreFilesAttached()) {
            window.onbeforeunload = alertUserOfPossibleUnsavedData;
            return;
        }

        // if this was reached, it means that the document no changes were found. So remove the attribute.
        $j('body').removeAttr('onbeforeunload');
    }

    $j(document).ready(function(){
        // collect the pristine values of the form
        registerPristineValues();
        registerFileField('file[1]');

        //----------------------------------------------------------------------
        // Don't allow us to navigate away from a page on which we're changed
        //  values on any control without a warning message.  Need to class our 
        //  save buttons, links, etc so they can do a save without the message - 
        //  ie. CssClass="noWarn". MUST EXCLUDE THE SEARCH ARTIFACT ID field 'idsString'
        //----------------------------------------------------------------------
        $j('input:text,input:checkbox,input:radio,input:hidden,textarea,select').not('[name="idsString"]').bind('change', function() {
            // verifying if the field has changed its value compared to the pristine, as well as the others.
          if (!$j(this).hasClass('pristine')) {
            alertUserIfAnyPristineChanged(this);
          }
        });

        // no warn for elements that does not need to be validate (save and save-view buttons)
        $j('#viewArtifactForm_SaveAndView').click(function() {
            $j('body').removeAttr('onbeforeunload'); 
        });

        $j('#viewArtifactForm_Save').click(function() {
            $j('body').removeAttr('onbeforeunload'); 
        });
    });