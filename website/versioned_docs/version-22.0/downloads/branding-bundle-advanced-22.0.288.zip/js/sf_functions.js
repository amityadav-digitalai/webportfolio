/*
 * CollabNet TeamForge(r) Enterprise Edition

 * Copyright 2007-2018 CollabNet, Inc.  All rights reserved.
 * http://www.collab.net
 */

//defining global variables referred in add_attachments.js, sf_functions.js
var attachedFilesFormData = new Array();
var deletedFiles = new Array();

var autoPopulateFieldArray = [];
function displayAlertErrorMessage(errorMessage) {
    alert(errorMessage);
}

// Style Guide Functions
function toggleDisplay(image, baseId, headerId, downloadUrl) {
    var tableObject = document.getElementById(baseId);
    var headerTable = document.getElementById(headerId);
    if (tableObject.style.display == 'table') {
    	tableObject.style.display = 'none';
        if (image && headerId) {
            image.src = "/sf-images/icons/arrow_collapsed_right.png";
            jQuery(headerTable).addClass('curve-bottom');
        } else {
            image.src =  "/sf-images/icons/icon16_arrowcollapsed_gr.gif";
	}

    } else {
    	tableObject.style.display = 'table';
        if (image && headerId) {
            image.src = "/sf-images/icons/arrow_expanded.png";
            jQuery(headerTable).removeClass("curve-bottom");
        } else {
            image.src =  "/sf-images/icons/icon16_arrowexpanded_gr.gif";
        }
        if (downloadUrl) {
            document.getElementById(baseId).src = downloadUrl;
        }
    }
}

//Add bottom curve to search criteria header  tables when search returns no results.
function addBottomCurve(headerId, bodyId) {
var bodyState = jQuery('#' + bodyId).css('display');
if (bodyState == 'none') {
jQuery('#' + headerId).addClass("curve-bottom");
}
}
/*
 * Gets a comma delimited list of selected values from a select box
 */
function getSelectedValues(sourceElement) {
    var valueString = "";

    if (sourceElement == null || sourceElement.tagName != "SELECT" || sourceElement.length == 0) {
        return;
    }

    for (var i = 0; i < sourceElement.length; i++) {
        var option = sourceElement.options[i];
        if (option.selected) {
            valueString += option.value + ",";
        }
    }

    return valueString.substring(0, valueString.length - 1);
}

// this is used to disaable the passed menu entry.
function disableMenuEntry(menuEntryId) {
    var menuEntry = document.getElementById(menuEntryId);
    menuEntry.innerHTML = '<div class="MenuItemDisabled">' + getDivText(menuEntry) + '</div>';
}


/*
 * Get the text from a specific div tag.  This is used for button and menu disabling functionality
 */
function getDivText(entryDiv) {
    if (entryDiv == null) {
        return '';
    }

    if (entryDiv.childNodes.length == 0) {
        return '';
    }

    var entryText = '';
    for (var i = 0; i < entryDiv.childNodes.length; i++) {
        var divChild = entryDiv.childNodes[i];
        if (divChild.innerHTML != null) {
            entryText += divChild.innerHTML;
        }
    }

    if (entryText == '' && entryDiv.childNodes.length == 1 && entryDiv.childNodes[0].nodeName == '#text') {
        entryText = entryDiv.childNodes[0].nodeValue;
    }

    return entryText;
}

/*
 *
 * Functions for toggling buttons between the enabled and disabled states
 *
 */
// This is used to store the old link information
var _buttonPreferences = new Array();
var _buttonInnerHTML = new Array();
var _buttonDelimiter = '::';

/*
 * An object used for storing preferences pertaining to when a button should be enabled vs. disabled
 */
function ButtonPreference(buttonId, minSelected, maxSelected) {
    this.buttonId = buttonId;
    this.minSelected = minSelected;
    this.maxSelected = maxSelected;
    this.validationFunction = null;

    this.getButtonId = function() {
        return this.buttonId;
    };

    this.getMinSelected = function() {
        return this.minSelected;
    };

    this.getMaxSelected = function() {
        return this.maxSelected;
    };

    this.hasValidationFunction = function() {
    	return this.validationFunction != null;
    };

    this.setValidationFunction = function(validationFunction) {
    	this.validationFunction = validationFunction;
    };

    this.getValidationFunction = function() {
    	return this.validationFunction;
    };
}

/*
 * Registers a button with a form element so that depending on how many items are checked, the button status can be
 *
 */
function registerButton(buttonId, formName, elementName, minSelected, maxSelected, validationFunction) {
    var prefId = formName + _buttonDelimiter + elementName;
    var prefArray = _buttonPreferences[prefId];

    //to handle registered calls from the artifact in line-edit mode
    if (typeof editMode == "boolean" && editMode) {
    	return false;
    }

    if (prefArray == null) {
        prefArray = new Array();
        _buttonPreferences[prefId] = prefArray;
    }

    prefArray[prefArray.length] = new ButtonPreference(buttonId, minSelected, maxSelected);
    prefArray[prefArray.length - 1].setValidationFunction(validationFunction);

    var form = document.forms[formName];
    if (form != null) {
        var element = form.elements[elementName];
        /* If enablement is not based on the number of items selected, toggle buttons.
         * If enablement is based on the number of items selected and there is at least
         * one list element visible, toggle buttons.  Otherwise, disable the button. */
        if (element != null || (minSelected == -1 && maxSelected == -1)) {
            toggleButtons(element);
        } else {
	    setButtonState(buttonId, "disabled");
        }
    }
}



function toggleButtonsCustomized(formElement) {
    if (formElement == null) {
        return;
    }

    var formName = '';
    var elementName = '';
    if (formElement.length != null && formElement.length > 0) {
        formName = formElement[0].form.name;
        elementName = formElement[0].name;
    } else {
        formName = formElement.form.name;
        elementName = formElement.name;
    }

    var prefId = formName + _buttonDelimiter + "_listItem";
    var prefList = _buttonPreferences[prefId];

     if (prefList == null) {
         return;
     }

    // Get the form and see how may checkboxes are checked
    var checked = 0;

    var checkboxes = document.forms[formName].elements[elementName];
    if (checkboxes.length == null) {
        if (checkboxes.checked) {
            checked = 1;
        }
    } else {
        for (var i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i].checked) {
                checked++;
            }
        }
    }

    // Now step through the preferences and toggle anything that needs to be toggled
    for (var j = 0; j < prefList.length; j++) {
        var pref = prefList[j];
        var buttonState = "disabled";
        if (pref.hasValidationFunction()) {
            if (pref.getValidationFunction()(checkboxes)) {
            	buttonState = "enabled";
            }
        } else if ((pref.getMinSelected() < 0 || checked >= pref.getMinSelected()) &&
            (pref.getMaxSelected() < 0 || checked <= pref.getMaxSelected())) {
            buttonState = "enabled";
        }

        // Set the button state
        setButtonState(pref.getButtonId(), buttonState);
    }
    toggleHeaderCheckBoxState(formName, checked, checkboxes.length);
}



/*
 * Toggles the state of any buttons that are listending to a specific form element
 */
function toggleButtons(formElement) {
    if (formElement == null) {
        return;
    }
    var formName = '';
    var elementName = '';
    if (formElement.length != null && formElement.length > 0) {
        formName = formElement[0].form.name;
        elementName = formElement[0].name;
    } else {
        formName = formElement.form.name;
        elementName = formElement.name;
    }

     toggleButtonsByName(formName, elementName);
}

/*
 * Toggles the state of all selected row when select all is toggled.
 */
function toggleAll(checker, formElement) {
  for(var i = 0; i < formElement.length; i++) {
    toggleRow(formElement[i]);
  }
}

/*
 * Toggles the state of selected row when checkox or radio button is toggled.
 */
function toggleRow(formElement) {
  //This is a hack to get only radio buttons remove background.
  var elementType = $j(formElement).attr('type');
  if(elementType.toLowerCase() === 'radio'){
    var nearestSelectedRow = $j(formElement).parentsUntil('.row-selected');
    if(nearestSelectedRow) {
      nearestSelectedRow.find('.row-selected').removeClass('row-selected');
    }
  }
  if (formElement.checked) {
    $j(formElement).closest('tr').addClass('row-selected');
  } else {
    $j(formElement).closest('tr').removeClass('row-selected');
  }
}

/*
 * Toggles the state of any buttons that are listening to a specific form name and element name
 */
function toggleButtonsByName(formName, elementName) {
    var prefId = formName + _buttonDelimiter + elementName;
    var prefList = _buttonPreferences[prefId];

     if (prefList == null) {
         return;
     }

      // Get the form and see how many checkboxes are checked
    // This is a bad hack that works with all versions of IE, do not modify it without testing this properly in the
    // planning folder artifact list in /sort/ and /rank/ mode!
    // The jQuery reads, look for the element that has the name /formName/ and within this element look for
    // "input" elements that are checked and have the name /elementName/. Count them and assign this to /checked/
    var checked = $j("*[name='" + formName + "'] input:checked[name='" + elementName + "']").length;
    var total = $j("*[name='" + formName + "'] input[name='" + elementName + "']").length;

    // Now step through the preferences and toggle anything that needs to be toggled
    for (var j = 0; j < prefList.length; j++) {
        var pref = prefList[j];
        var buttonState = "disabled";
        if (pref.hasValidationFunction()) {
                var checkboxes = document.forms[formName].elements[elementName];
                if (pref.getValidationFunction()(checkboxes)) {
            	buttonState = "enabled";
            }
        } else if ((pref.getMinSelected() < 0 || checked >= pref.getMinSelected()) &&
            (pref.getMaxSelected() < 0 || checked <= pref.getMaxSelected())) {
            buttonState = "enabled";
        }

        // Set the button state
        setButtonState(pref.getButtonId(), buttonState);
    }
	toggleHeaderCheckBoxState(formName, checked, total);
}

/* Reset buttons in the specified form and enable a button with given buttonId.
   Use this call only once in a page, as calling this twice will reset whatever
   has been set in the first time. */
function toggleButtonsInsideIFrame(formElement, elementName0, buttonId) {
    if (formElement == null) {
        return;
    }

    var formName = '';
    var elementName = '';
    if (formElement.length != null && formElement.length > 0) {
        formName = formElement[0].form.name;
	if (elementName0 == null) {
	    elementName = formElement[0].name;
	} else {
	    elementName = elementName0;
	}
    } else {
        formName = formElement.form.name;
        elementName = formElement.name;
    }

    var prefId = formName + _buttonDelimiter + elementName;
    var prefList = _buttonPreferences[prefId];
     if (prefList == null) {
         return;
     }

    // Get the form and see how may checkboxes are checked
    var checked = 1;
    var checkboxes = document.forms[formName].elements[elementName];
    if (checkboxes.length == null) {
        if (checkboxes.checked) {
            checked = 1;
        }
    } else {
        for (var i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i].checked) {
                checked++;
            }
        }
    }

    // Now step through the preferences and toggle anything that needs to be toggled
    for (var j = 0; j < prefList.length; j++) {
        var pref = prefList[j];
	var buttonState = "disabled";
	if (buttonId == undefined || pref.getButtonId() == buttonId) {
	    if (pref.hasValidationFunction()) {
		if (pref.getValidationFunction()(checkboxes)) {
		    buttonState = "enabled";
		}
	    } else if ((pref.getMinSelected() < 0 || checked >= pref.getMinSelected()) &&
		(pref.getMaxSelected() < 0 || checked <= pref.getMaxSelected())) {
		buttonState = "enabled";
	    }
	}

	// Set the button state
	setButtonState(pref.getButtonId(), buttonState);
    }
}

function dissableOneButtonInsideIFrame(formElement, elementName0, buttonId) {
    if (formElement == null) {
        return;
    }

    var formName = '';
    var elementName = '';
    if (formElement.length != null && formElement.length > 0) {
        formName = formElement[0].form.name;
	if (elementName0 == null) {
	    elementName = formElement[0].name;
	} else {
	    elementName = elementName0;
	}
    } else {
        formName = formElement.form.name;
        elementName = formElement.name;
    }

    var prefId = formName + _buttonDelimiter + elementName;
    var prefList = _buttonPreferences[prefId];
     if (prefList == null) {
         return;
     }

    // Get the form and see how may checkboxes are checked
    var checked = 1;
    var checkboxes = document.forms[formName].elements[elementName];
    if (checkboxes.length == null) {
        if (checkboxes.checked) {
            checked = 1;
        }
    } else {
        for (var i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i].checked) {
                checked++;
            }
        }
    }

    // Now step through the preferences and toggle anything that needs to be toggled
    for (var j = 0; j < prefList.length; j++) {
        var pref = prefList[j];
	var buttonState = "disabled";
	if (buttonId == undefined || pref.getButtonId() == buttonId) {
		setButtonState(pref.getButtonId(), buttonState);

	}

    }
}
/*
 * Set the state of a button an sf-button in a form
 *
 */
function setButtonStateWithElement(divTagElement, buttonId, state) {

    var isDropDown = false;
    var buttonMiddle = null;

    if (state == 'disabled') {
        buttonMiddle = getButtonSection(divTagElement, 'Middle');
    } else {
        buttonMiddle = getButtonSection(divTagElement, 'MiddleDisabled');
    }

    if (buttonMiddle == null) {
        isDropDown = true;
        if (state == 'disabled') {
            buttonMiddle = getButtonSection(divTagElement, 'MiddleDropDown');
        } else {
            buttonMiddle = getButtonSection(divTagElement, 'MiddleDisabledDropDown');
        }
    }

    if (buttonMiddle == null) {
        return false;
    }

    var buttonDisabled = false;
    if (buttonMiddle != null) {
        if (_buttonInnerHTML[buttonId] != null) {
            buttonMiddle.innerHTML = _buttonInnerHTML[buttonId];
            _buttonInnerHTML[buttonId] = null;
        } else {
            _buttonInnerHTML[buttonId] = buttonMiddle.innerHTML;
            buttonMiddle.innerHTML = getDivText(buttonMiddle);
            buttonDisabled = true;
        }
    }

    if (buttonDisabled) {
        buttonMiddle.className = 'MiddleDisabled';

        if (isDropDown) {
            buttonMiddle.className = 'MiddleDisabledDropDown';
        }
    } else {
        buttonMiddle.className = 'Middle';

        if (isDropDown) {
            buttonMiddle.className = 'MiddleDropDown';
        }
    }
    return true;
}

/*
 * Set the state of a button an sf-button in a form
 */
function setButtonState(buttonId, state) {
   var divTag = document.getElementById(buttonId);
   return setButtonStateWithElement(divTag, buttonId, state);
}

/*
 * Get the div tag representing a specific portion of a button (left, middle, or right side)
 */
function getButtonSection(buttonContainer, buttonClass) {
    if (buttonContainer != null){
       for (var i = 0; i < buttonContainer.childNodes.length; i++) {
          var buttonSection = buttonContainer.childNodes[i];
          if (buttonSection.className == buttonClass) {
            return buttonSection;
          }
       }
    }
    return null;
}


// Beginning of menu functions

// Used to store menu list selection preferences
var _MenuListSelectPreferences = new Array();

/*
 * An object used for storing preferences pertaining to when a button should be enabled vs. disabled
 */
function MenuPreference(menuEntryId, formName, elementName, minSelected, maxSelected) {
    this.menuEntryId = menuEntryId;
    this.minSelected = minSelected;
    this.maxSelected = maxSelected;
    this.formName = formName;
    this.elementName = elementName;
    this.originalContent = document.getElementById(menuEntryId).innerHTML;

    this.getFormName = function() {
        return this.formName;
    };

    this.getElementName = function() {
        return this.elementName;
    };

    this.getMinSelected = function() {
        return this.minSelected;
    };

    this.getMaxSelected = function() {
        return this.maxSelected;
    };

    this.getMenuEntryId = function() {
        return this.menuEntryId;
    };

    this.initialize = function() {
        var menuEntry = document.getElementById(this.menuEntryId);
        menuEntry.innerHTML = this.originalContent;

        if (!this.isEnabled()) {
            menuEntry.innerHTML = '<div class="MenuItemDisabled">' + getDivText(menuEntry) + '</div>';
        }
    };

    this.isEnabled = function() {
	if (this.minSelected <= 0 && this.maxSelected < 0) {
	    return true;
	}

	var form = document.forms[this.formName];
	if (form == null) {
	    return false;
	}

    // use jquery selector instead of "form.elements[<name>]", since the latter isn't uptodate for modified DOM
    var checkboxes = jQuery("input[name="+this.elementName+"]").get();
	if (checkboxes == null) {
	    return false;
	}

	var checked = 0;
	if (checkboxes.length == null) {
	    if (checkboxes.checked) {
		checked = 1;
	    }
	} else {
	    for (var i = 0; i < checkboxes.length; i++) {
		if (checkboxes[i].checked) {
		    checked++;
		}
	    }
	}

	return ((this.minSelected <= 0 || this.minSelected <= checked) &&
	    	(this.maxSelected < 0 || this.maxSelected >= checked));
    };
}

/**
 * This method sets the selection preferences for a menu entry.  Based on a list select form, different
 * numbers of checked items can change the behavior of menu options.
 *
 * @param menuId the menu id
 * @param entryId the entry id
 * @param formName the form name
 * @param minSelected the minimum number of selected items
 * @param maxSelected the maximum number of selected items
 * @param listElementName the form list element name.
 * 			If the listElementName is not specified, then it defaults to '_listItem'.
 */
function setMenuEntryPreference(menuId, entryId, formName, minSelected, maxSelected, listElementName) {

	if (!listElementName) {
		listElementName = '_listItem';
	}

    if (_MenuListSelectPreferences[menuId] == null) {
        _MenuListSelectPreferences[menuId] = new Array();
    }

    var prefId = _MenuListSelectPreferences[menuId].length;
    _MenuListSelectPreferences[menuId][prefId] = new MenuPreference(entryId, formName, listElementName, minSelected, maxSelected);
}

/**
 * Initialize the menu entries to the correct states
 */
function initMenu(menuId) {
    var preferences = _MenuListSelectPreferences[menuId];
    if (preferences != null) {
      for (var i = 0; i < preferences.length; i++) {
        preferences[i].initialize();
      }
    }
}

/*
 * The new menu implementation
 */

/*
 * First, check the browser
 */
var detect = navigator.userAgent.toLowerCase();
var thestring;

function Browser() {
	this.isKonqueror = false;
	this.isSafari = false;
	this.isOmniWebr = false;
	this.isOpera = false;
	this.isWebTV = false;
	this.isICab = false;
	this.isIE = false;
	this.isNS = false;
	this.isChrome = false;

	if (checkIt('konqueror')) this.isKonqueror = true;
	else if (checkIt('safari')) this.isSafari = true;
	else if (checkIt('omniweb')) this.isOmniWebr = true;
	else if (checkIt('opera')) this.isOpera = true;
	else if (checkIt('webtv')) this.isWebTV = true;
	else if (checkIt('icab')) this.isICab = true;
	else if (checkIt('msie')) this.isIE = true;
    else if (checkIt('chrome')) this.isChrome = true;
	//else if (!checkIt('compatible')) this.isNS = true;
	else this.isNS = true;
        return;
}

function checkIt(string)
{
	var place = detect.indexOf(string) + 1;
	thestring = string;
	return place;
}

var browser = new Browser();

// Reference to the currently active button (none on open)
var activeButton = null;

// Capture mouse clicks on the page so any active button can be
// deactivated.

if (browser.isIE) {
  document.onmousedown = pageMousedown;
} else if (document.addEventListener != null) {
  document.addEventListener("mousedown", pageMousedown, true);
}

function pageMousedown(event) {

  var el;

  // If there is no active menu, exit.

  if (!activeButton)
    return;

  // Find the element that was clicked on.

  if (browser.isIE)
    el = window.event.srcElement;
  else
    el = (event.target.className ? event.target : event.target.parentNode);

  // If the active button was clicked on, exit.

  if (el == activeButton)
    return;

  var elId = el.id;
  // If the element clicked on was not a menu button or item, close the
  // active menu.

  if (el.className != "menuButton"  && el.className != "menuItem" && el.className != "caret" &&
      el.className != "menuItemSep" && el.className != "menu" &&
      el.className != "AppButtonText" && el.className != "AppButtonPadding" &&
      el.className != "AppButtonPaddingRight" && elId != "rows-icon" && elId != "columns-icon")
    closeMenu(activeButton);
}

function buttonClick(button, menuName) {
  // Associate the named menu to this button if not already done.

  if (!button.menu)
    button.menu = document.getElementById(menuName);

  // Reset the currently active button, if any.

  if (activeButton && activeButton != button)
    closeMenu(activeButton);

  // Toggle the button's state.

  if (button.isDepressed)
    closeMenu(button);
  else
    openMenu(button);

  return false;
}

function buttonClickAndSetMenuPosition(button, menuName) {
  // Associate the named menu to this button if not already done.

  if (!button.menu)
    button.menu = document.getElementById(menuName);

  // Reset the currently active button, if any.

  if (activeButton && activeButton != button)
    closeMenu(activeButton);

  // Toggle the button's state.

  if (button.isDepressed)
    closeMenu(button);
  else
    openMenu(button);

  // Set menu position
  setMenuPosition(button);

  return false;
}

function buttonMouseover(button, menuName) {

  // If any other button menu is active, deactivate it and activate this one.
  // Note: if this button has no menu, leave the active menu alone.

  if (activeButton && activeButton != button) {
    closeMenu(activeButton);
    if (menuName)
      buttonClick(button, menuName);
  }
}

/**
 * This  method handles the keyboard events of a dropdown. It will allow user to select
 * the options of a dropdown via keyboard keys(up, down, right, left arrows)
 * @param eventData
 * @param event
 */
function getChar(eventData, event){
  var keyCode = ('which' in event) ? event.which : event.keyCode;
  var button = eventData.button;
  var menuName = eventData.menuName;

  if (!button.menu) {
    button.menu = document.getElementById(menuName);
  }
  if (button.isDepressed) {
    var menuItems = $j(button.menu).find('a');

    //up arrow
    if(keyCode == 38){
      var selectedIndex = -1;
      var selected = undefined;
      $j.each(menuItems, function( index, value ) {
        if( $j(menuItems[index]).hasClass('menuSelected')){
          selected = menuItems[index];
          $j(menuItems[index]).removeClass('menuSelected');
          selectedIndex = index;
        }
      });
    if (selected == undefined || selectedIndex == 0) {
		  $j(menuItems[menuItems.length-1]).addClass("menuSelected");
      } else {
    	  $j(menuItems[selectedIndex-1]).addClass("menuSelected");
      }
	}

	//tab
	if(keyCode == 9) {
		event.preventDefault();
	}

	//down arrow or tab
	if(keyCode == 40 || keyCode == 9) {
	  var selectedIndex = -1;
	  var selected = undefined;
	  $j.each(menuItems, function( index, value ) {
	    if( $j(menuItems[index]).hasClass('menuSelected')){
		  selected = menuItems[index];
		  $j(menuItems[index]).removeClass('menuSelected');
		  selectedIndex = index;
	    }
	  });
	  if (selected == undefined || selectedIndex == menuItems.length) {
        $j(menuItems[0]).addClass("menuSelected");
      } else {
        $j(menuItems[selectedIndex+1]).addClass("menuSelected");
      }
    }

    //enter
    if(keyCode == 13){
      $j.each(menuItems, function( index, value ) {
        if( $j(menuItems[index]).hasClass('menuSelected')){
          $j(menuItems[index])[0].click();
        }
      });
    }
  }

  //up,down,right,left arrow
  else if(keyCode == 37 || keyCode == 38 || keyCode == 39 || keyCode == 40) {
    openMenu(button);
  }

  //escape
  if(keyCode == 27) {
    closeMenu(button);
  }
}

function BrowserWidth() {
  var myWidth = 0;
  if( typeof( window.innerWidth ) == 'number' ) {
    //Non-IE
    myWidth = window.innerWidth;
  } else {
    if( document.documentElement &&
        ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
      //IE 6+ in 'standards compliant mode'
      myWidth = document.documentElement.clientWidth;
    } else {
      if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
        //IE 4 compatible
        myWidth = document.body.clientWidth;
      }
    }
  }
  return myWidth;
}

function openMenu(button) {
  $j(button.menu).find('a').removeClass("menuSelected");
  var w, dw, x, y, screenWidth, menuWidth;

  initMenu(button.menu.id);

  // For IE, set an explicit width on the first menu item. This will
  // cause link hovers to work on all the menu's items even when the
  // cursor is not over the link's text.

  if (browser.isIE && (button.menu.firstChild.style != null) && !button.menu.firstChild.style.width) {
    w = button.menu.firstChild.offsetWidth;
    button.menu.firstChild.style.width = w + "px";
    dw = button.menu.firstChild.offsetWidth - w;
    w -= dw;
    button.menu.firstChild.style.width = w + "px";
  }

  x = getPageOffsetLeft(button);
  y = getPageOffsetTop(button);
  var menuHeight = jQuery(button.menu).outerHeight();
  var buttonEl = jQuery(button);
  var windowEl = jQuery(window);

  if ((buttonEl.offset().top + buttonEl.height() + menuHeight) > (windowEl.height() + windowEl.scrollTop())) {
    // if we run out of space, put the menu above the button instead
    y = y - menuHeight;
  } else {
    // Position the associated drop down menu under the button and show it
    y = y + button.offsetHeight;
  }

  if (browser.isIE) {
    x += 2;
    y += 2;
  }
  if (browser.isNS && browser.version < 6.1)
    y--;
  else if (browser.isNS && button.menu.id != "filters") {
    var child = button.firstChild;
    // If we can get offsetLeft of child, that's likely
    // an image, which can be "float: right"'ed. Mozilla has
    // bug calculating parent link offsetLeft for euch images
    if (child != undefined && child.offsetLeft != undefined) {
      x += child.offsetLeft;
    }
  }

  // Determine the width of the menu
  if (browser.isIE) {
    screenWidth = window.screen.availWidth;
    menuWidth = button.menu.offsetWidth;
  }
  else {
    screenWidth = screen.width;
    menuWidth = document.defaultView.getComputedStyle(button.menu, "").getPropertyValue("width");
    menuWidth = menuWidth.substr(0, menuWidth.length - 2);
  }

  var SEARCHES_MENU_WIDTH = 300;
  if (button.menu.id == "searches"){
      button.menu.style.width = SEARCHES_MENU_WIDTH;
      x = x - SEARCHES_MENU_WIDTH ;
  }

  // With the width of the menu, correct the x position if necessary
  if (x > (BrowserWidth() - menuWidth -5))
    x = x - menuWidth -5;
  if (x < 0)
    x = 0;


  // Position and show the menu.

  button.menu.style.left = x + "px";
  button.menu.style.top  = y + "px";
  button.menu.style.visibility = "visible";
  var blockFrameHeight

  //all the menu items size 25, except from the items in the number of results per page menu are 25 height
  var HEIGHT_COMMON_MENU_ITEM = 25
  var HEIGHT_TABLE_CONFIG_MENU_ITEM = 17
  var blockedRowHeight = HEIGHT_COMMON_MENU_ITEM
  if (button.menu.id == "configureTableMenu") {
      blockedRowHeight=HEIGHT_TABLE_CONFIG_MENU_ITEM
  }

  if (button.menu.id == "ProjectMenu") {
      var maxHeight = document.body.clientHeight;
      var minHeight = 50;
//      blockFrameHeight = (document.getElementById('ProjectMenu').getElementsByTagName('a').length)*25

      if (maxHeight < button.menu.scrollHeight) {
	  var height = Math.max(maxHeight - (y + 20), minHeight);

	  if (button.menu.style.overflow != "auto") {
	      button.menu.style.width = button.menu.offsetWidth + 15;
	      button.menu.style.height = height + "px";
	      button.menu.style.overflow = "auto";
	  }
      } else {
	  button.menu.style.overflow = "";
	  button.menu.style.height = "auto";
      }
  }

    if (isIEVersion(6)) {
        if (!fixIframeObj) {
            fixIframeObj = createIEFix();
        }
        blockFrameHeight = (button.menu.getElementsByTagName('a').length)*blockedRowHeight
        fixIframeObj.style.display = '';
        fixIframeObj.style.width = menuWidth + 2
        fixIframeObj.style.top = y
        fixIframeObj.style.left = x
        fixIframeObj.style.height = blockFrameHeight

        if(button.menu.style.height!= null && button.menu.style.height!= '' &&button.menu.style.height >0){
            fixIframeObj.style.height = button.menu.style.height;
        }
    }

  // Set button state and let the world know which button is
  // active.

  button.isDepressed = true;
  activeButton = button;
}

function closeMenu(button) {
  if (!button) return;
  if (button.menu)
    button.menu.style.visibility = "hidden";

  // Set button state and clear active menu global.
    if (isIEVersion(6)) {
        fixIframeObj = document.getElementById('blockIframeLayer')
        fixIframeObj.style.display = 'none'
    }
  button.isDepressed = false;
  activeButton = null;
}

/*
 * Some help functions for the positioning
 */
function getPageOffsetLeft(el) {

  // Return the true x coordinate of an element relative to the page.

  return el.offsetLeft + (el.offsetParent ? getPageOffsetLeft(el.offsetParent) : 0);
}

function getPageOffsetTop(el) {

  // Return the true y coordinate of an element relative to the page.

  return el.offsetTop + (el.offsetParent ? getPageOffsetTop(el.offsetParent) : 0);
}

/*
 * This method is used for toggling check boxes in a form.  All it needs is the form and
 * the name of the checkbox elements being toggled.  The checkboxes always are populated to the state of the master
 * checkbox.
 *
 * checker  - The actual element that is being used to toggle the checkboxes
 * formName - The name of the form that is having elements toggled
 * varName  - The name of the checkboxes that are being toggled by the master
 */
function toggleSelectItems(checker, formName, varName) {
    var form = eval("document." + formName);
    var checkBoxes = new Array();

    if (form == null) {
        return;
    }
    if (!isHttpTest) {
        toggleHeaderCheckBox(checker.checked, formName);
    }

    // Step through the form elements and see if we can find them manually
    for (var i = 0; i < form.elements.length; i++) {
	if (form.elements[i].name == varName) {
	    checkBoxes.push(form.elements[i]);
	}
    }

    if (checkBoxes.length == 0) {
	return;
    }

    var numOptions = checkBoxes.length;
    if (numOptions == null) {
        checkBoxes.checked = checker.checked;
    } else {
        for (var i = 0; i < numOptions; i++) {
            checkBoxes[i].checked = checker.checked;
        }
    }

    toggleButtons(checkBoxes);
    toggleAll(checker.checked, checkBoxes);
}

//function to toggle header and floating header checkbox when either of it is clicked
function toggleHeaderCheckBox(value, formName){
   $j('.floatingHeader').find('input[name="_listCheckAll"]').prop("checked", value);
   $j('form[name='+formName+']').find('input[name="_listCheckAll"]').prop("checked", value);
}

//function to change the header checkbox state when atleast one of the items is not selected 
function toggleHeaderCheckBoxState(formName, checked, total){
    if(checked !=0 && checked < total ) {
	    toggleHeaderCheckBox(false, formName);
        $j('.floatingHeader').find('input[name="_listCheckAll"]').addClass("negateIcon");
        $j('form[name='+formName+']').find('input[name="_listCheckAll"]').addClass("negateIcon");
    } else {
	if(checked == 0 ) {
	    toggleHeaderCheckBox(false, formName);
	} else {
	    toggleHeaderCheckBox(true, formName);
	}
	$j('.floatingHeader').find('input[name="_listCheckAll"]').removeClass("negateIcon");
	$j('form[name='+formName+']').find('input[name="_listCheckAll"]').removeClass("negateIcon");
	}
}

//for dhtml filter row hide / reveal
function trigger() {

   var filterrow = document.getElementById('filter');
   if (filterrow != undefined) {
	filterrow.style.display = "none";

        var ficon = document.getElementById('filtericon');
 	ficon.src = ficon.src.replace('Hide','Show');

        var applyfilterbutton = document.getElementById('applyfilter');
        if (applyfilterbutton != undefined)
        applyfilterbutton.style.display = "none";

	var removefilterbutton = document.getElementById('removefilter');
        if (removefilterbutton != undefined)
	removefilterbutton.style.display = "none";

	var dividerbutton = document.getElementById('divider');
        if (dividerbutton != undefined)
	dividerbutton.style.display = "none";

       var applyfilterbutton2 = document.getElementById('applyfilter2');
       if (applyfilterbutton2 != undefined)
       applyfilterbutton2.style.display = "none";

       var removefilterbutton2 = document.getElementById('removefilter2');
       if (removefilterbutton2 != undefined)
       removefilterbutton2.style.display = "none";

       var dividerbutton2 = document.getElementById('divider2');
       if (dividerbutton2 != undefined)
       dividerbutton2.style.display = "none";

        var filterTD = document.getElementById('filterTD');
        if (filterTD != undefined) {
        	 filterTD.style.border = "1px solid #FFFFFF";
             filterTD.style.background = "#FFFFFF";
        }

    }
}

//for dhtml filter row hide / reveal when using Filters button
function trigger2(filterPlus) {

   var filterrow = document.getElementById('filter');
   if (filterrow != undefined) {
     filterrow.style.display = "none";

     var filterbutton = document.getElementById('filters_button');
     filterbutton.innerHTML = filterPlus;

     var filterbutton = document.getElementById('filters_button_img');
     filterbutton.innerHTML = "<img src=\"/sf-images/icons/table/icon_ShowFilters.png\" width=\"16\" height=\"16\" alt=\""+ showFilterTxt +"\">";

     var applyfilterbutton = document.getElementById('applyfilter');
     if (applyfilterbutton != undefined)
        applyfilterbutton.style.display = "none";

     var removefilterbutton = document.getElementById('removefilter');
     if (removefilterbutton != undefined)
        removefilterbutton.style.display = "none";

     var dividerbutton = document.getElementById('divider');
     if (dividerbutton != undefined)
        dividerbutton.style.display = "none";

     var applyfilterbutton2 = document.getElementById('applyfilter2');
     if (applyfilterbutton2 != undefined)
        applyfilterbutton2.style.display = "none";

     var removefilterbutton2 = document.getElementById('removefilter2');
     if (removefilterbutton2 != undefined)
       removefilterbutton2.style.display = "none";

     var dividerbutton2 = document.getElementById('divider2');
     if (dividerbutton2 != undefined)
       dividerbutton2.style.display = "none";

     var filterTD = document.getElementById('filterTD');
     if (filterTD != undefined) {
    	 filterTD.style.border = "1px solid #FFFFFF";
         filterTD.style.background = "#FFFFFF";
     }
   }

   var filterrow = document.getElementById('filter1');
   if (filterrow != undefined) {
     filterrow.style.display = "none";
   }
}


function collapseRow(){

        if (document.getElementById('filter').style.display == ""){
	trigger();
	}
	else
	{
	var filterrow = document.getElementById('filter');
	filterrow.style.display = "";

        var ficon = document.getElementById('filtericon');
 	ficon.src = ficon.src.replace('Show','Hide');

        var applyfilterbutton = document.getElementById('applyfilter');
        if (applyfilterbutton != undefined)
	applyfilterbutton.style.display = "";

	var removefilterbutton = document.getElementById('removefilter');
        if (removefilterbutton != undefined)
	removefilterbutton.style.display = "";

	var dividerbutton = document.getElementById('divider');
        if (dividerbutton != undefined)
	dividerbutton.style.display = "";

        var applyfilterbutton2 = document.getElementById('applyfilter2');
        if (applyfilterbutton2 != undefined)
        applyfilterbutton2.style.display = "";

        var removefilterbutton2 = document.getElementById('removefilter2');
        if (removefilterbutton2 != undefined)
        removefilterbutton2.style.display = "";

        var dividerbutton2 = document.getElementById('divider2');
        if (dividerbutton2 != undefined)
        dividerbutton2.style.display = "";

        var filterTD = document.getElementById('filterTD');
        if (filterTD != undefined) {
        	 filterTD.style.border = "1px solid #CCCCCC";
        	 filterTD.style.background = "#FAFAFA";
        }
        }
}

//drop down menu jump script
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}



//auto centering popup code...
var win = null;

function NewWindow(mypage,myname,w,h,scroll){
  var leftPosition = (screen.width) ? (screen.width-w)/2 : 0;
  var topPosition = (screen.height) ? (screen.height-h)/2 : 0;
  var settings = 'height=' + h +
         ',width=' + w +
         ',top=' + topPosition +
         ',left=' + leftPosition +
         ',scrollbars=' + scroll +
         ',resizable=yes';
  win = window.open(mypage, myname, settings);
  if (win != null) {
    win.focus();
  }
}


function NewWindowWithSessionCheck(mypage,myname,w,h,scroll){
  if (isHttpTest || isSessionActive()) {
     NewWindow(mypage,myname,w,h,scroll);
  } else {
     showSessionTimeoutDiv();
  }
}

// The code in this file is not optimized for titan production... keep that in mind when using for development purposes.

//dhtml tabs

function domTab(i,n){
	// Variables for customisation:
	var numberOfTabs = 5;
	var colourOfInactiveTab = "#D2D2D2";
	var colourOfActiveTab = "#DFDFDF";
	var colourOfInactiveLink = "#333333";
	var colourOfActiveLink = "#333333";
	var colourOfActiveBottomBorder = "#DFDFDF";
	var colourOfInactiveBottomBorder = "1px solid #ff0000";
	// end variables
	if (document.getElementById){
		for (var f = 1; f < numberOfTabs + 1; f++) {
			document.getElementById('contentblock'+f).style.display='none';
			document.getElementById('link'+f).style.background=colourOfInactiveTab;
			document.getElementById('link'+f).style.color=colourOfInactiveLink;
		}
		document.getElementById('contentblock'+i).style.display='block';
		document.getElementById('link'+i).style.background=colourOfActiveTab;

		document.getElementById('link'+i).style.color=colourOfActiveLink;
	}
}




//for the open / close functions in the leftnav
function toggleOpenMenu(o,framesetCall) {
    var i,l,t;
    i = o.getElementsByTagName('img')[0];
    l = o.parentNode.getElementsByTagName('div')[1];
    if(l.style.display == 'block') {
	l.style.display = 'none';
	i.src = i.src.replace('_open.','_closed.');
    } else {
	i.src = i.src.replace('_closed.','_open.');
	l.style.display = 'block';
    }
}

function toggleCloseMenu(o,openstate,framesetCall) {
    var i,l,t;
    i = o.getElementsByTagName('img')[0];
    l = o.parentNode.getElementsByTagName('div')[1];

    if(l.style.display !='none'){
	l.style.display ='none';
	i.src = i.src.replace('_open.','_closed.');
    }
    else{
	l.style.display = 'block';
	i.src = i.src.replace('_closed.','_open.');
    }
}

// No need to edit beyond here

// --- START MENU CODE ---
var ie4 = document.all && (navigator.userAgent.indexOf("Opera") == -1);
var ns6 = document.getElementById && !document.all;
var ns4 = document.layers;

function showmenu(e, which) {
    if (!document.all && !document.getElementById && !document.layers) {
	return;
    }

    clearhidemenu();
    var menuobj = ie4? document.all.popmenu : ns6? document.getElementById("popmenu") : ns4? document.popmenu : "";
    menuobj.thestyle=(ie4||ns6)? menuobj.style : menuobj;
    if (ie4||ns6) {
	menuobj.innerHTML=which;
    } else {
	menuobj.document.write('<layer name=gui bgColor=#E6E6E6 width=165 onmouseover="clearhidemenu()" onmouseout="hidemenu()">'+which+'</layer>');
	menuobj.document.close();
    }

    menuobj.contentwidth = (ie4 || ns6) ? menuobj.offsetWidth : menuobj.document.gui.document.width;
    menuobj.contentheight = (ie4 || ns6) ? menuobj.offsetHeight : menuobj.document.gui.document.height;

    var eventX = ie4? event.clientX : ns6? e.clientX : e.x;
    var eventY = ie4? event.clientY : ns6? e.clientY : e.y;

    //Find out how close the mouse is to the corner of the window
    var rightedge=ie4? document.body.clientWidth-eventX : window.innerWidth-eventX;
    var bottomedge=ie4? document.body.clientHeight-eventY : window.innerHeight-eventY;

    //if the horizontal distance isn't enough to accomodate the width of the context menu
    if (rightedge < menuobj.contentwidth) {
	//move the horizontal position of the menu to the left by it's width
	menuobj.thestyle.left=ie4? document.body.scrollLeft+eventX-menuobj.contentwidth : ns6? window.pageXOffset+eventX-menuobj.contentwidth : eventX-menuobj.contentwidth;
    } else {
	//position the horizontal position of the menu where the mouse was clicked
	menuobj.thestyle.left=ie4? document.body.scrollLeft+eventX : ns6? window.pageXOffset+eventX : eventX;
    }

    //same concept with the vertical position
    if (bottomedge < menuobj.contentheight) {
	menuobj.thestyle.top=ie4? document.body.scrollTop+eventY-menuobj.contentheight : ns6? window.pageYOffset+eventY-menuobj.contentheight : eventY-menuobj.contentheight;
    } else {
        menuobj.thestyle.top=ie4? document.body.scrollTop+event.clientY : ns6? window.pageYOffset+eventY : eventY;
    }

    menuobj.thestyle.visibility = "visible";

    return false;
}

function contains_ns6(a, b) {
   if (b == null) {
	return true;
    }

    //Determines if 1 element in contained in another- by Brainjar.com
    while (b.parentNode) {
	if ((b = b.parentNode) == a) {
	    return true;
	}
    }

    return false;
}

function hidemenu(){
    if (window.menuobj) {
	menuobj.thestyle.visibility=(ie4||ns6)? "hidden" : "hide";
    }
}

function dynamichide(e){
    if (ie4 && !menuobj.contains(e.toElement)) {
	hidemenu();
    } else if (ns6 && e.currentTarget!= e.relatedTarget && !contains_ns6(e.currentTarget, e.relatedTarget)) {
	hidemenu();
    }
}

function delayhidemenu(){
    if (ie4||ns6||ns4) {
	delayhide=setTimeout("hidemenu()",500);
    }
}

function clearhidemenu(){
    if (window.delayhide) {
	clearTimeout(delayhide);
    }
}

function highlightmenu(e, state){
    if (document.all) {
	source_el = event.srcElement;
    } else if (document.getElementById) {
	source_el=e.target;
    }

    if (source_el.className == "menuitems") {
	source_el.id = (state == "on") ? "menumouseover" : "";
    } else {
	while (source_el.id != "popmenu") {
	    source_el = document.getElementById ? source_el.parentNode : source_el.parentElement;
	    if (source_el.className=="menuitems") {
		source_el.id=(state=="on")? "menumouseover" : "";
	    }
	}
    }
}

// --- END MENU CODE ---

/**
 * Set the action of a form to a new page
 */
function setFormAction(formName, formAction) {
    var theForm = eval('document.' + formName);
    theForm.action = formAction;

    return true;
}

/*
 * To check if the current screen can be excluded from checking for session active validity
 */

function canExcludeActiveSessionCheck(formName, submitValue) {
  var retvalue = 0;
  var excludeForms = ["login", "localLogin", "createUser", "createUserRequest",
                      "forcePasswordChangeForm", "filterOnStatusPlanningFolder", "usernameForm",
                      "exportItemsForm", "saveSearchOrFilter", "massUpdateArtifactsForm",
                      "selectTrackerColumns", "folderPreferenceNamePopUpForm", "searchTracker",
                      "searchDocuments", "searchWikiPages", "searchTasks", "searchPosts",
                      "myTaskProgress", "listPosts", "browseCategory", "searchForm", "addCategory",
                      "createAuthenticatedUser", "createSamlUser", "resetPassword", "importArtifactsForm"];
  var excludeActions = ["_filterRemove", "_folderPreferenceRemove", "_filterApply", "ViewCommits", "ViewSource"];

  retvalue = $j.inArray(formName, excludeForms);
  if(retvalue == -1) {
    retvalue = $j.inArray(submitValue, excludeActions);
  }

  return retvalue;
}

/**
 * This submit functionionality has been changed so that before submitting the form,
 * an ajax call will be made to the server to check if the session has expired or alive
 * However, the Login form & Set Site Mode will be exempted
 */
function submitForm(form, submitValue) {
    if ((typeof isHttpTest !== 'undefined' && isHttpTest) ||  canExcludeActiveSessionCheck(form.name, submitValue) > -1 ||
        canExcludeActiveSessionCheck(form.id, submitValue) > -1) {
        submitFormHandler(form, submitValue);
    } else {
        checkValidSessionAndSubmit(form, submitValue);
    }
}

/**
 * Submit a form with a given name.  The value of the 'sfsubmit' variable is set with the second parameter.
 */
function submitFormHandler(form, submitValue, xsrfToken) {
  // This is used to match the button
  if (form.name == "selectForumsForm" && submitValue == "Monitor") {
    monitorTypeModalPopup();
  } else {
    if (form.name == "myProjects" && submitValue == "delete") {
      form.action = "/sf/sfmain/do/listProjectGroupsAdmin";
      form.name = "listProjectGroupsAdmin";
    }
    if (form.name == "browseCategory" && submitValue == "searchCategory") {
      form.action = "/sf/sfmain/do/search";
    }

    var linkCall = "submitForm(";

    // At this point, we want to turn off this submit button
    for (var i = 0; i < document.links.length; i++) {
      var link;
        try {
          link = document.links[i];
          if (link.href.indexOf(linkCall) > 0) {
            link.href = 'javascript:void(0);';
          }
        }catch(error) {
          // Skip the error, possible to get invalid argument error in IE when link port is nonnumeric
        }
    }
    if (xsrfToken) {
        $j("input[name='_xsrftoken']").val(xsrfToken);
    }
    form.sfsubmit.value=submitValue;
    // later can be extended for addAttachment

    if ((form.name == "createDocument" || form.name =="editDocument" || form.name == "viewArtifactForm" || form.name == "createArtifactForm" || form.name == "createArtifactDependencyForm"
     || form.id == "createFieldForm" || form.id == "editFieldForm"  || form.name == "addAttachment"|| form.id == "editTrackerForm")  &&
        (submitValue == "SaveAndView" || submitValue == "Save" || submitValue == "submit")) {
     if ($j(form) && $j(form).areYouSure) {
      $j(form).areYouSure( {'silent':true} ); // By now, all validations are done. Suppress AYS and submit.
     }
      if (attachedFilesFormData.length > 0 || deletedFiles.length > 0) {
        artifactXHRCall(form,submitValue);
      } else {
        form.submit();
      }

    } else {
      if (form.name == "login") {
        // Since its a login attempt, clear session storage data
        sessionStorage.clear();
        if (!isHttpTest) {
          pwd = $j("input[name='password']").val();
          if (pwd !== undefined && pwd !== null & pwd !== "") {
            pwd = encrypt(pwd);
            $j("input[name='password']").val(pwd);
          }
        }
      }
      form.submit();
    }
  }
} // submitForm

function encrypt(password) {
  var iv = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);
  var salt = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);

  var aesUtil = new AesUtil(128, 1000);
  var ciphertext = aesUtil.encrypt(salt, iv, password);

  var aesPassword = (iv + "::" + salt + "::" + ciphertext);
  var password = btoa(aesPassword);
  return password;
}

/**
 * Submit a form with a given name.  The value of the 'sfsubmit' variable is set with the second parameter.
 * submit the form without voiding the button
 */
function submitFormNoVoidButtons(form, submitValue ) {
    form.sfsubmit.value=submitValue;
    form.submit();
} // submitForm

function artifactXHRCall(form,submitValue) {
  var http = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");
  var formData = new FormData();
  var percentUploaded = 0;
  formData.append("sfsubmit",submitValue);
  formData.append("attachmentsId",document.getElementById('attachmentsId').value);
  formData.append(document.getElementById("_xsrftoken").name,
  document.getElementById("_xsrftoken").value);
  for(var j = 0; j < deletedFiles.length; j++) {
    formData.append("deletedFileId[" + j + "]",deletedFiles[j]);
  }
  for(var i = 0; i < attachedFilesFormData.length; i++) {
    if (removedFileIndices.indexOf(i)  === -1) {
      formData.append("file[" + i + "]",attachedFilesFormData[i],attachedFilesFormData[i].name);
    }
  }
  http.open('POST', '/sf/tracker/do/uploadMultipleAttachments', true);
  var circleRightElem = jQuery("div.attachment .progress.blue .progress-right .progress-bar-circle ");
  var circleLeftElem = jQuery("div.attachment .progress.blue .progress-left .progress-bar-circle ");
  var progressValueElem = jQuery("div.progress-value");
  var timeStarted, timeRemainingSeconds, totalSizekB, quarterOfUploadSize;
  var closerToEnd = false;

  http.upload.addEventListener("progress", function(e) {
    if (!totalSizekB && !quarterOfUploadSize) {
        totalSizekB = e.total / 1024;
        quarterOfUploadSize = Math.round(e.total / 4);
    }

    percentUploaded = parseInt((e.loaded / e.total * 100));

    var seconds_elapsed = (new Date().getTime() - timeStarted.getTime()) / 1000;
    var bytes_per_second = seconds_elapsed ? e.loaded / seconds_elapsed : 0;
    var remaining_bytes = e.total - e.loaded;
    var seconds_remaining = seconds_elapsed ? Math.abs(remaining_bytes / bytes_per_second) : 1;
    seconds_remaining = seconds_remaining.toFixed(2);

    // Add animation to the element to rotate in speed based on the percent uploaded
    if (totalSizekB < 200) {
        if (circleLeftElem && circleRightElem && progressValueElem) {
            circleRightElem.css("animation", "loading-1 " + seconds_remaining + "s linear forwards");
            circleLeftElem.css("animation", "loading-2 " + seconds_remaining + "s linear forwards " + seconds_remaining + "s");
        }
    } else if (totalSizekB >= 200) {
        if (remaining_bytes <= quarterOfUploadSize) {
            closerToEnd = true;
        }
        if (!closerToEnd) {
           // add slow animation to match against percent upload.
           seconds_remaining = seconds_remaining * 2;
           circleRightElem.css("animation", "loading-1 " + seconds_remaining + "s linear forwards");
           circleLeftElem.css("animation", "loading-2 " + seconds_remaining + "s linear forwards " + seconds_remaining + "s");
        }
    }
    progressValueElem.html(percentUploaded + "%");
  }, false);

  http.onreadystatechange = function(e) {
    if (http.readyState == 4) {
      if(http.status == 200) {
        var json = JSON.parse(http.response);
        if(json.isSuccess) {
          form.attachmentsId.value = json.attachmentsKey;
          form.submit();
        } else {
          window.location = http.responseURL;
        }
      }
    }
  }

  http.send(formData);
  timeStarted = new Date();
  if (form.name == "createDocument" || form.name =="editDocument" ||
    form.name == "viewArtifactForm" || form.name == "createArtifactForm" ||
    form.name == "createArtifactDependencyForm" || form.name == "addAttachment") {
        jQuery("div.attachment").removeClass("hide");
  }
  return false;
}

function trim(inputString) {
   if (typeof inputString != "string") { return inputString; }
   var retValue = inputString;
   var ch = retValue.substring(0, 1);
   while (ch == " ") { // Check for spaces at the beginning of the string
      retValue = retValue.substring(1, retValue.length);
      ch = retValue.substring(0, 1);
   }
   ch = retValue.substring(retValue.length-1, retValue.length);
   while (ch == " ") { // Check for spaces at the end of the string
      retValue = retValue.substring(0, retValue.length-1);
      ch = retValue.substring(retValue.length-1, retValue.length);
   }
   return retValue; // Return the trimmed string back to the user
} // Ends the "trim" function

//function to trigger default action onclick of enter key.
function submitDefault(evt,form,submitValue,validate) {

   var e;
   if (ie4) {
         e = window.event;
   } else if (ns6 || ns4) {
         e = evt;
   }

    if (e && e.keyCode == 13) {
	if (validate == "true") {
	    var formName = form.name;
	    var methodName = "validate" + formName.charAt(0).toUpperCase() + formName.substring(1,formName.length);
	    var functionName = methodName + "(" + form.name + ")";
            if(eval(functionName)) {
		submitForm(form,submitValue);
	    }
	} else {
	    submitForm(form,submitValue);
	}
    }
}//End of submitDefault

//function to prevent default action onclick of enter key.
function disableOnEnterSubmit(evt) {

    var e;
    if (ie4) {
        e = window.event;
    } else if (ns6 || ns4) {
        e = evt;
    }

    return !(e && e.keyCode == 13);
}//End of noSubmitDefault

// function to submit a login form on click of the 'enter' key.
// When the enter key is clicked, we submit the form named "login"
function submitLoginOnEnter(evt) {
    if (ie4) {
         if (window.event && window.event.keyCode == 13) {
             submitForm(document.forms['login'],'submit');
         }
    } else if (ns6 || ns4) {
        if (evt && evt.which == 13) {
	    submitForm(document.forms['login'],'submit');
	}
    }
    // else: unknown browser, so we do nothing.
}//End of submitOnEnter

// Change the count number in a tab
function showCount(elementId, count) {
    var pageElement = document.getElementById(elementId);
    if (pageElement != null) {
	pageElement.innerHTML = count;
    }
}

//Functions for moving options from one select list to another list

function moveOneRight(lstFirst,lstSecond, noSelect) {
    for(var i=0;i<lstFirst.options.length;) {
        if(lstFirst.options[i].selected) {
            var opt=new Option(lstFirst.options[i].text,lstFirst.options[i].value);
            lstFirst.options[i]=null;
            lstSecond.options[lstSecond.options.length]=opt;
            opt.selected = true;
        } else {
            i++;
        }
    }

    if(lstSecond.options.length>1 && lstSecond.options[0].value=="" ) {
        lstSecond.options[0]=null;
    }

    sortList(lstFirst,false,false);
    if (!noSelect)  selectRight(lstSecond);
}

function moveAllRight(lstFirst,lstSecond, noSelect) {
    for(var i=0;i<lstFirst.options.length;)
    {
        var opt=new Option(lstFirst.options[i].text,lstFirst.options[i].value);
        lstSecond.options[lstSecond.options.length]=opt;
        lstFirst.options[i]=null;
    }

    if(lstSecond.options.length>1 && lstSecond.options[0].value=="" ) {
        lstSecond.options[0]=null;
    }

    sortList(lstFirst,false,false);
    if (!noSelect) selectRight(lstSecond);
}

function moveOneLeft(lstFirst,lstSecond) {
    if(lstSecond.options.length==1 && lstSecond.options[0].value=="" ) {
        lstSecond.options[0].selected=false;
        return;
    }

    for (var i=0;i<lstSecond.options.length;) {
        if (lstSecond.options[i].selected) {
            var opt=new Option(lstSecond.options[i].text, lstSecond.options[i].value);
            lstFirst.options[lstFirst.options.length]=opt;
            lstSecond.options[i]=null;
        } else {
            i++;
        }
    }

	sortList(lstFirst,false,false);

    selectRight(lstSecond);
}

function moveAllLeft(lstFirst,lstSecond) {
    if (lstSecond.options.length == 1 && lstSecond.options[0].value == "" ) {
        lstSecond.options[0].selected = false;
        return;
    }

    for (var i=0;i<lstSecond.options.length;) {
        var opt = new Option(lstSecond.options[i].text,lstSecond.options[i].value);
        lstFirst.options[lstFirst.options.length] = opt;
        lstSecond.options[i] = null;
    }
	sortList(lstFirst,false,false);

    selectRight(lstSecond);
}

function selectRight(lstSecond) {
    for(var i=0;i<lstSecond.options.length;i++) {
        lstSecond.options[i].selected = true;
    }
}

// Compare functions used internally by the SortList routine,
function ListCompareNums(a,b)
{
	var la = parseInt(a.split("{")[0]);
	var lb = parseInt(b.split("{")[0]);
	if (la < lb) return -1;
	if (la > lb) return 1
	return 0;
}
function ListCompareText(a,b)
{	var la = a.toLowerCase();
	var lb = b.toLowerCase();
	if (la < lb) return -1;
	if (la > lb) return 1
	return 0;
}

// Quite Fast way of sorting big option lists
function sortList(Combo, IntSort, UseVals)
{
	var cmbText = new Array(Combo.options.length);
	var cmbItems;

	// get copy of
	for (x=0; x<cmbText.length; x++)
		cmbText[x]=(UseVals)?Combo.options[x].value + "{" + Combo.options[x].text:Combo.options[x].text + "{" + Combo.options[x].value;

	if (IntSort)
		cmbText.sort(ListCompareNums);
	else
		cmbText.sort(ListCompareText);

	//rebuild main list, but don't redimension it
	for (x=0; x<cmbText.length; x++){
		cmbItems = cmbText[x].split("{");
		Combo.options[x].text=(UseVals)?cmbItems[1]:cmbItems[0];
		Combo.options[x].value=(UseVals)?cmbItems[0]:cmbItems[1];
	}
}

//end of field picker functions.


//used by artifacts filter to capture the enter key on the text input fields
function captureEnterAndSubmit(e, formName, formAction,form, submitValue) {

    if (!e) {
	if (window.event) {
	    //Internet Explorer
	    e = window.event;
	} else {
	    return;
	}
    }
    if (typeof( e.keyCode ) == 'number') {
	//DOM
	e = e.keyCode;
    } else if (typeof( e.which ) == 'number') {
	//NS 4 compatible
	e = e.which;
    } else if (typeof( e.charCode ) == 'number') {
	//also NS 6+, Mozilla 0.9+
	e = e.charCode;
    } else {
	//total failure, we have no way of obtaining the key code
	//nothing is made
	return;
    }
    if (e == 13) {
    if (browser.isIE) {
	    if (document.getElementById('datePatternPlaceHolder') != undefined) {
	        replacePlaceHolderValue('_filter!!date', document.getElementById('datePatternPlaceHolder').value);
	        }
    }
	setFormAction(formName, formAction) && submitForm(form , submitValue);
    }
}

function changeVisibility(state)  {
    var v =   document.getElementById("length_error_title_span");
    if(state=="view"){
	v.style.display="block";
    }
    else{
	if(state=="hide"){
	    v.style.display="none";
	}
    }
}

function textCounter(field,maxlimit) {
    if (field.value.length >= maxlimit) {
	changeVisibility("view");
    }
    else {
	changeVisibility("hide");
    }
}

//detect if we are using IE

function isIEVersion(version) {
    localVersion = 0
    if (navigator.appVersion != null && navigator.appVersion.indexOf("MSIE") != -1)  {
        temp = navigator.appVersion.split("MSIE")
        localVersion = parseFloat(temp[1])
    }

    if (localVersion == version){
        return true
    }
    return false
}

var fixIframeObj;

function createIEFix(){
var fixIframeObj;
	if(isIEVersion(6)){
		fixIframeObj = document.createElement('IFRAME');
                fixIframeObj.setAttribute('src', '.');
                fixIframeObj.id='blockIframeLayer'
                fixIframeObj.style.filter = 'alpha(opacity=0)';
		fixIframeObj.style.position = 'absolute';
		fixIframeObj.style.zIndex = '0';
                document.body.appendChild(fixIframeObj);
        }
return fixIframeObj;

}

// pce: start
function page_addcomponent(pageFolderPath, componentType) {
    this.location="/sf/page/do/createComponent/" + pageFolderPath + "?component_type=" + componentType;
}

// variables used for reordering components
var numberOfComponents;
var slotMatrix = new Array();

// set the number of components that will be on the page
function setNumberOfComponents(count) {
    numberOfComponents = count;
}

// put a component id at a new display position 
function updatePageComponentMatrix(position, componentId) {
    slotMatrix[position] = componentId;
}


function getObject(id) {
  if (ie4) {
    return document.all[id];
  } else {
    return document.getElementById(id);
  }
}

// swap the position of 2 page components in the browser.
// this is called after the ajax processes
function processMove(oldIndex, newIndex) {

    // update the html
    var newslot = getObject("componentslot_"+(newIndex));
    var oldslot = getObject("componentslot_"+(oldIndex));
    var tempslot = newslot.innerHTML;
    newslot.innerHTML = oldslot.innerHTML;
    oldslot.innerHTML = tempslot;

    //update the array
    var tempId = slotMatrix[newIndex];
    slotMatrix[newIndex] = slotMatrix[oldIndex];
    slotMatrix[oldIndex] = tempId;

    // fix arrow icons
    var newslot_up_arrow = getObject("moveup_" + slotMatrix[newIndex]);
    var newslot_down_arrow = getObject("movedown_" + slotMatrix[newIndex]);
    var oldslot_up_arrow = getObject("moveup_" + slotMatrix[oldIndex]);
    var oldslot_down_arrow = getObject("movedown_" + slotMatrix[oldIndex]);

    newslot_up_arrow.className = "uparrow";
    oldslot_up_arrow.className = "uparrow";
    if(newIndex <= 0)
        newslot_up_arrow.className = "uparrowgray";
    if(oldIndex <= 0)
        oldslot_up_arrow.className = "uparrowgray";

    newslot_down_arrow.className = "downarrow";
    oldslot_down_arrow.className = "downarrow";
    if(newIndex >= numberOfComponents - 1)
        newslot_down_arrow.className = "downarrowgray";
    if(oldIndex >= numberOfComponents - 1)
        oldslot_down_arrow.className = "downarrowgray";
}

// move a component up 
function moveUp(comp_id, pageFolderPath, msg) {
  for (i=0; i<slotMatrix.length; i++) {
    if(comp_id ==(slotMatrix[i])) {
        if(i > 0) {
            reorderPageComponents(pageFolderPath, i, 'up', msg);
            return;
        }
    }
  }
}

// move a component down
function moveDown(comp_id, pageFolderPath, msg) {
  for (i=0; i<slotMatrix.length; i++) {
    if(comp_id ==(slotMatrix[i])) {
        if(i < numberOfComponents - 1) {
            reorderPageComponents(pageFolderPath, i, 'down', msg);
            return;
        }
    }
  }
}

// process component reorder through ajax
function reorderPageComponents(pageFolderPath, compIndex, direction, msg) {
    var compId = slotMatrix[compIndex];
    // remove the component_ prefix from compId
    compId = compId.substring(10, compId.length);
    var newIndex = (direction == "up") ? compIndex-- : compIndex++;
    var url = "/sf/page/do/reorderComponent/" + pageFolderPath + "/" + compId + "?dir=" + direction;
    var http = window.XMLHttpRequest ? new XMLHttpRequest() :
        new ActiveXObject("Microsoft.XMLHTTP");
    http.open('get', url);
    http.onreadystatechange = function() {
      if (http.readyState == 4) {
        var response = http.responseText;
        if(response.match("success")) {
            processMove(compIndex, newIndex);
        } else {
            alert(msg);
        }
      }
    };
    http.send(null);
    return false;
}

// process edit component through ajax
// currently not used
function editComponent(pageFolderPath, componentId, formId)
{
   // TODO: will need to escape text values.
    var obj = document.getElementById(formId);
    var getstr = "?";
    var newTitle="";
    for (i=0; i<obj.childNodes.length; i++) {
       if (obj.childNodes[i].tagName == "INPUT") {
          if (obj.childNodes[i].type == "text") {
             getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
             //TODO: this is just grabbing any text field needs to be verify this is the title field!
             newTitle=obj.childNodes[i].value;
          }
          if (obj.childNodes[i].type == "checkbox") {
             if (obj.childNodes[i].checked) {
                getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
             } else {
                getstr += obj.childNodes[i].name + "=&";
             }
          }
          if (obj.childNodes[i].type == "radio") {
             if (obj.childNodes[i].checked) {
                getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
             }
          }
       }
       if (obj.childNodes[i].tagName == "SELECT") {
          var sel = obj.childNodes[i];
          getstr += sel.name + "=" + sel.options[sel.selectedIndex].value + "&";
       }

    }
    makeEditComponentRequest(pageFolderPath, componentId, getstr, newTitle);
}

function makeEditComponentRequest(pageFolderPath, componentId, arguments, newTitle)
{
    var url = "/sf/page/do/editComponent/" + pageFolderPath + arguments;
    var http = window.XMLHttpRequest ? new XMLHttpRequest() :
        new ActiveXObject("Microsoft.XMLHTTP");
    http.open('get', url);
    http.onreadystatechange = function() {
      if (http.readyState == 4) {
        var response = http.responseText;
        if(response.match("success")) {
            editSuccessful(componentId, newTitle);
        } else {
            alert("error");
        }
      }
    };
    http.send(null);
    return false;
}

function editSuccessful(componentId, newTitle ) {
    alert("it worked! "+ newTitle);
}

function toggleDisplayUsingIds(imageId, baseId) {
    var image = null;
    if (imageId) {
        image = document.getElementById(imageId);
    }
    toggleDisplay(image, baseId);
}

function toggleDisplayNoImage(baseId) {
    var tableObject = document.getElementById(baseId);

    if (tableObject.style.display == 'table' ||
            tableObject.style.display == 'block' ||
            tableObject.style.display == '') {
        tableObject.style.display = 'none';
    } else {
        if (document.all) {
            tableObject.style.display = '';
        } else {
            tableObject.style.display = '';
        }
    }
}

// sets the focus of a field, if the panel is visible
function toggleFormFocus(fieldId, panelId) {
    var panelObject = document.getElementById(panelId);

    if (panelObject.style.display == 'none' )
        return;
    var fieldObject = document.getElementById(fieldId);
    fieldObject.focus();
}

// pce: end


//function that checks the element to see if the reload has failed (if that is the case, the action should have
// responded with the string 'failed'. If it has, reload the current page
//(used for AJAX actions)
   function checkResult(element) {
     if ('failed' == element.innerHTML) {
       window.location.reload();
     }
   }

/**
 * Parses the url and return an array of the url params.  Each entry of the array is an array of two entries (param
 * name and param value).
 * @param url
 * @return array of params
 */
function parseUrlParams(url) {
  var params = new Array();
  var paramStartIndex = url.indexOf("?");
  if (paramStartIndex != -1) {
    // means there are params
    var paramStr = url.substring(paramStartIndex + 1);
    var paramPairs = paramStr.split("&");
    for (var i=0; i<paramPairs.length; i++) {
      var keypair = paramPairs[i].split("=");
      // use decodeURI since 'unescape' does not work properly for non-ASCII characters
      for (var j=0; j<keypair.length; j++) {
        keypair[j] = decodeURI(keypair[j]);
      }
      params[params.length] = keypair;
    }
  }
  return params;
}

/* firefox doesn't always update the status bar after loading flash. */
function firefoxFinishLoadHack(){
  setTimeout(loadImgHack, 1500);
}

function clearImgHack() {
  var pageLoadedEl = document.getElementById('PageLoaded')
  if (pageLoadedEl) {
    pageLoadedEl.innerHTML=" ";
  }
}

function loadImgHack(){
  var pageLoadedEl = document.getElementById('PageLoaded')
  if (pageLoadedEl) {
    pageLoadedEl.innerHTML='<img src="/sf-images/misc/white.gif" alt=""></img>';
  }
}

function printWindowWithDelay() {
  setTimeout("if (window.print) window.print();", 100);
}

function checkEmptyContent(fieldId, errorMsg) {
  var content;
  content = document.getElementById(fieldId).value;
  if(content == "") {
    alert(errorMsg);
    return false;
  }
  return true;
}


/**
 * Placeholder attribute does not work in IE so add default values to the elements.
 * @param id, id of the element
 * @param placeHolderaValue, the value to be set
 */
function addPlaceHolder(id, placeHolderValue) {
    if (browser.isIE) {
        var $j = jQuery.noConflict();
        $j(document).ready(function () {
            var element = document.getElementById(id);
            if (element != null) {
		// this check is to make sure that, if the field already has a value retain it.
                var firstTimeValue = $j(element).val() == "" ? placeHolderValue : $j(element).val();
                $j(element).val(firstTimeValue);

                $j(element).focus(function () {
                    var currentVal = $j(this).val();
                    if (currentVal == placeHolderValue) {
                        $j(this).val("");
                    } else {
                        $j(this).select();
                    }
                    return false;
                });

                $j(element).blur(function () {
                    if ($j(this).val() == "") {
                        $j(this).val(placeHolderValue);
                    }
                    return false;
                });
            }
        });
    }
}

/**
 * Replace place holder value to empty string for IE,
 * to avoid submitting default place holder value.
 * Replaces if element value matches place holder value
 * @param id, id or id pattern of the element
 * @param placeHolderValue, the default place holder value
 */
function replacePlaceHolderValue(id, placeHolderValue) {
    if (browser.isIE) {
        var $j = jQuery.noConflict();
        $j(document).ready(function () {
        $j('#filter').find('input').each(function() {
            if ($j(this).attr('id') && $j(this).attr('id').indexOf(id) == 0 && $j(this).val() === placeHolderValue) {
                $j(this).val('');
            }
        });
        });
    }
}

/**
 * Applies radial gradient effect for the given array of colors
 * to be used in highcharts based pie charts.
 * @param colors - array of colors
 */
function getPieGradient(colors) {
    return (window.Highcharts ? Highcharts : window.opener.Highcharts).map(colors, function (color) {
        return {
            radialGradient: {
                cx: 0.5,
                cy: 0.5,
                r: 0.7
            },
            stops: [
                [0, color],
                [1, (window.Highcharts ? Highcharts : window.opener.Highcharts).Color(color).brighten(-0.1).get('rgb')] // darken
            ]
        };
    });
}

/**
 * Function to calculate the highcharts data div width. This is required to be called only
 * in case of preview on the Add Component -> Tracke Metrics page.
 *
 * Note that this can be avoided if the preview page is rid of using html <table> for layout
*/
function setChartContentDivWidth(chartType, chartPreviewDivSelector, chartDataDivElement) {
	var offSet = 10;
	if(chartType !== 'burndown') {
		// Other than burndown chart, legend is present for remaining two charts. i.e open vs close, open by prio
		var legendSelector = "#" + chartPreviewDivSelector +" .legend";
		offSet += jQuery(legendSelector).width();
	}
	chartDataDivElement.width(jQuery('#'+chartPreviewDivSelector).width() - offSet);
}

/**
 * Submit a form with a given name, only if the user confirms the action
 */
function submitFormAfterConfirmation(form, message) {
  var submitAction = confirm(message);
  if (submitAction) {
    submitForm(form, 'submit');
  }
} // End of submitFormAfterConfirmation

// show the help contents
function showHelpContents() {
    // First, close the help menu
    closeMenu(activeButton);
    window.open(baseHelp + "/index.html", 'help', 'resizable=yes,toolbar=yes,status=yes,scrollbars=yes,location=yes,resizeable=yes,width=800,height=600');
 }

// Show Eclipse Help without any closemenu interactions (for Wiki)
function showHelpNoMenu(topic) {
    window.open(baseHelp + topic, 'help', 'resizable=yes,toolbar=yes,status=yes,scrollbars=yes,location=yes,resizeable=yes,width=800,height=600');
}

$j(document).ready(function() {
  initTooltip();
  // Set file name
  $j('input[type=file]').change(function(e){
    setFileName(this);
  });

  // Loop through calendar image and set additional class for input type calendar.
  $j('.calendar').each(function(i, cal) {
    var inputId = $j(cal).attr('for');
    inputId = replaceId(inputId);
    $j(inputId).addClass('cal-icon');
    // Turn off auto-complete for calendar input field.
    $j(inputId).attr('autocomplete', 'off');
    $j(document).on("click", inputId, function() {
      return calShow($j(inputId).attr('id'));
  });
  });
});

// Set file name next to input file type.
function setFileName(input) {
  //hide the struts errors
  $j("#err_attachment").hide();

  var prohibitedFilesTypes = $j("input[name=prohibitedFileTypes]").val();
  var prohibitedFilesTypesErrorMessage = $j("input[name=prohibitedFileTypesErrorMess]").val();

  var filename = $j(input).val().split('\\').pop(); 
  var files;
  files=input.files;

  var isRestricted = false;
  var isZeroSizeFile = false;
  if (files[0].size == 0) {
    isZeroSizeFile = true;
  }
  if (filename && filename !== "") {
    if (prohibitedFilesTypes !== undefined &&
          prohibitedFilesTypes !== null && prohibitedFilesTypes !== "") {
      prohibitedFilesTypesArray = prohibitedFilesTypes.split(",");
      fileExt = filename.slice((filename.lastIndexOf(".") - 1 >>> 0) + 2);
      $j.each(prohibitedFilesTypesArray, function(key, value) {
          if (value.toLowerCase() == fileExt.toLowerCase()) {
              $j('#file').val('');
              isRestricted = true;
          }
      });
    }
  if (isRestricted || isZeroSizeFile) {
    if (isRestricted) {
      alert(prohibitedFilesTypesErrorMessage);
    } else if (isZeroSizeFile) {
        if (typeof emptyFileErrMsg !== 'undefined') {
          alert(emptyFileErrMsg);
        }
      }
      $j(input).val('');
      $j(input).parent().find('.selected-file').html("");
      $j(input).parent().find('.selected-file').attr("title", "");
      if ($j('form[name="createDocument"]').length > 0 || $j('form[name="editDocument"]').length > 0 ) {
        attachedFilesFormData.pop();
      }
  } else {
         if ($j('form[name="createDocument"]').length > 0 || $j('form[name="editDocument"]').length > 0 ) {
           attachedFilesFormData[0]=files[0];
         }
         $j(input).parent().find('.selected-file').html(filename);
         $j(input).parent().find('.selected-file').attr("title", filename);
    }
  } else {
      $j(input).parent().find('.selected-file').html("");
      $j(input).parent().find('.selected-file').attr("title", "");
  }
}

// Replaces special characters in id
function replaceId(inputId) {
  return "#" + inputId.replace( /(\#|\!|\_])/g, "\\\$1" );
}

// Initialize bootstrap tooltip
function initTooltip() {
  $j("[data-toggle='tooltip']").tooltip();
}

// Hack to position the yui menu for rows selection.
function setMenuPosition(elem) {
  if ($j(elem).attr('id') === 'ChooseColumns') {
    if (!$j("#configureTableMenu").css('marging-top') &&
        ($j("#configureTableMenu").offset().top < $j("#ChooseColumns").offset().top)) {
      $j("#configureTableMenu").css('margin-top', '-2px');
    }
  };
}

/*
 * The following methods are called in Create/Edit Document screen during Onload & Lock Checkbox onclick
 * When the screen is loaded checkDocumentLockFieldsOnLoad will be called which will enable/disable 
 * Download restricted & Allow force unlock checkboxes
 * When the user enables on the Prevent other users from Edit checkbox, the Allow force unlock will be automatically checked
 * and the Download restricted checked will be unchecked.  However The user can uncheck these checkboxes 
 * depending on the requirement
 */

function checkDocumentLockFieldsOnChange(element) {
  checkDocumentLockFieldsOnLoad(element);
  if (element.checked) {
    document.getElementById('downloadRestricted').checked = false;
    document.getElementById('allowForceUnlock').checked = true;
  } else {
    document.getElementById('downloadRestricted').checked = false;
    document.getElementById('allowForceUnlock').checked = false;
  }
}

function checkDocumentLockFieldsOnLoad(element) {
  if (element.checked) {
    document.getElementById('downloadRestricted').disabled = false;
    document.getElementById('allowForceUnlock').disabled = false;
  } else {
    document.getElementById('downloadRestricted').disabled = true;
    document.getElementById('allowForceUnlock').disabled = true;
  }
}

/*
 * This method is used to open the clone pop up for the artifact
 * in the list artifacts page. In both tracker and planning folder view.
 */
function openClonePopup(projectPath, artifactId, folderId, folderPath, hasCreatePermission, returnUrlKey) {
    var scope = angular.element(document.getElementById('cloneArtifact')).scope();
    scope.openClonePopup(projectPath, artifactId, folderId, folderPath, hasCreatePermission, returnUrlKey);
}

// Get the hidden fields and visible fields through ajax call and hide and show the respective fields
function hideTransitionHiddenFields(folderPath, artifactId, isStatusChange, last_status_selected) {
  // for hidden fields
  var statusValue = $j('#selectedStatus').find("option:selected").text();
    if (folderPath) {
    var queryParam;
    if (artifactId) {
      queryParam = "?toStatus=" + statusValue + "&artifactId=" + artifactId;
    } else {
      queryParam = "?toStatus=" + statusValue;
    }
    var handlerURL = "/sf/tracker/do/getHiddenFields/" +  folderPath + queryParam;

    $j.ajax( {
      url : handlerURL,
      dataType : 'json',
      success : function(response) {
        var hiddenFieldAlertMsg = response.hiddenFieldAlertMsg;
        var hiddenFields = response.hiddenFields;
        var autoPopulateFields = response.autoPopulateList;
        if (isStatusChange && hiddenFieldAlertMsg && hiddenFields.length > 0) {
          var isChangeOk = window.confirm(hiddenFieldAlertMsg);
          if (!isChangeOk && last_status_selected) {
            $j('#selectedStatus').val(last_status_selected);
            markAsTransitionRequiredField('true');
            return;
          }
        }
        for (i =0; i < hiddenFields.length; i++) {
          if ($j('#fieldId_' + hiddenFields[i])) {
            $j('#fieldId_' + hiddenFields[i]).hide();
          }
        }

        var instructionBar = document.getElementById('hidden_instruction');
        if (hiddenFields.length > 0) {
            instructionBar.style.display="";
        } else {
            instructionBar.style.display="none";
        }
        var visibleFields = response.visibleFields;
        for (i =0; i < visibleFields.length; i++) {
          if ($j('#fieldId_' + visibleFields[i])) {
            $j('#fieldId_' + visibleFields[i]).show();
          }
        }
        if (isStatusChange) {
          autoPopulateArtifactFields(autoPopulateFieldArray, artifactId, folderPath, true);
        }
        autoPopulateFieldArray = [];
        if (autoPopulateFields) {
          autoPopulateArtifactFields(autoPopulateFields, artifactId, folderPath, false);
        }
      },
      cache : false,
      async : false
    });
  }
}

function autoPopulateArtifactFields(autoPopulateFields, artifactId, folderPath, storeValues) {
  for (i = 0; i < autoPopulateFields.length; i++) {
    var autoPopulateField = autoPopulateFields[i];
    if (autoPopulateField.fieldDisplayType === 'DROPDOWN') {
      if (autoPopulateField.fieldName === 'assignedTo') {
        var assignedToUser = angular.copy(autoPopulateField.values[0]);
        if (assignedToUser && assignedToUser.id && assignedToUser.name) {
          var controllerScope = angular.element(document.getElementById('assignedTo')).scope();
          var oldSelectedUser = angular.copy(controllerScope.selectedUser);
          controllerScope.updateUser(assignedToUser);
          controllerScope.$apply();
          autoPopulateField.values[0] = oldSelectedUser;
        }
      } else if(autoPopulateField.fieldName === 'reportedInRelease' ||
                autoPopulateField.fieldName === 'resolvedInRelease') {
          var reportedInRelease = angular.copy(autoPopulateField.values[0]);
          if (reportedInRelease) {
              var controllerScope = angular.element(document.getElementById('release_' + autoPopulateField.fieldName)).scope();
              autoPopulateField.values[0] = {value : controllerScope.releaseId};
              controllerScope.releaseId = reportedInRelease.value;
              controllerScope.releases();
          }
      } else {
        var selectedValue = angular.copy(autoPopulateField.values[0].value);
        autoPopulateField.values[0].value = $j('#fieldId_' + autoPopulateField.fieldId + ' select').val();
        if (autoPopulateField.parentId !== undefined) {
           loadValidValues(autoPopulateField.fieldId, folderPath, autoPopulateField.values[0].value, true);
        }
        $j('#fieldId_' + autoPopulateField.fieldId + ' select').val(selectedValue);
      }
    } else if (autoPopulateField.fieldDisplayType === 'TEXT' || autoPopulateField.fieldDisplayType === 'DATE') {
      var selectedValue = angular.copy(autoPopulateField.values[0].value);
      var inputField = $j('#fieldId_' + autoPopulateField.fieldId + ' input');
      inputField = inputField.length > 0 ? inputField : $j('#fieldId_' + autoPopulateField.fieldId + ' textarea');
      autoPopulateField.values[0].value = inputField.val();
      inputField.val(selectedValue);
    } else if (autoPopulateField.fieldDisplayType === 'MULTISELECT') {
      var selectedValues = angular.copy(autoPopulateField.values);
      if (selectedValues && selectedValues.length > 0) {
        var oldValues = $j('#fieldId_' + autoPopulateField.fieldId).val();
        var values = [];
        if (oldValues) {
          $j.each(oldValues, function(i, e) {
            values.push({value : e});
          });
        }
        autoPopulateField.values = values;
        $j.each(selectedValues, function(i,e){
          $j('#fieldId_' + autoPopulateField.fieldId + ' select option[value=' + e.value + ']').prop("selected", true);
        });
      } else {
        $j('#artifactField_' + autoPopulateField.fieldId).val([]);
      }
    } else if (autoPopulateField.fieldDisplayType === 'FOLDER') {
      var folder = angular.copy(autoPopulateField.values[0]);
      var oldFolder = {};
      if (autoPopulateField.fieldName === 'team') {
        oldFolder.name = $j('#assignedTeamDisplay').text() ? $j('#assignedTeamDisplay').text().trim() : "";
        oldFolder.id = $j('#assignedTeam').val();
        $j('#assignedTeamDisplay').text(folder.name);
        $j('#assignedTeam').val(folder.id);
      } else {
        if (artifactId) {
          oldFolder.name = $j('.pf-node-assigned').text() ? $j('.pf-node-assigned').text().trim() : "";
          $j('.pf-node-assigned').text(folder.name);
        } else {
          oldFolder.name = $j('#assignedPlanningFolderDisplay').text() ? $j('#assignedPlanningFolderDisplay').text().trim() : "";
          $j('#assignedPlanningFolderDisplay').text(folder.name);
        }
        oldFolder.id = $j('#assignedPlanningFolder').val();
        $j('#assignedPlanningFolder').val(folder.id);
      }
      autoPopulateField.values[0] = oldFolder;
    } else if (autoPopulateField.fieldDisplayType === 'USER') {
      var selectedValues = angular.copy(autoPopulateField.values);
      var userField = document.querySelector('input[name="_FullName_flexFields(' + autoPopulateField.fieldId +')"]')
      var fieldScope = angular.element(userField).scope().$parent;
      var oldUsers = [];
      if (fieldScope.userNames && fieldScope.userIds && fieldScope.userNames.length === fieldScope.userIds.length) {
        for (i =0; i < fieldScope.userNames.length; i++) {
          oldUsers.push({key : fieldScope.userNames[i], value : fieldScope.userIds[i]});
        }
      }
      autoPopulateField.values = oldUsers;
      fieldScope.setSelectedOptions(selectedValues, false);
      fieldScope.$apply();
    }
    if (!storeValues) {
      autoPopulateFieldArray.push(autoPopulateField);
    }
  }
}

function copyUrl(artifactId) {
     $j('#' + artifactId + "_copy_url").show().css({"background-color":"#272525","display": "block",
     "position": "absolute",
     "z-index": "10",
     "height": "30px",
     "color" : "white",
     "padding" : "6px 8px 8px",
     "letter-spacing" : "0px",
     "left" : "0px",
     "top" : "30px",
     "font-size" : "14px",
     "text-align" : "center",
     "font-family" : "'SourceSansPro-Regular', Helvetica, Arial, sans-serif",
     "font-weight" : "normal",
     "border-radius" : "5px"}).delay(1000).fadeOut();
}

function printArtifact(path, artifid) {
  NewWindow('/sf/tracker/do/printArtifact/' + path + '/' + artifid, 'printArtifact', 800, 750, 'yes');
}


function makeDfcpWrapperDiv() {
    return $j('<div id="dfcp_wrapper"></div>');
}

function dfcpCancelBtnEventHandler() {
    document.getElementById('dfcp_outer').setAttribute('style', "display:none;");
    var wrapper = document.getElementById('dfcp_wrapper');
    if (wrapper.hasOwnProperty('remove')) {
        wrapper.remove();
    } else {
        if (wrapper.parentNode !== null) {
            wrapper.parentNode.removeChild(wrapper);
        }
    }
}

function appendDfcpWrapper(wrapper) {
    $j('.modal-body').append(wrapper);
}

function showDfcPopup() {
    document.getElementById('dfcp_outer').removeAttribute('style');
}

function registerDfcpCancelAndCloseBtnHandler() {
    document.getElementById('dfcp_cancel_btn').onclick = dfcpCancelBtnEventHandler;
    document.getElementById("dfcp_close_btn").onclick = dfcpCancelBtnEventHandler;
}

function makeDfcpRepoListSeparatorDiv() {
    return $j('<div class="row delete-discussion-forum-used-by-repo-list-separator"></div>');
}

function showCanNotDeleteForumPopUp(forumIdToInfo, forumUsages, selectedForums) {
    function disableDeleteButton() {
        document.getElementById('dfcp_delete_btn').disabled = true;
    }

    function enableCanNotDelete() {
        document.getElementById('dfcp_can_not_delete').removeAttribute('style');
        document.getElementById('dfcp_delete_warning').setAttribute('style', "display:none;");
    }

    var wrapper = makeDfcpWrapperDiv();
    var toBeDeleted = [];
    for (var i = 0; i < selectedForums.length; i++) {
        var forum = selectedForums[i];
        if (forumUsages.hasOwnProperty(forum.id)) {
            toBeDeleted.push(forum);
        }
    }
    for (var i = 0; i < toBeDeleted.length; i++) {
        var forum = toBeDeleted[i];
        if (i > 0) {
            wrapper.append($j('<div class="row delete-discussion-forum-used-by-forum-separator"></div>'));
        }
        var forumHeader = '<div class="row"><div class="col-md-12">' + document.getElementById('__usedByRepositoryPrefix__').innerText + ' <b>"' + forum.title + '"</b>:</div></div>';
        wrapper.append($j(forumHeader));
        wrapper.append(makeDfcpRepoListSeparatorDiv());
        var repositoriesWithPermission = 0;
        var usages = forumUsages[forum.id]['usages'];
        usages.sort(function (a, b) {
            return a.repositoryName.localeCompare(b.repositoryName);
        });
        for (var j = 0; j < usages.length; j++) {
            var repo = usages[j];
            var linkToRepo = 'ctf/code/' + repo.projectPath + '/git/' + repo.repositoryPath;
            var linkToRepoSettings = linkToRepo + '/settings?tab=notifications';
            var linkToRepoView = linkToRepo + '/tree';
            var repoItem = '<div class="row delete-discussion-forum-used-by-repository">' +
                '<div class="col-md-12">' +
                '<label class="delete-discussion-forum-text"><a href="' + linkToRepoView + '" target="_self">' + repo.repositoryName + '</a>' +
                '<span>  (<a href="' + linkToRepoSettings + '" target="_self">settings</a>)</span>' +
                '</label> </div> </div>';
            wrapper.append($j(repoItem));
            repositoriesWithPermission++;
        }
        var noPermissionRepoCount = parseInt(forumUsages[forum.id]['noPermission']);
        if (noPermissionRepoCount > 0) {
            var prefix = document.getElementById('__usedByRepositoryButNoPermissionPrefix__').innerText;
            var suffix = repositoriesWithPermission > 0 ?
                document.getElementById('__usedByRepositoryButNoPermissionSuffix__').innerText
                : document.getElementById('__usedByOnlyNoPermissionRepositoriesSuffix__').innerText;
            var noPermissionRepoDiv = '<div class="row delete-discussion-forum-used-by-repository">' +
                '<div class="col-md-12 delete-discussion-forum-used-by-no-permission-repository">' +
                '<label class="delete-discussion-forum-text">' + prefix + ' (' + noPermissionRepoCount + ') ' + suffix + '</label>' +
                '</div></div>';
            wrapper.append($j(noPermissionRepoDiv));
        }
    }
    registerDfcpCancelAndCloseBtnHandler();
    appendDfcpWrapper(wrapper);
    enableCanNotDelete();
    disableDeleteButton();
    showDfcPopup();
}

function showForumDeleteWarningPopup(forumIdToInfo, toBeDeleted, p1, p2) {
    function enableDeleteButton() {
        document.getElementById('dfcp_delete_btn').disabled = false;
    }

    function enableDeleteWarning() {
        document.getElementById('dfcp_can_not_delete').setAttribute('style', "display:none;");
        document.getElementById('dfcp_delete_warning').removeAttribute('style');
    }

    var wrapper = makeDfcpWrapperDiv();
    var followingForumsHeader = '<div class="row"><div class="col-md-12">' + document.getElementById('__deleteWarningForumList__').innerText + '</div></div>';
    wrapper.append($j(followingForumsHeader));
    wrapper.append(makeDfcpRepoListSeparatorDiv());
    for (var i = 0; i < toBeDeleted.length; i++) {
        var forum = toBeDeleted[i];
        var linkToForum = '/sf/discussion/do/listTopics/' + forum.projectPath + '/' + forum.folderPath;
        var forumDiv = '<div class="row delete-discussion-forum-used-by-repository">' +
            '<div class="col-md-12">' +
            '<label class="delete-discussion-forum-text"><a href="' + linkToForum + '" target="_self">' + forum.title + '</a></label>' +
            '</div>' +
            '</div>';
        wrapper.append($j(forumDiv));
    }
    registerDfcpCancelAndCloseBtnHandler();
    appendDfcpWrapper(wrapper);
    enableDeleteWarning();
    enableDeleteButton();
    document.getElementById('dfcp_delete_btn').onclick = function () {
        submitForm(p1, p2);
        dfcpCancelBtnEventHandler();
    };
    showDfcPopup();
}

function showForumDeleteConfirmPopup(p1, p2) {
    var forumIdToInfoMap = JSON.parse(document.getElementById('__forumIdToInfo__').innerText);
    var forumUsages = JSON.parse(document.getElementById('__forumUsages__').innerText);
    var selectedForums = [];
    var items = document.getElementsByName('_listItem');
    for (var i = 0; i < items.length; i++) {
        var forum = items[i];
        if (forum.checked) {
            var forumInfo = forumIdToInfoMap[forum.id];
            selectedForums.push({
                id: forum.id,
                title: forumInfo['title'],
                projectPath: forumInfo['projectPath'],
                folderPath: forumInfo['folderPath']
            });
        }
    }
    selectedForums.sort(function (a, b) {
        return a.title.localeCompare(b.title);
    });
    var atLeastOneUsed = false;
    for (var i = 0; i < selectedForums.length; i++) {
        var forum = selectedForums[i];
        atLeastOneUsed = forumUsages.hasOwnProperty(forum.id) && forumUsages[forum.id]['usages'].length > 0;
        if (atLeastOneUsed) {
            break;
        }
    }

    if (atLeastOneUsed) {
        showCanNotDeleteForumPopUp(forumIdToInfoMap, forumUsages, selectedForums);
    } else {
        showForumDeleteWarningPopup(forumIdToInfoMap, selectedForums, p1, p2);
    }
}
