/*@COPYRIGHT
 *CollabNet TeamForge(r) Enterprise Edition
 *Copyright 2007-2017 CollabNet, Inc. All rights reserved.
 *http://www.collab.net
 *COPYRIGHT@
 */

/**
 * Module declaration 'ArtifactEditor'
 */
ArtifactEditor = new ArtifactEditorHandler(WebClient);

/*
 * To handle session timeout scenario
 */
var vUrl, vArtifactData, vArtifactCreateEditor;
var vArtifactId, vUpdateData, vArtifactEditor;
var vArtifactEditorHandler = ArtifactEditor;
var descDefValue;
var trackerUnitMultiplier;
/*
 * To handle session timeout scenario
 */
function initUpdateArtifactData() {
  vArtifactEditorHandler.updateArtifactData(vArtifactId, vUrl, vUpdateData, vArtifactEditor);	
}

/*
 * To handle session timeout scenario
 */
function initCreateArtifactData() {
  vArtifactEditorHandler.createArtifact(vUrl, vArtifactData, vArtifactCreateEditor);	
}

function ArtifactEditorHandler(webClientHandler) {

    this.webClient = webClientHandler;
    this.messages = {};    
    this.artifactEditorPrefix = 'editor_';
    this.permissions = {};
    this.fieldMetaData = {};
    this.relationsData = {};
    this.fieldRegexValidationData = {};
    this.editorLabelMaxLength = 35;

    var me = this;

    /**
     * The editor options.
     * - artifactUpdated(artifactId, artifactData) -
     * - artifactCreated(artifactEditor)
     */
    this.editorOptions = {};
    
    /**
     * Sets the permissions object.
     * 
     * @param permissions the permission object
     */
    this.setPermissions = function(permissions) {
        this.permissions = permissions;
    };

    /**
     * Gets edit artifact permission.
     *
     * @returns true if user has edit permission
     */
    this.getEditArtifactPermission = function() {
        return (typeof me.permissions['hasEditArtifactPermission'] !== "undefined") ? me.permissions['hasEditArtifactPermission'] : false;
    };
    
 
    /**
     * Gets edit comment permission.
     *
     * @returns true if user has permission to edit comment
     */
    this.getEditCommentPermission = function() {
        return (typeof me.permissions['hasEditCommentPermission'] !== "undefined") ? me.permissions['hasEditCommentPermission'] : false;
    };

    /**
     * Set project path.
     * @param projectPathString the project path.
     */
    this.setProjectPath = function(projectPathString) {
         this.projectPathString = projectPathString;
    };
    
    /**
     * Sets url key for further use by artifact cards
     */
    this.setReturnUrlKey = function(returnUrlKey) {
      this.returnUrlKey = returnUrlKey;
    }

    
    /**
     * Set folder path.
     * @param folderPathString the folder path.
     */
    this.setFolderPath = function(folderPathString) {
         this.folderPathString = folderPathString;
    };
    
    /**
     * Set planning folder path.
     * @param folderPathString the folder path.
     */
    this.setPlanningFolderPath = function(planningFolderPathString) {
         this.planningFolderPathString = planningFolderPathString;
    };
 
    /**
     * Set team Id selected.
     * @param teamId the team id.
     */
    this.setTeamId = function(teamId) {
         this.teamId = teamId;
    };

    /**
     * Sets the Artifact editor options.
     * 
     * @param editorOptions the artifact editor options
     */
    this.setEditorOptions = function(editorOptions) {
        this.editorOptions = editorOptions;
    };
    
    /**
     * Sets the i18n messages.
     * @param messages the messages key value pair.
     */
    this.setMessages = function(messages) {
        me.messages = messages;
    };

    this.setNobodyUser = function(user) {
        if (user) {
            me.nobodyUser = user;
        }
    }
    /**
     * Opens the artifact editor.
     * 
     * @param artifactId the ID of the artifact to display
     */
    this.createEditorForEditArtifact = function(artifactId, cardVersion) {
            var url = '/sf/projectboards/do/editArtifact/'
                + me.projectPathString + '/' + me.folderPathString + '/' + artifactId;
            me.openArtifactEditor(url, me.messages['artifact.editor.loading.message'], cardVersion);
    };
    
    /**
     * Opens the dialog for add artifact.
     * 
     */
    this.createEditorForAddArtifact = function() {
        var url = '/sf/projectboards/do/renderAddArtifactCard/'
            + me.projectPathString;
        me.openArtifactEditor(url, me.messages['create.artifact.editor.loading.message']);
    };

    /**
     * Open the artifact editor modal.
     * 
     * @param url the url to be invoked
     * @param loadingMessage the message to be displayed while loading editor
     */
    this.openArtifactEditor = function(url, loadingMessage, cardVersion) {
        $j('.greenText').remove(); 
        var progressDisplay = $j(this).bootstrap_dialog(me.getProgressDisplayOptions(loadingMessage));
        var success = function(response) {
            progressDisplay.bootstrap_dialog("destroy");
            if ((response.action !== undefined) && (response.action === "render")) {
                var artifactData = response.artifactData;
                var editorOptions;
            if (artifactData !== undefined && artifactData.id) {    
                    me.setPermissions(artifactData.artifactPermissions);
                    me.setNobodyUser(response.nobodyUser);
                    me.webClient.setNobodyUser(response.nobodyUser);
                    var artifactEditor = $j(me.getArtifactEditorHTML(artifactData));
                    artifactData.version = cardVersion;
                    me.populateArtifactEditor(artifactEditor, artifactData);
                    editorOptions = me.getEditEditorOptions(artifactEditor, artifactData);
                    var accordionConfiguration = me.webClient.getAccordionConfiguration(artifactEditor, {
                    active: 0
                });
                 
                artifactEditor.find('.artifact-editor-accordion').accordion(accordionConfiguration);
                 
                artifactEditor.bootstrap_dialog(editorOptions, me.messages);
                me.setUpTeam(artifactData);
                me.setUpArtifactEditorListeners(artifactEditor, artifactData);
                me.setUpArtifactEditorInitialization();
                } else {
                var trackerData =response.trackerList;
                if(trackerData !== undefined){
                    var artifactCreateEditor = $j(me.getArtifactAddHTML(trackerData));
                    me.populateAddArtifactData (artifactCreateEditor, trackerData);
                    var addOptions =me.getAddArtifactOptions(artifactCreateEditor);
                    artifactCreateEditor.bootstrap_dialog(addOptions, me.messages);
                    me.setUpArtifactCreateEditorListeners(artifactCreateEditor);
                    }
                }
            } else if ((response.action !== undefined) && (response.action === "refresh")) {
                me.webClient.handleLogout();
            }
        };

        var failure = function(request) {
            progressDisplay.bootstrap_dialog("destroy");
            me.webClient.alert(me.messages['artifact.editor.load.error']);
        };

        var request = me.webClient.getJSON(url, success, failure);
    };
        
    /**
     * Create a DOM element for a artifact dialog box.
     * 
     * @param artifactData the artifact details
     * @return the jQuery Dialog object
     */
    this.getEditEditorOptions = function(artifactEditor, artifactData) {
        var editorTitle = me.messages['edit.artifact.details'] + ' ' + artifactData.id;
        if(!me.getEditArtifactPermission()) {
          editorTitle = me.messages['view.artifact.details'] + ' ' + artifactData.id;
        }
        var editorOptions = {
                cancel : function() {
                    $j(this).bootstrap_dialog("destroy");
                },
                title : editorTitle
        };

        if(me.getEditArtifactPermission() || me.getEditCommentPermission()) {
            editorOptions.save = function() {
                me.updateArtifact(artifactData, artifactEditor);
            }
        }
        return editorOptions;
    };
    
    /**
     * Create a DOM element for add artifact dialog box.
     * 
     * @param artifactCreateEditor the artifact details
     * @return the jQuery Dialog object
     */
    
    this.getAddArtifactOptions= function(artifactCreateEditor){
        
        var editorTitle = me.messages['create.artifact.details'];
        var editorOptions = {
            cancel : function() {
                $j(this).bootstrap_dialog("destroy");
            },
            title : editorTitle,
            action:"create"
            
    };
    editorOptions.save = function() {
        if(artifactCreateEditor.parent().next().find('.Button').eq(1).attr('disabled')==='disabled'){
            return;
        }else {
        me.createArtifactData(artifactCreateEditor);
        }

    }
    return editorOptions;
};

     
    /**
     * Sets up the options for the progress display modal.
     * 
     * @param message the display message.
     */
    this.getProgressDisplayOptions = function(message) {
        var options = {
            title : "",
            content: me.webClient.displayProgress(message),
            hide_close: true
        };

        return options;
    }
    
    /**
     * Sets up the artifact create listeners.
     * 
     * @param artifactCreateEditor the artifact create editor.
     */
    this.setUpArtifactCreateEditorListeners =function(artifactCreateEditor) {
        var editorIDs = me.getEditorIDs(me.getEditorID());
         var finder = function(elemId) {           
             return artifactEditor.find("#" + elemId);
         };
         
         artifactCreateEditor.delegate('#' + editorIDs.tracker, 'change', function() {
             var field = $j(this);
             if (field.val()) {
                 me.validateTrackerType(artifactCreateEditor,field);    
             }
         });
         
         
         artifactCreateEditor.delegate('#' + editorIDs.title, 'keyup change', function() {       
             var checkBoxSelector =artifactCreateEditor.find('.editor-selectionBox');
             if (artifactCreateEditor.find('input[id=' + editorIDs.title + ']').val().length >0){ 
                 checkBoxSelector.attr('isEnabled',true);
             }else{
                 checkBoxSelector.attr('isEnabled',false);
                 artifactCreateEditor.find('.copy-title').prop('checked', false);
             }
         });
         
         /**
          * Handles the copy-title check box status
          */
                  
                  
         artifactCreateEditor.delegate('.copy-title', 'change', function() {
             
             var artifactTitle =artifactCreateEditor.find('input[id=' + editorIDs.title + ']').val();
             if( artifactCreateEditor.find('.copy-title').prop('checked') && artifactTitle.length >0 ){
                 artifactCreateEditor.find('textarea[id=' + editorIDs.description + ']').val(artifactTitle);
             }else {
                 artifactCreateEditor.find('.copy-title').prop('checked', false);
                }
            });
         me.titleLengthCheck(artifactCreateEditor,editorIDs);
        
    }

    /**
     * Sets up the artifact editor listeners.
     * 
     * @param artifactEditor the artifact editor.
     * @param artifactData the artifact data.
     * TODO: Remove artifactData param once fieldMetaData and transitionData
     * set at instance level.
     */
    this.setUpArtifactEditorListeners = function(artifactEditor, artifactData) {
        
        var editorID = artifactEditor.attr('id');
        var editorIDs = me.getEditorIDs(editorID);
        
        var finder = function(elemId) {           
            return artifactEditor.find("#" + elemId);
        };
        
        /**
         * Handles the changes for the priority required field.
         */
        artifactEditor.delegate('#' + editorIDs.priority, 'change', function() {
            var field = $j(this);
            $j.each(artifactData.fieldMetaData, function(id, fieldMetaDataValueObject) {
                if (fieldMetaDataValueObject.name == 'priority') {
                    if (fieldMetaDataValueObject.isRequired && field.val() == '0') {
                        me.webClient.markError(finder(editorIDs.priority), me.messages['artifact.editor.invalid.value.error']);
                    } else {
                        me.clearError(field);
                    }
                    return false;
                }
            });
        });
        
        /**
         * Handles the change for the assignedTo field
         */
        artifactEditor.delegate('#' + editorIDs.assignedTo, 'change', function() {
            var field = $j(this);
            $j.each(artifactData.fieldMetaData, function(id, fieldMetaDataValueObject) {
                if (fieldMetaDataValueObject.name == 'assignedTo') {
                    if (fieldMetaDataValueObject.isRequired &&
                            me.nobodyUser &&
                            field.val() == me.nobodyUser.id) {
                        me.webClient.markError(finder(editorIDs.assignedTo), me.messages['artifact.editor.invalid.value.error']);
                    } else {
                        me.clearError(field);
                    }
                    return false;
                }
            });
        });

        /**
         * Handle the changes on the tracker unit change.
         * resets the field display value.
         */
        artifactEditor.delegate('#' + editorIDs.trackerUnit, 'change', function() {
            
            var field = $j(this);
            var inputField = field.parents('.settings-column-row').first().children('.artifact-editor-effort').children('input');            
            //the value of the unit multiplier that was selected
            var selectedTrackerUnitMultiplier = field.find('option:selected').attr('unitMultiplier');           
            inputField.val(Math.round(100 * parseFloat(inputField.attr('originalValue') / selectedTrackerUnitMultiplier)) / 100);
            
        });

        /**
         * Set required field(s) with mandatory UI widget for status workflow transition
         */
        artifactEditor.delegate('#' + editorIDs.status, 'change', function() {
            var selectedStatus = $j(this).val();
            var requiredFieldsArray = artifactData.transitionData[selectedStatus];

            // if required fields exists for selected status add workflow required widget
            // else remove required widget (if present)
            if (requiredFieldsArray !== null && requiredFieldsArray !== undefined) {
                /* Better to remove all exiting required widget and then add for required fields for selected status.
                 * Pending --> Open requiredFieldsArray[field1, field2, field3, field4]
                 * Pending --> Closed requiredFieldsArray[field1]
                 * Changing status from Pending --> Open --> Closed in the same transaction, widget has to be removed from
                 * field2, field3 and field4 which is cumbersome to track.
                 */
                me.removeAllWorflowRequiredWidget(artifactEditor);
                //loop through each required field configured for a status
                $j.each(requiredFieldsArray, function(index, requiredFieldId) {
                    var requiredFieldName = artifactData.fieldMetaData[requiredFieldId] !== undefined ? artifactData.fieldMetaData[requiredFieldId].name : requiredFieldId;
                    //get label id by field name and append required field widget
                    var labelId = editorIDs[requiredFieldName] !== undefined ? editorIDs[requiredFieldName] : requiredFieldId;
                    me.addWorflowRequiredWidgetToField(labelId, artifactEditor);
                });
            } else {
                me.removeAllWorflowRequiredWidget(artifactEditor);
            }

            // Hide the transition hidden fields in primary attribute
            var hiddenFieldsArray = artifactData.transitionHiddenFieldData[selectedStatus];
            me.hideFields(hiddenFieldsArray, editorID,editorIDs, artifactData, artifactEditor);
        });

        /**
         * Handle the changes on the title  change.
         * adds the key up event.
         */
        artifactEditor.delegate('#' + editorIDs.title, 'keyup change', function() {          
            textCounter(this,255);          
        }); 
        
        
        /**
         * Handle the changes on the value of the effort field 
         * resets the original value.         
         */
        artifactEditor.delegate('.artifact-editor-effort > input', 'keyup change', function() {
            
           var field = $j(this);          
           //the value of the unit multiplier that was selected
           var selectedTrackerUnitMultiplier = field.parents('.settings-column-row').first().children(
                            '.artifact-editor-effort-unit').find('option:selected').attr('unitMultiplier');
           trackerUnitMultiplier = selectedTrackerUnitMultiplier;
           var value;
           if (trackerUnitMultiplier == 1) {
               value = parseFloat(field.val()) * selectedTrackerUnitMultiplier;
           } else {
               value = Math.round(parseFloat(field.val()) * selectedTrackerUnitMultiplier);
           }
           if (!isNaN(value)) {
               field.attr('originalValue', value);
           } else {
               field.attr('originalValue', '-1');
           }
        });

        /**
         * Handles the pattern validation on text fields
         */
        artifactEditor.delegate('input.validate,textarea.validate', 'change keyup', function() {
            var field = $j(this);
            if (field.val()) {
                me.validateFieldValuePattern(field);
            } else if(me.fieldMetaData[field.attr('id')].isRequired) {
                me.webClient.markError(field, me.messages['artifact.editor.required.value.error']);                
            } else {                
                me.fieldRegexValidationData[field.attr('id')] = true;
                me.clearError(field);
            }
        });
        
        /**
         * Handles select error clear scenario for required flex select fields.
         */
        artifactEditor.delegate('select.flexfield', 'change', function() {
            var field = $j(this);
            //check flex field and required.
            if (field.val() && me.fieldMetaData[field.attr('id')].isRequired) {
                //remove the None option.
                field.children().filter(function(index, option) {
                    return option.value == '';
                }).remove();
                me.clearError(field);    
            }        
        });
        
        
        /**
         * Handle Parent Child relations.
         * Iterate the relationsData and set the listeners.
         */         
        $j.each(me.relationsData, function(parentId, childId) {            
            artifactEditor.delegate('#' + parentId, 'change', function() {               
                
                var parentField = artifactEditor.find('#' + parentId);
                var selectedValue = parentField.find('option:selected').val();
                
                if (selectedValue) {                    
                    var url = '/sf/tracker/do/getChildFieldValuesJSON/'
                        + me.projectPathString + '/' + me.folderPathString + '?childid=' + childId + '&parentfv=' + selectedValue;
                    
                    me.addChildDataOptionsForParentFieldValue(url, childId, artifactEditor)
                } else {
                    me.webClient.addDefaultOptionToSelect(childId, me.messages['common.none'], finder, true, true);
                }
            });
        });

    };
    
    /**
     * Handle the changes on the title  change.
     * adds the key up event.
     */
    this.titleLengthCheck = function(artifactEditor, editorIDs){
        artifactEditor.delegate('#' + editorIDs.title, 'keyup change', function() {          
            textCounter(this,255);          
    }); 
    }


    /**
     * Sets up the artifact editor initializations.
     */
    this.setUpArtifactEditorInitialization = function() {
        $j('span[rel=tooltip]').tooltip();
    }
    
    /**
     * Fetches child options value for the parent select field.
     * Used for parent child field relations.
     * 
     * @param url the get url
     * @param elementId the element to fetch the data for.
     * @param artifactEditor the artifact editor.
     */
    this.addChildDataOptionsForParentFieldValue = function(url, elementId, artifactEditor) {
        
        var finder = function(elemId) {           
            return artifactEditor.find("#" + elemId);
        };
        
        var success = function(response) {            
            if ((response.action !== undefined) && (response.action === "render")) {  
                if (response.values.length) {
                    me.webClient.changeDataToSelectWithOptionValue(elementId, response.values, response.values[0], finder);    
                } else {
                    me.webClient.addDefaultOptionToSelect(elementId, me.messages['common.none'], finder, false, true);
                }                
            } 
        };

        var failure = function(request) {
            artifactEditor.bootstrap_dialog("destroy");
            me.webClient.alert(me.messages['artifact.editor.load.error']);
        };

        var request = me.webClient.getJSON(url, success, failure);        
    }
    
    /**
     * Validates the Field for its pattern.
     * and populates fieldRegexValidationData map and add/removes errors.
     * 
     * @param element the field to validate for
     */
    this.validateFieldValuePattern = function(element) {
        
        var url = '/sf/tracker/do/validateField?fieldId=' + element.attr('id') + '&value=' + element.val();

        var success = function(response) {
            if ((response.action !== undefined) && (response.action === "render")) {
                me.fieldRegexValidationData[element.attr('id')] = response.match;
                if (response.match) {
                    me.clearError(element);
                } else {
                    me.webClient.markError(element, me.messages['artifact.editor.invalid.value.error']);
                }
            }
        };
        var request = me.webClient.getJSON(url, success);
    }
    
    /**
     * Validates the Tracker type if work-flow configured
     *   it populates the info message
     * 
     * @param element the field to validate for
     */
    

        this.validateTrackerType = function(artifactCreateEditor, element) {

        var url = '/sf/projectboards/do/getTrackerConfig/'
                + me.projectPathString + '/' + element.val();

        var success = function(response) {

            if ((response.action !== undefined) && (response.action === "render")) {

                var infoMessage = element.parent().prev();

                //Set description with default value
                descDefValue = response.descDefValue;
                var finder = function(elemId) {
                    return artifactCreateEditor.find("#" + elemId);
                 };
                me.webClient.addDataToField('editor_new_description',descDefValue, finder);
                artifactCreateEditor.find('.copy-title').prop('checked', false);

                if (infoMessage.hasClass("workflowInfo")) {
                    infoMessage.remove();
                    me.disableCreateArtifact(artifactCreateEditor, false);
                }
                if (response.isHiddenFieldConfigured) {
                    me.disableCreateArtifact(artifactCreateEditor, "disabled");
                    var argument = [ '<a href=/sf/tracker/do/createArtifact/'
                                           + me.projectPathString
                                           + '/'
                                           + element.val()
                                           +'?returnUrlKey='
                                           + me.returnUrlKey
                                           + ' target="_self">'
                                           + me.messages['create.artifact.link.text']
                                           + '</a>' ];
                    message = me.webClient.formatMessage(me.messages['tracker.workflow.hidden.field.message'], argument);
                    element.parent().before(me.webClient.getInfoMessage(message));
                } else if (!response.hasCreate || response.isUnSupported) {
                    me.disableCreateArtifact(artifactCreateEditor, "disabled");
                    artifactCreateEditor.find('.editor-selectionBox').attr('isEnabled', false);
                    var message;
                    if (!response.hasCreate) {
                        message = me.messages['tracker.create.permission.message'];
                    } else if (response.isUnSupported) {
                        var argument = [ '<a href=/sf/tracker/do/createArtifact/'
                                + me.projectPathString
                                + '/'
                                + element.val()
                                +'?planningFolderPath='
                                + me.planningFolderPathString
                                + '&returnUrlKey='
                                + me.returnUrlKey
                                + ' target="_self">'
                                + me.messages['create.artifact.link.text']
                                + '</a>' ];
                        message = me.webClient.formatMessage(me.messages['tracker.workflow.message'], argument);
                    }
                    element.parent().before(me.webClient.getInfoMessage(message));
                }
            }
        }
        var request = me.webClient.getJSON(url, success);
    };  

        /**
         * Disables the fields and button when tracker configured with workflow.
         */
    this.disableCreateArtifact = function(artifactCreateEditor,isEnable) {
        var editorID = me.getEditorID();
        var editorIDs = me.getEditorIDs(editorID);
        artifactCreateEditor.parent().next().find('.Button').eq(1).attr('disabled', isEnable);
        artifactCreateEditor.find('#' + editorIDs.title).attr('disabled', isEnable);
        artifactCreateEditor.find('#' + editorIDs.description).attr('disabled', isEnable);
       }
    
    /**
     * Updates the artifact with the edited input.
     */
    this.updateArtifact = function(artifactData, artifactEditor) {
        var artifactId = artifactData.id;
        if (me.validateArtifactEditor(artifactEditor, artifactId)) {
            var requestData = me.createArtifactUpdateJSONData(artifactEditor);
            me.updateArtifactData(artifactId, '/sf/projectboards/do/updateArtifact/'+ me.projectPathString + '/' 
                    + me.folderPathString + '/' + artifactId, requestData, artifactEditor);
        } else {
          var editorID = me.getEditorID(artifactId);
          var editorIDs = me.getEditorIDs(editorID);
          var selectedStatus = $j("#" + editorID + "_status").val();
          var hiddenFieldsArray = artifactData.transitionHiddenFieldData[selectedStatus];
          me.hideFields(hiddenFieldsArray, editorID,editorIDs, artifactData, artifactEditor);
        }
    }; 

    // hide the fields when the status changes
    this.hideFields = function (hiddenFieldsArray, editorID, editorIDs, artifactData, artifactEditor) {
        if (hiddenFieldsArray !== null && hiddenFieldsArray !== undefined) {
            me.showAllFieldWidget(artifactEditor);
            $j.each(hiddenFieldsArray, function(index, hiddenFieldId) {
                var hiddenFieldName = artifactData.fieldMetaData[hiddenFieldId] !== undefined ? artifactData.fieldMetaData[hiddenFieldId].name : hiddenFieldId;
                //get label id by field name and hide the hidden field
                var labelId = editorIDs[hiddenFieldName] !== undefined ? editorIDs[hiddenFieldName] : hiddenFieldId;
                me.hideWorflowTransitionHiddenField(labelId, artifactEditor);
                if (hiddenFieldId === 'comment') {
                    $j(".comments-accordion-header").hide();
                    $j(".comments-accordion-content").hide();
                }
            });
        } else {
            me.showAllFieldWidget(artifactEditor);
        }
    }
    /**
     * Saves the artifact with the new input.
     */
    this.createArtifactData = function(artifactCreateEditor) {
        var editorID = me.getEditorID();
        var editorIDs = me.getEditorIDs(editorID);
        if (me.validateArtifactEditor(artifactCreateEditor)) {
            var requestData = me.createArtifactAddJSONData(artifactCreateEditor);
            var folderPath =artifactCreateEditor.find('select[id=' + editorIDs.tracker + ']').val();
            me.createArtifact('/sf/projectboards/do/addArtifact/'+ me.projectPathString + '/' 
                    + folderPath , requestData, artifactCreateEditor);
        }
    }; 

    /**
     * Creates the JSON request for the artifact editor field data.
     * 
     * @param artifactEditor the artifact editor.
     */
    this.createArtifactUpdateJSONData = function(artifactEditor) {
        
        var editorID = artifactEditor.attr('id');
        var editorIDs = me.getEditorIDs(editorID);
        var requestData = { 
            title: artifactEditor.find('input[id=' + editorIDs.title + ']').val(),
            description: artifactEditor.find('textarea[id=' + editorIDs.description + ']').val(),
            version: artifactEditor.find('input[id=' + editorIDs.version + ']').val(),
            status: artifactEditor.find('select[id=' + editorIDs.status + ']').val(),
            priority: artifactEditor.find('select[id=' + editorIDs.priority + ']').val(),
            
            selectedTeam: me.getSelectedTeam(editorIDs.team),
            assignedTo: artifactEditor.find('select[id=' + editorIDs.assignedTo + ']').val(),
            assignedToText: artifactEditor.find('select[id=' + editorIDs.assignedTo + '] option:selected').text(),
            actualEffort: artifactEditor.find('input[id=' + editorIDs.actualEffort + ']').attr('originalValue'),
            remainingEffort: artifactEditor.find('input[id=' + editorIDs.remainingEffort + ']').attr('originalValue'),
            estimatedEffort: artifactEditor.find('input[id=' + editorIDs.estimatedEffort + ']').attr('originalValue'),
            // if point field is enabled then set field value. if point field is enabled but no value is set then set to 0
            points: artifactEditor.find('input[id=' + editorIDs.points + ']').length > 0 ? 
                (artifactEditor.find('input[id=' + editorIDs.points + ']').val() ?  artifactEditor.find('input[id=' + editorIDs.points + ']').val() : 0) :
                artifactEditor.find('input[id=' + editorIDs.points + ']').val(),
            comments: artifactEditor.find('textarea[id=' + editorIDs.comment + ']').val()            
        };

        requestData.otherFields = me.createOtherFieldsUpdateJSONData(artifactEditor, '.otherfield');
        requestData.flexFields = me.createOtherFieldsUpdateJSONData(artifactEditor, '.flexfield');
        return requestData;
    };
    
    /**
     * Creates the JSON request for the artifact add field data.
     * 
     * @param artifactCreateEditor the artifact add editor.
     */
    this.createArtifactAddJSONData = function(artifactCreateEditor) {
        var editorID = me.getEditorID();
        var editorIDs = me.getEditorIDs(editorID);
        var requestData = { 
            title: artifactCreateEditor.find('input[id=' + editorIDs.title + ']').val(),
            description: artifactCreateEditor.find('textarea[id=' + editorIDs.description + ']').val(),
            planningFolderPath: me.planningFolderPathString,
            teamId: me.teamId

            };

        return requestData;
    };

    /**
     * Creates the JSON request for the artifact editor other fields.
     * 
     * @param artifactEditor the artifact editor.
     * @param fieldType the type of field (flex field or other field)     
     * @returns the JSON data for other fields
     */
    this.createOtherFieldsUpdateJSONData = function(artifactEditor, fieldType) {
        var otherFieldsJSON = {};
        var otherFields = artifactEditor.find(fieldType);
        otherFields.each(function(index, value){
            var field = $j(value);
            var fieldKey = field.attr('name');            
            if (field.is('select')) {
                if (fieldKey == 'Reported in Release') fieldKey = 'reportedInRelease';
                if (fieldKey == 'Fixed in Release') fieldKey = 'resolvedInRelease';
                if (fieldKey == 'Group'  && fieldType == '.otherfield') fieldKey = 'group';
                if (fieldKey == 'Category'  && fieldType == '.otherfield') fieldKey = 'category';
                if (fieldKey == 'Customer'  && fieldType == '.otherfield') fieldKey = 'customer';
                var fieldValue = field.find('option:selected').val();
                if ((fieldKey == 'reportedInRelease' || fieldKey == 'resolvedInRelease') && 
                        fieldType != '.flexfield') {
                    otherFieldsJSON[fieldKey] = fieldValue;
                } else if(fieldValue) {
                    var displayText = field.find('option:selected').text();
                    if (displayText === 'None') {
                        otherFieldsJSON[fieldKey] = "";
                    } else {
                    otherFieldsJSON[fieldKey] = displayText;
                    }
                } else {
                    otherFieldsJSON[fieldKey] = fieldValue;
                }
            } else {
                otherFieldsJSON[fieldKey] = field.val();
            }
        });

        return otherFieldsJSON;
    };
    

    /**
     * Handle a save request for a artifact data.
     *
     * @param url the url to post the data.
     * @param data the artifact update data to post to the server.
     * @param artifactEditor the editor element of the artifact to update.
     */
    this.updateArtifactData = function(artifactId, url, updateData, artifactEditor) {
    	
       /*
        * To handle session timeout scenario
        */
       vArtifactId = artifactId;
       vUrl = url;
       vUpdateData = updateData;
       vArtifactEditor = artifactEditor;;
    	
       if(!isSessionActive()) {
         showSessionTimeoutDiv('initUpdateArtifactData');
         return;
       }
    	
       artifactEditor.bootstrap_dialog("destroy");
       var progressDisplay = $j(this).bootstrap_dialog(me.getProgressDisplayOptions(me.messages['artifact.editor.saving.message']));
       var success = function(response) {
           progressDisplay.bootstrap_dialog("destroy");
           if ((response.action !== undefined) && (response.action === "render")) {
               me.editorOptions.artifactUpdated(artifactId, response.data);
               me.displayArtifactSuccessMessage(artifactId, me.messages['artifact.updated.success.message'], true);
           } else if ((response.action !== undefined) && (response.action === "refresh")) {
               me.webClient.handleLogout();
           } else if ((response.action !== undefined) && response.action === "error") {
               me.webClient.alert(response.message) ;
           }
                                                 
       };

       var failure = function(request) { 
           progressDisplay.bootstrap_dialog("destroy");
           me.webClient.alert(me.messages['artifact.editor.update.error']);                    
       };

       me.webClient.postJSON(url, updateData, success, failure);
    };
    
    
    /**
     * Handle a save request for a add artifact data.
     *
     * @param url the url to post the data.
     * @param data the artifact data to post to the server.
     * @param artifactCreateEditor the editor element of the artifact .
     */
    
    this.createArtifact = function( url, artifactData, artifactCreateEditor) {
       /*
        * To handle session timeout scenario
        */
    	vUrl = url;
    	vArtifactData = artifactData;
    	vArtifactCreateEditor = artifactCreateEditor;;
    	
        if(!isSessionActive()) {
          showSessionTimeoutDiv('initCreateArtifactData');
          return;
        }
        artifactCreateEditor.bootstrap_dialog("destroy");
        var progressDisplay = $j(this).bootstrap_dialog(me.getProgressDisplayOptions(me.messages['artifact.editor.saving.message']));
        var success = function(response) {
            progressDisplay.bootstrap_dialog("destroy");
            if ((response.action !== undefined) && (response.action === "render")) {
                me.displayArtifactSuccessMessage(response.artifactId, me.messages['artifact.created.success.message'], true);
                me.editorOptions.artifactCreated(response,me.planningFolderPathString, me.teamId);
            } else if ((response.action !== undefined) && (response.action === "refresh")) {
                me.webClient.handleLogout();
            } else if ((response.action !== undefined) && response.action === "error") {
               me.webClient.alert(response.message) ;
           }
                                                  
        };

        var failure = function(request) { 
            progressDisplay.bootstrap_dialog("destroy");
            me.webClient.alert(me.messages['artifact.create.error']);                    
        };

        me.webClient.postJSON(url, artifactData, success, failure);
     };
    
    
    
    
    /**
     * Validates the fields of the artifact editor.
     *
     * @param artifactEditor the artifactEditor to validate
     * @returns whether all fields are valid.
     */
    this.validateArtifactEditor = function(artifactEditor,artifactId) {
       
        var editorID = me.getEditorID(artifactId);
        var editorIDs = me.getEditorIDs(editorID);
        
        //Common rules for add,edit artifact
        var rules = [
          {
             selector : '#' + editorIDs.title,
             rule: me.webClient.getNotEmptyValidationRule(),
             message: me.messages['artifact.editor.requiredField.title.error']
          },
          {
             selector : '#' + editorIDs.title,
             rule: me.webClient.getMaxTitleLengthValidationRule(),
             message: me.messages['artifact.editor.title.length.error']
          },
          {
             selector : '#' + editorIDs.description,
             rule: me.webClient.getNotEmptyValidationRule(),
             message: me.messages['artifact.editor.requiredField.description.error']
          
          }, 
          {
             selector : '#' + editorIDs.description,
             rule: me.webClient.getDescNotSameAsDefaultValidationRule(descDefValue) ,
             message: me.messages['artifact.editor.requiredField.description.error']
          }
       ];
        (artifactId== undefined) ? me.addTrackerFieldValidationRule(artifactEditor,rules,editorIDs) : me.addEditorValidationRules(artifactEditor, rules,editorIDs);
        
        return me.webClient.validateEditor(artifactEditor, rules);
    };
    

    /**
     * Validates the fields of the artifact editor.
     *
     * @param artifactEditor the artifactEditor to validate
     * @param rules the editor rules
     * @param editorIDs the editor ids
     * @returns whether all fields are valid.
     */
    
    this.addEditorValidationRules = function(artifactEditor, rules,editorIDs) {
        
        me.addOtherFieldValidationRules(artifactEditor, rules);
        me.addOtherFieldRequiredRules(artifactEditor, rules);
        me.addWorkflowFieldValidationRules(artifactEditor, rules);
        me.getCommentsWorkFlowValidationRule('#' + editorIDs.comment, rules);
 
        rules.push({
            selector : '#' + editorIDs.estimatedEffort,
            rule: me.webClient.getPositiveIntegerValidationRule(),
            message: me.messages['artifact.editor.positive.integer.error']
         },
         {
             selector : '#' + editorIDs.estimatedEffort,
             rule: me.webClient.getTrackerBaseUnitValidationRule(trackerUnitMultiplier),
             message: me.messages['artifact.editor.positive.integer.error']
         },
         {
            selector : '#' + editorIDs.estimatedEffort,
            rule: me.webClient.getTrackerUnitLengthValidationRule(),
            message: me.messages['artifact.editor.tracker.unit.length.error']
          },
         {
            selector : '#' + editorIDs.actualEffort,
            rule: me.webClient.getPositiveIntegerValidationRule(),
            message: me.messages['artifact.editor.positive.integer.error']
         },
         {
            selector : '#' + editorIDs.actualEffort,
            rule: me.webClient.getTrackerBaseUnitValidationRule(trackerUnitMultiplier),
            message: me.messages['artifact.editor.positive.integer.error']
         },
         {
            selector : '#' + editorIDs.actualEffort,
            rule: me.webClient.getTrackerUnitLengthValidationRule(),
            message: me.messages['artifact.editor.tracker.unit.length.error']
          },
         {
            selector : '#' + editorIDs.remainingEffort,
            rule: me.webClient.getPositiveIntegerValidationRule(),
            message: me.messages['artifact.editor.positive.integer.error']
         },
         {
            selector : '#' + editorIDs.remainingEffort,
            rule: me.webClient.getTrackerBaseUnitValidationRule(trackerUnitMultiplier),
            message: me.messages['artifact.editor.positive.integer.error']
         },
         {
            selector : '#' + editorIDs.remainingEffort,
            rule: me.webClient.getTrackerUnitLengthValidationRule(),
            message: me.messages['artifact.editor.tracker.unit.length.error']
          },
         {
            selector : '#' + editorIDs.points,
            rule: me.webClient.getPositiveNonDecimalIntegerValidationRule(),
            message: me.messages['artifact.editor.positive.integer.error']
         });
        
        
    }
    
    /**
     * Adds rule for tracker field on add artifact
     *
     * @param artifactEditor the artifactEditor to validate
     * @param rules the editor rules
     * @param editorIDs the editor ids
     * @returns whether all fields are valid.
     */
    
    this.addTrackerFieldValidationRule = function(artifactEditor, rules, editorIDs){
        rules.push({
                selector : '#' + editorIDs.tracker,
                rule: me.webClient.getOptionSelectedValidationRule(),
                message: me.messages['create.artifact.requiredField.tracker.error']
            });
    }
    
    /**
     * Adds rule for transition workflow fields.
     * 
     * @param artifactEditor the artifactEditor to validate
     * @param rules the editor rules
     */
    this.addWorkflowFieldValidationRules = function(artifactEditor, rules) {
        
        var workFlowFields = artifactEditor.find('.transitionRequiredFieldMarkInstruction').prev().children();
        var effortFields = me.getEffortFields(artifactEditor);
        var callbackRule;
        var errorMessage;
        workFlowFields.each(function(index, value) {
            var field = $j(value).attr('for');            
            //check if effort fields
            if (field) {
                if (field.indexOf('priority') > -1) {
                    callbackRule = me.webClient.getNonZeroPositiveIntegerValidationRule();
                    errorMessage = me.messages['artifact.editor.required.value.error'];
                } else if (field.indexOf('assignedTo') > -1) {
                    callbackRule = me.webClient.getAssignedToFieldValidationRule();
                    errorMessage = me.messages['artifact.editor.required.value.error'];
                } else if($j.inArray(field, effortFields) == -1) {
                    callbackRule = me.webClient.getNotEmptyValidationRule();
                    errorMessage = me.messages['artifact.editor.required.value.error'];                
                } else {
                    callbackRule = me.webClient.getNonZeroPositiveIntegerValidationRule();
                    errorMessage = me.messages['artifact.editor.positive.nonzero.integer.error'];
                }
                rules.push({
                    selector : '#' + field,
                    rule: callbackRule,
                    message: errorMessage
                });    
            }            
        });
    }
    
    /**
     * Wrapper method that validates comment not empty upon configured 
     * for workflow.
     * 
     * @param the add comment field.
     * @param rules the editor rules
     */
    this.getCommentsWorkFlowValidationRule = function(commentField, rules) {
        
        if ($j(commentField).parents('.artifact-editor-accordion').children('.comments-accordion-header')
                .children('.transitionRequiredFieldMarkInstruction').length == 1) {
            rules.push({
                selector : commentField,
                rule: me.webClient.getNotEmptyValidationRule(),
                message: me.messages['artifact.editor.required.value.error']
            });
        }        
    }

    /**
     * Adds rules for field validations.
     *
     * @param artifactEditor the artifactEditor to validate
     * @param rules the editor rules
     */
    this.addOtherFieldValidationRules = function(artifactEditor, rules) {
        var otherFields = artifactEditor.find('.validate');
        otherFields.each(function(index, value) {
            var field = $j(value);
            rules.push({
                selector : '#' + field.attr('id'),
                rule: me.webClient.getRegExValidationRule(me.fieldRegexValidationData[field.attr('id')]),
                message: me.messages['artifact.editor.invalid.value.error']
            });
        });
    }

    /**
     * Adds rules for required field empty check.
     *
     * @param artifactEditor the artifactEditor to check
     * @param rules the editor rules
     */
    this.addOtherFieldRequiredRules = function(artifactEditor, rules) {
        var otherFields = artifactEditor.find('.required').prev().children();
        otherFields.each(function(index, value){
            var field = $j(value);
            rules.push({
                selector : '#' + field.attr('for'),
                rule: me.webClient.getNotEmptyValidationRule(),
                message: me.messages['artifact.editor.required.value.error']
            });
        });

    }

    /**
     * Creates the Artifact Editor.
     * 
     * @param artifactData the artifact data.
     */
    this.getArtifactEditorHTML = function(artifactData) {
        var editorID = me.getEditorID(artifactData.id);
        var editorIDs = me.getEditorIDs(editorID);
    
        var artifactEditorHTML = ['<div class="artifact-editor form-row-bg" id="', editorID, '">'];
        artifactEditorHTML.push(me.getTitleHTML(editorIDs.title));    
        artifactEditorHTML.push(me.getDescriptionHTML(editorIDs.description));
        artifactEditorHTML.push('<div class="workflowInstruction"></div>');
        artifactEditorHTML.push(me.getEditorAccordionHTML(editorIDs, artifactData));
        
        artifactEditorHTML.push('<input id="', editorIDs.version,'" type="hidden"/>');
        artifactEditorHTML.push('</div>');
        return artifactEditorHTML.join('');
    };

    /**
     * Creates the Artifact add Dialog.
     * 
     * @returns a HTML DIV which contains create artifact 
     */
    
    this.getArtifactAddHTML = function() {

        var editorID = me.getEditorID();
        var editorIDs = me.getEditorIDs(editorID);
        var artifactAddHTML = ['<div class="artifact-add form-row-bg">']; 
        artifactAddHTML.push(me.getTrackerListHTML(editorIDs.tracker));
        artifactAddHTML.push(me.getTitleHTML(editorIDs.title));
        artifactAddHTML.push(me.getSelectBoxHTML());
        artifactAddHTML.push(me.getDescriptionHTML(editorIDs.description));
        artifactAddHTML.push('</div>');
        return artifactAddHTML.join('');
        
    };
    
    /**
    * Builds a HTML DIV which contains the Tracker list of the quick add.
    * 
    * @returns a HTML DIV which contains the Tracker list.
    */
    
    
    this.getTrackerListHTML =function(tracker){
        return [ '<div class="tracker-list">',
                 '<label for="' + tracker + '">', me.messages['application.Tracker'],':',
                 me.webClient.getRequiredField(),'</label>',
            '<select class="inputfield default" type = "text" name="trackers" id="' + tracker + '"></select>',
                 '</div>'].join('');
    };

    /**
     * Builds a HTML DIV which contains the title area of the artifact editor.
     * 
     * @param title the title to be used in the editor
     * @returns a HTML DIV which contains the artifact title area of the artifact
     *          editor
     */
    this.getTitleHTML = function(title) {
        return [ '<div class="editor-title clearfix">',
                 '<label class="pull-left" for="' + title + '">', me.messages['artifact.title.fieldname'], ':',
            me.webClient.getRequiredField(), '</label>',
            '<div><input class="default" type="text" maxlength="255" name="title" id="' + title + '"/>',
            '<span class="infoText" id="length_error_title_span">',me.messages['edit.artifact.max.title.length.reached'],
            '</span></div></div>'].join('');
    };
    
    this.getSelectBoxHTML =function(){
        return ['<div class="editor-selectionBox checkbox popup-bottom-nospace pull-right" isEnabled="false">',
                '<input class="copy-title primary-checkbox" type="checkbox" id="copy-title"/>',
                '<label class="checkbox-title custom-label" for="copy-title">', me.messages['create.artifact.copy.title'], 
                '</label></div>'].join('');
    };

    /**
     * Builds a HTML DIV which contains the description area of the artifact
     * editor.
     * 
     * @param description the ID to put in the description area
     * @returns a HTML DIV which contains the description area of the artifact
     *          editor
     */
    this.getDescriptionHTML = function(description) {
        return ['<div class="editor-description clearfix popup-bottom-nospace">',
                '<label for="' + description + '">', me.messages['artifact.description.fieldname'], ':', 
                me.webClient.getRequiredField(), '</label>',
                '<div><textarea class="default" name="description" rows="3" cols="20" id="' + description +'"></textarea>',
                '</div></div>'].join('');
    };
    
    /**
     * Builds up the content for the accordion.
     * 
     * @param editorIDs the editorIDs used for building the editor
     * @returns the HTML content for the editor accordion section.
     */
    
    this.getEditorAccordionHTML = function(editorIDs, artifactData) {
        
        var accordionHTML = ['<div class="artifact-editor-accordion popup-bottom-nospace">'];
        
        //settings area
        accordionHTML.push(me.buildAccordionHeader(me.messages['artifact.editor.settings.title'], "settings-accordion-header"));
        accordionHTML.push('<div class="settings-accordion-content">');
        accordionHTML.push(me.buildSettingsContentHTML(editorIDs, artifactData));
        accordionHTML.push('</div>');

        //other fields area
        if (artifactData.otherFields && artifactData.otherFields.length > 0) {
            accordionHTML.push(me.buildAccordionHeader(me.messages['artifact.editor.other.fields.title'], "other-fields-accordion-header"));
            accordionHTML.push('<div class="otherfields-accordion-content">');
            accordionHTML.push(me.buildOtherFieldsContentHTML(artifactData.otherFields));
            accordionHTML.push('</div>');
        }

        //comments area
        accordionHTML.push(me.buildAccordionHeader(me.messages['artifact.editor.comments.title'], "comments-accordion-header"));
        accordionHTML.push('<div class="comments-accordion-content">');
        accordionHTML.push(me.buildCommentsContentHTML(editorIDs));
        accordionHTML.push('</div>');
        
        accordionHTML.push('</div>');
        
        return accordionHTML.join('');
    }

    /**
     * Builds up the content for the settings content.
     * 
     * @param editorIDs the editorIDs used for building the editor
     * @param artifactData the artifact data
     * @returns the HTML content for the settings accordion
     */
    this.buildSettingsContentHTML = function(editorIDs, artifactData) {
       var settingsContent = ['<div class="settings-accordion-content-table" >'];
       settingsContent.push('<div class="artifact-editor-settings-column-1">');
       settingsContent.push(me.getColumn1SettingsHTML(editorIDs, artifactData));
       settingsContent.push('</div>');

       settingsContent.push('<div class="artifact-editor-settings-column-2">');
       settingsContent.push(me.getColumn2SettingsHTML(editorIDs, artifactData));
       settingsContent.push('</div>');
       settingsContent.push('</div>');
       return settingsContent.join('');
    };

    /**
     * Builds up the content for other mandatory fields in the artifact editor.
     * 
     * @param otherFields the other mandatory fields.
     * @returns the HTML content for the settings accordion
     */
    this.buildOtherFieldsContentHTML = function(otherFields) {
        var otherFieldsContent = [];
        otherFieldsContent.push('<div class="otherfields-accordion-content-table" >');
        $j.each (otherFields, function() {
           if (me.otherFieldBuilder[this.displayType]) {
               otherFieldsContent.push('<div class="settings-column-row">');
                    otherFieldsContent.push(me.buildLabel(this.id, this.text));
                    otherFieldsContent.push('<div class="artifact-editor-content">');
                    otherFieldsContent.push(me.otherFieldBuilder[this.displayType](this));
                    otherFieldsContent.push('</div>');
               otherFieldsContent.push('</div>');
           }
        });
        otherFieldsContent.push('</div>');

        return otherFieldsContent.join('');
    };

     /**
      * Holds the functions defined for building different type of other mandatory fields.
      */
     this.otherFieldBuilder = {
         "TEXT" : function(otherField) {
             var textFieldContent = [];
             if (otherField.displayLine == 1) {
                 textFieldContent.push('<input class="inputfield default" id="'+ otherField.id + '" name="'+ otherField.text + '" type="text"/>');
             } else {
                 textFieldContent.push('<textarea class="inputfield default" id="' + otherField.id + '" ' +
                     'name="' + otherField.text + '" rows="2"></textarea>');
             }             
             return textFieldContent.join('');
         },

         "DROPDOWN" : function(otherField) {
             var dropDownContent = [];
             dropDownContent.push('<select class="inputfield default" id="'+ otherField.id + '" name="'+ otherField.text + '" type="text"></select>');
             return dropDownContent.join('');
         }
     };

     /**
      * Builds the label HTML for the artifact editor fields.
      * @param id the label id
      * @param title the label value
      */
     this.buildLabel = function(id, title) {
         var labelContent = [];
         var isLabelLengthExceeded = decodeHtmlAttribute(title).length > me.editorLabelMaxLength;
         labelContent.push('<div class="artifact-editor-content"' + (isLabelLengthExceeded ? 'title="'+ title +'"': '')+ '>');
         labelContent.push('<div class="field-label overflow-ellipsis"><label for="', id, '"', ' title="', title, '">');         
         labelContent.push(title + ":");
         labelContent.push('</label></div></div>');
         return labelContent.join('');
     };

    /**
     * Builds up the content for the column 1 settings.
     * 
     * @param editorIDs the editorIDs used for building the editor
     * @param artifactData the artifact data
     * @returns the HTML content for the column 1 settings
     */
    this.getColumn1SettingsHTML = function(editorIDs, artifactData) {
        var column1Content = [];
        column1Content.push('<div>');

        column1Content.push(me.getEditorSelectHTML(editorIDs.priority, 'artifact.editor.priority.title', 'priority'));
        column1Content.push(me.getEditorSelectHTML(editorIDs.status, 'artifact.editor.status.title', 'status'));
        column1Content.push(me.getEditorSelectHTML(editorIDs.assignedTo, 'artifact.editor.assignedTo.title', 'assignedTo'));
        column1Content.push(me.buildTeamTreeHTML(editorIDs, artifactData));
       
        column1Content.push('</div>');

        return column1Content.join('');
    }

    /**
     * Builds up the content for team tree selector.
     * 
     * @param editorIDs the editor id holder
     * @returns the team tree html widget
     */
    this.buildTeamTreeHTML = function(editorIDs, artifactData) {
        var treeHTML = [];
        treeHTML.push('<div class="settings-column-row">');
        treeHTML.push(me.buildLabel(editorIDs.team, me.messages['artifact.editor.team.title']));
        treeHTML.push('<div class="artifact-editor-content" id="', editorIDs.team, '"  data-ng-controller="TeamTreeCtrl" >');
        treeHTML.push('<div  data-ng-show="', me.getEditArtifactPermission(), '"  class="widgets-combo-tree" data-selected="teamComboTreeModel.selected" data-type="\'team\'"',
                'data-tree-family="teamComboTreeModel.treeFamily" data-on-select="onSelect()" data-ng-click="moveScrollToTreePos()">',
        '</div>'  );
        treeHTML.push('<input class="inputfield default " type="text" data-ng-show="', !me.getEditArtifactPermission(),' || teamComboTreeModel.selected.hide" disabled = "true" value="',$j.trim(artifactData.assignTeamTitle),'" />');
        treeHTML.push('</div>');
        treeHTML.push('</div>');
        return treeHTML.join('');
    	
    }

    /**
     * Builds up the content for the column 2 settings.
     * 
     * @param editorIDs the editorIDs used for building the editor
     * @param artifactData the artifact data
     * @returns the HTML content for the column 2 settings
     */
    this.getColumn2SettingsHTML = function(editorIDs, artifactData) {
        var column2HTML = [];
        column2HTML.push('<div>');
  
        if (typeof artifactData.points !== "undefined") {
             column2HTML.push(me.getPointsHTML(editorIDs.points));
        }
        column2HTML.push(me.getEffortHTML(artifactData.estimatedEffort, editorIDs, 'estimatedEffort', 'artifact.editor.estimated.effort.title'));
        column2HTML.push(me.getEffortHTML(artifactData.remainingEffort, editorIDs, 'remainingEffort', 'artifact.editor.remaining.effort.title'));
        column2HTML.push(me.getEffortHTML(artifactData.actualEffort, editorIDs, 'actualEffort', 'artifact.editor.actual.effort.title'));
        column2HTML.push('</div>');

        return column2HTML.join('');
    }

    /**
     * Builds a HTML div which contains the drop down in the artifact editor.
     * 
     * @param elementId the elementId of the drop down
     * @param title the drop down label title
     * @param name the drop down name
     * @return a HTML Div which contains the drop down in artifact editor.
     * 
     */
    this.getEditorSelectHTML = function(elementId, title, name) {

        var editorSelectContent = [];
        editorSelectContent.push('<div class="settings-column-row">');
        editorSelectContent.push(me.buildLabel(elementId, me.messages[title]));
        editorSelectContent.push('<div class="artifact-editor-content">' +
            '<select class="inputfield default" id="' + elementId + '"type="text" name="'+ name +'"></select></div>');
        editorSelectContent.push('</div>');
        return editorSelectContent.join('');
    }

    /**
     * Builds the comments content section of editor.
     * 
     * @param editorIDs the editorIDs used for building the editor
     * @returns the HTML content for the comments section.
     */
    this.buildCommentsContentHTML = function(editorIDs) {
        var commentsContent = [];
        
        commentsContent.push(me.getEditArtifactPermission() || me.getEditCommentPermission() ?
            me.getCommentsAddAreaHTML(editorIDs.comment) : '');
        commentsContent.push('<div class="editor-comments-content">');
        commentsContent.push('<div id="' + editorIDs.commentDetails + '"></div>');
        commentsContent.push('</div>');
        return commentsContent.join('');
    };
    
    /**
     * Creates the comments text area with the given id.
     * 
     * @param textAreaId the text area ID
     * @returns {String} the html string for the text area.
     */
    this.getCommentsAddAreaHTML = function(addAreaId) {
       return '<div class="editor-comment-add-container">' +
            '<textarea rows="1" class="editor-comment-add default" id="' + addAreaId + '" ' +
            'type="text" name="comment"></textarea></div>';
    };
    
    /**
     * Builds the comments contents.
     * Forms the comment html string.
     * 
     * @param textAreaId the comment area.
     * @param comments the comments data.
     * @param finder the finder function to locate the editor element.
     * 
     * @returns commentArea the comments content section.
     * 
     */
    this.addCommentHtmlToElement = function(textAreaId, comments, finder) {
      
        var commentArea = finder(textAreaId);        
        for ( var i = 0; i < comments.length; i++) {
            var comment = comments[i];
            var commentContent = [];
            if (i%2 == 0) {
                commentContent.push('<div class="comment comment-even">'); 
            } else {
                commentContent.push('<div class="comment comment-odd">');
            }
            commentContent.push('<div class="comment-header">' + comment.createdBy + ' : '
                    + comment.dateCreated + '</div>' + encodeHtml(comment.description) + '</div><br/>');
            commentArea.append(commentContent.join(''));
        }
        return commentArea;
    };

    /**
     * Builds a HTML div which contains the story points of the artifact editor.
     * 
     * @param points the story point of the artifact
     * @returns the HTML content for the story point section.
     */
    this.getPointsHTML = function(points) {
        var pointsContent = [];
        pointsContent.push('<div class="settings-column-row">');
        pointsContent.push(me.buildLabel(points, me.messages['artifact.editor.points.title']));
        pointsContent.push('<div class="artifact-editor-content">' +
            '<input class="inputfield default" id="'+ points +
        '" type="text" name="points" size="4" maxlength="4"></input></div>');
        pointsContent.push('</div>');
        return pointsContent.join('');
    }

    /**
     * Builds a HTML div which contains the effort for the artifact editor.
     * 
     * @param effort the effort of the artifact
     * @param editorIDs the artifact editor IDs
     * @param name the effort name
     * @param title the effort title
     * @returns the HTML content for the effort section.
     */
    this.getEffortHTML = function(effort, editorIDs, name, title) {
        var effortContent = [];
        if  (typeof effort !== "undefined") {
            effortContent.push('<div class="settings-column-row">');
            effortContent.push(me.buildLabel(editorIDs[name], me.messages[title]));
            effortContent.push('<div class="artifact-editor-effort">' +
                '<input class="inputfield default" id="'+ editorIDs[name] + '" type="text" name="'+ name + '" ' +
                'size="6" maxlength="6"></input></div>');
            effortContent.push('<div class="artifact-editor-effort-unit">' +
                '<select class="inputfield default" id="' + editorIDs.trackerUnit + '"type="text" ' +
                'name="trackerUnit" aria-label="trackerUnit"></select></div>');
            effortContent.push('</div>');
        }
        return effortContent.join('');
    }
    
    /**
     * Associates tracker data with quick add HTML container. 
     * 
     * @param artifactCreateEditor the artifactEditor DOM element
     * @param trackerData the Tracker information to present in the artifactCreateEditor
     */
    this.populateAddArtifactData  =function(artifactCreateEditor, trackerData) {
        
        var editorID = me.getEditorID();
        var editorIDs = me.getEditorIDs(editorID);
        
        var finder = function(elemId) {           
            return artifactCreateEditor.find("#" + elemId);
        };
        trackerData.unshift({text:me.messages['common.none'], value:''});
        me.webClient.addDataToSelectWithOptionValue(editorIDs.tracker, trackerData, "", finder);
    };


    /**
     * Associates artifact data with artifacts HTML container. 
     * 
     * @param artifactEditor the artifactEditor DOM element
     * @param artifactData the artifact information to present in the artifactEditor
     */
    this.populateArtifactEditor = function(artifactEditor, artifactData) {
        
        var editorID = artifactEditor.attr('id');
        var editorIDs = me.getEditorIDs(editorID);
    
        var finder = function(elemId) {           
            return artifactEditor.find("#" + elemId);
        };
        me.relationsData = artifactData.parentChildMap;        
        me.fieldMetaData = artifactData.fieldMetaData;
        me.webClient.addDataToField(editorIDs.title,artifactData.title, finder);
        me.webClient.addDataToField(editorIDs.description,artifactData.description, finder);  
        me.webClient.addDataToField(editorIDs.version,artifactData.version, finder);
        me.webClient.addDataToSelect(editorIDs.status, artifactData.statusList, artifactData.status, finder);        
        me.webClient.addDataToSelectWithOptionValue(editorIDs.priority, me.populatePriorityOptions(), artifactData.priority, finder);

        me.webClient.addDataToSelectWithOptionValue(editorIDs.assignedTo, artifactData.assignedToList, artifactData.assignedTo, finder);
        me.addDataToSelectWithAttributeOption(editorIDs.trackerUnit, artifactData.trackerUnitList, artifactData.trackerUnitID, finder);
        me.addDataToEffortField(editorIDs.estimatedEffort, editorIDs.trackerUnit, artifactData.estimatedEffort, finder);
        me.webClient.addAttributeToField(editorIDs.estimatedEffort,'originalValue', artifactData.estimatedEffort, finder);
        me.addDataToEffortField(editorIDs.actualEffort, editorIDs.trackerUnit, artifactData.actualEffort, finder);
        me.webClient.addAttributeToField(editorIDs.actualEffort,'originalValue', artifactData.actualEffort, finder);
        me.addDataToEffortField(editorIDs.remainingEffort, editorIDs.trackerUnit, artifactData.remainingEffort, finder);
        me.webClient.addAttributeToField(editorIDs.remainingEffort,'originalValue', artifactData.remainingEffort, finder);        
        me.webClient.addDataToField(editorIDs.points,artifactData.points, finder);
        me.addCommentHtmlToElement(editorIDs.commentDetails, artifactData.comments, finder);
        me.populateOtherFieldData(artifactData.otherFields, finder);

        if (me.getEditArtifactPermission() || me.getEditCommentPermission()) {
            me.webClient.setInputHints(editorIDs.comment, me.messages['artifact.editor.comments.enter'], finder);
        }
        me.setFieldEditingPermission(artifactEditor, 'input[name$=Effort], select[name=trackerUnit]', !artifactData.autosumming);
        me.setFieldEditingPermission(artifactEditor, 'input[name$=points]', !artifactData.autoSummingPoints);
        me.setFieldEditingPermission(artifactEditor, ':input:not(textarea[name=comment])', me.getEditArtifactPermission());
        me.setFieldLabelWidgets(artifactEditor, artifactData.fieldMetaData);
        me.checkRequiredPrimaryFields(artifactEditor, artifactData,  artifactData.fieldMetaData, finder, editorIDs);
    };

    /**
     * This method populates the other mandatory fields with their values.
     * 
     * @param otherFields the other mandatory fields.
     * @param finder the finder function.
     */
    this.populateOtherFieldData = function(otherFields, finder) {
        $j.each (otherFields, function() {
            if (me.otherFieldPopulator[this.displayType]) {
                me.otherFieldPopulator[this.displayType](this, finder);
                var elem = finder(this.id);
                if (this.isFlexField) {
                    elem.addClass('flexfield');
                } else {
                    elem.addClass('otherfield');
                }
            }
        });
    }

    /**
     * Holds the functions defined for populating different type of other mandatory fields.
     */
    this.otherFieldPopulator = {
        "TEXT" : function(otherField, finder) {
            me.webClient.addDataToField(otherField.id, otherField.value, finder);
            if (otherField.pattern) {
                me.addPatternValidationFieldStyles(finder(otherField.id), otherField.pattern);
                if(otherField.hasErrors) {
                    me.fieldRegexValidationData[otherField.id] = false;
                    if(me.getEditArtifactPermission())
                    me.webClient.markError(finder(otherField.id), me.messages['artifact.editor.invalid.value.error']);
                } else {
                    me.fieldRegexValidationData[otherField.id] = true;
                }
                    
            }            
            if(!otherField.value && me.fieldMetaData[otherField.id].isRequired &&
                    me.getEditArtifactPermission()) {
                me.webClient.markError(finder(otherField.id), me.messages['artifact.editor.required.value.error']);
            }                
         },

         "DROPDOWN" : function(otherField, finder) {
             if (otherField.optionList !== undefined) {
                 if (otherField.value === '') {
                      if(me.fieldMetaData[otherField.id].isRequired && 
                              me.getEditArtifactPermission()) {
                          me.webClient.markError(finder(otherField.id), me.messages['artifact.editor.required.value.error']);
                      }
                 }                
                 me.webClient.addDataToSelectWithOptionValue(otherField.id, otherField.optionList, 
                         me.webClient.getValueForSelectedText(otherField.optionList, otherField.value), finder);
                 
              } else {
                  me.webClient.addDefaultOptionToSelect(otherField.id, me.messages['common.none'], finder, true);
              }           
         }
    };

    /**
     * Adds the pattern validation to the given text field.
     * 
     * @param elem the text field element.
     * @param pattern the pattern to add.
     */
    this.addPatternValidationFieldStyles = function(elem, pattern) {
        elem.addClass('validate');
        elem.data('pattern', pattern);
        elem.attr('placeholder', pattern);        
    }

    /**
     * Removes error message If any.
     * 
     * @param elem the field element.
     */    
    this.clearError = function(elem) {
        elem.closest('.settings-column-row').next('.error-label').remove();        
        elem.closest('.settings-column-row').removeAttr('style'); 
    }

    /**
     * Returns priority option with value and text.
     * 
     * @param priorityId the priority Id.
     */
    this.populatePriorityOption = function(priorityId) {
        
        return priority = {                
                text: me.messages['artifact.priority.value.' + priorityId ],
                value: priorityId   
        };
    };
    
    /**
     * Populates the priority options.
     * @returns priorities the options with text and value of priority.
     */
    this.populatePriorityOptions = function() {
        var priorities = [];        
        for ( var i = 0; i < 6; i++) {
            var priority = me.populatePriorityOption(i);
            priorities.push(priority);
        }
        return priorities;
    };
    
        
    /**
     * Fills in a select with the passed in options along with option values and custom attr.
     *
     * @param selectID the ID of the select
     * @param options the options to populate with Text and Value.
     * @param selectedOption the option which should be selected.     
     * @param finder finds the select element by the selectID
     * @return the DOM element that was updated
     */
    this.addDataToSelectWithAttributeOption = function(selectID, options, selectedOption, finder) {
       var select = finder(selectID);

       for (var i = 0; i < options.length; i++) {
          var option = options[i];         
          var optionElement = $j('<option/>');
          optionElement.text(option.text);
          optionElement.val(option.value);
          optionElement.attr('unitMultiplier', option.unitMultiplier);
          select.append(optionElement);
       }      
       select.val(selectedOption);
       return select;
    };
    
    
    /**
     * Fills a field with the calculated data for effort.
     *
     * @param fieldID the ID of the field to fill
     * @param selectID the selectId of tracker unit.
     * @param data the data to calculate to put into the field
     * @param finder {function} to provide the jquery object from the field ID
     * @return the DOM element that was updated
     */
    this.addDataToEffortField = function(fieldID, selectID, data, finder) {
       var newField = finder(fieldID);
       var selectField = finder(selectID);
       
       var unitMultiplier = selectField.find('option:selected').attr('unitMultiplier');
       newField.val(Math.round(100 * parseFloat(data / unitMultiplier)) / 100);
       
       return newField;
    };
    
    /**
     * Displays formatted success message.
     * 
     * @param artifactId the artifact ID.
     * @param message the success message.
     * @param displayIdAsLink if set to true, displays artifact id as link.
     */
    
    this.displayArtifactSuccessMessage =function(artifactId, message, displayIdAsLink) {
        var artifactKey = [artifactId];
        if (displayIdAsLink) {
            artifactKey = ['<a href=/sf/go/'+artifactId+'?returnUrlKey=' + me.returnUrlKey + ' target="_self">'+artifactId+'</a>'];
        }
        var formatedMessage = me.webClient.formatMessage(message, artifactKey); 
        me.webClient.successMessage(formatedMessage);
    }
    
    /**
     * Returns the effort Fields Array.
     * 
     * @parma artifactEditor the artifact editor.
     */
    this.getEffortFields = function(artifactEditor) {
                
        var editorID = artifactEditor.attr('id');
        var editorIDs = me.getEditorIDs(editorID);
        
        var effortFields = [editorIDs.estimatedEffort,
                            editorIDs.actualEffort,
                            editorIDs.remainingEffort,
                            editorIDs.points];
        return effortFields;
    }
    
    /**
     * Returns the artifact editor if it exists.
     * 
     * @param artifactId the artifact ID
     * @return {jQuery} the artifact editor for the artifact, if one exists.
     */
    this.getArtifactEditor = function(artifactId) {
        return me.webClient.getAsJquery('#' + me.getEditorID(artifactId));
    };
    
    /**
     * Generate an ID prefix that should not collide with other IDs on this page.
     * Since we allow only one pane per Artifact, the artifactId suffices.
     *
     * @param artifactId The ID of the artifact to be edited
     */
    this.getEditorID = function(artifactId) {
       if (artifactId) {
          return me.artifactEditorPrefix + artifactId;
       } else {
          return me.artifactEditorPrefix + 'new';
       }
    };

    /**
     * Returns an object containing all the ID's for a artifact editor.
     * 
     * @param editorID the id of the artifactEditor the fields belong to
     * @returns editorIDs the id's used in the artifact editor
     */
    this.getEditorIDs = function(editorID) {
        var editorIDs = {
                'title' : editorID + '_title',
                'description' : editorID + '_description',
                'version' : editorID + '_version',
                'status' : editorID + '_status',
                'priority' : editorID + '_priority',
                'team'  : editorID + '_selectedTeam',
                'assignedTo' : editorID + '_assignedTo',
                'estimatedEffort' : editorID + '_estimatedEffort',
                'actualEffort' : editorID + '_actualEffort',
                'remainingEffort' : editorID + '_remainingEffort',
                'trackerUnit' : editorID + '_trackerUnit',
                'points' : editorID + '_points',
                'comment' : editorID + '_addComment',
                'commentDetails' : editorID + '_commentDetails',
                'tracker' : editorID + '_tracker'
        };
        return editorIDs;
    };
    
    /**
     * Builds a default accordion header
     * 
     * @param title the display title of the header
     * @param cssClass the class to apply to the header
     * @returns a HTML wrapped <h3 class="cssClass"><a>title</a></h3>
     */
    this.buildAccordionHeader = function(title, cssClass) {
       return ['<h3 class="' + cssClass + '"><a href="#">' + title + '</a></h3>'].join('');
    };

    /**
     * Provides the standard UI element for indicating workflow required field.
     *
     * @returns {String} HTML for widget
     */
    this.getWorkflowRequiredField = function() {
        return '<span class="transitionRequiredFieldMarkInstruction">*</span>';
    }

    /**
     * Disables the editing of the given fields if the user does not have the given permission
     * @param selector the selector for the fields to be disabled
     * @param artifactEditor the artifactEditor DOM element
     * @param hasPermission the permission for the fields
     */
    this.setFieldEditingPermission = function(artifactEditor, selector, hasPermission) {
       if (!hasPermission) {
        artifactEditor.find(selector).attr('disabled', 'disabled');
       }
    };

    /**
     * Set help text and required widget for field labels
     * @param artifactEditor the artifactEditor DOM element
     * @param fieldMetaData field meta data
     */
    this.setFieldLabelWidgets = function(artifactEditor, fieldMetaData) {
        var editorID = artifactEditor.attr('id');
        var editorIDs = me.getEditorIDs(editorID);
        $j.each(fieldMetaData, function(id, fieldMetaDataValueObject) {
            var labelId = editorIDs[fieldMetaDataValueObject.name] !== undefined ? editorIDs[fieldMetaDataValueObject.name] : id;
            var label = $j(artifactEditor.find('label[for="' + labelId + '"]'));
            if (label !== undefined) {
                if (fieldMetaDataValueObject.helpText) {
                    label.parent().after('<span class="help-text-icon" rel="tooltip" data-original-title="' + fieldMetaDataValueObject.helpText +'" data-placement="right" />');
                }
                if (fieldMetaDataValueObject.isRequired !== undefined && fieldMetaDataValueObject.isRequired ) {
                    label.parent().after(me.webClient.getRequiredField());
                }
            }
        });
    };

    this.checkRequiredPrimaryFields = function(artifactEditor, artifactData, fieldMetaData, finder, editorIDs) {
        $j.each(fieldMetaData, function(id, fieldMetaDataValueObject) {
            if (fieldMetaDataValueObject.name == 'priority') {
                if (fieldMetaDataValueObject.isRequired !== undefined &&
                        fieldMetaDataValueObject.isRequired &&
                        artifactData.priority == '0' ) {
                    me.webClient.markError(finder(editorIDs.priority), me.messages['artifact.editor.invalid.value.error']);
                }
                return false;
            } else if (fieldMetaDataValueObject.name == 'assignedTo') {
                if (fieldMetaDataValueObject.isRequired !== undefined &&
                        fieldMetaDataValueObject.isRequired &&
                        me.nobodyUser &&
                        artifactData.assignedTo == me.nobodyUser.id) {
                    me.webClient.markError(finder(editorIDs.assignedTo), me.messages['artifact.editor.invalid.value.error']);
                }
                return false;
            }
        });
    }

    /**
     * Adds workflow required widget to field label
     * @param labelId the label for id
     * @param artifactEditor the artifact editor DOM element
     */
    this.addWorflowRequiredWidgetToField = function(labelId, artifactEditor) {
        var label = $j(artifactEditor.find('label[for="' + labelId + '"]'));
        if (label.length > 0) {
            label.parent().after(me.getWorkflowRequiredField());
            // Add widget to accordion header
            me.addWorflowRequiredWidgetToHeader(label, artifactEditor);
        } else {
            var field = artifactEditor.find('#'+labelId);
            me.addWorflowRequiredWidgetToHeader(field, artifactEditor);
        }
    };

    /*
     * Hide the field widget that has the given labelId
     */
    this.hideWorflowTransitionHiddenField = function(labelId, artifactEditor) {
        var label = $j(artifactEditor.find('label[for="' + labelId + '"]'));
        if (label !== null && label !== undefined && label.length > 0) {
            label.parents('.settings-column-row').hide();
        }
    };

    /**
     * Adds workflow required widget to accordion header.
     * @param element the jQuery field element
     * @param artifactEditor the artifact editor DOM element
     */
    this.addWorflowRequiredWidgetToHeader = function(element, artifactEditor) {
        
        // If element present in settings accordion content add to settings accordion header
        if($j(element).parents('.settings-accordion-content').length > 0) {
             me.appendElementToNodeIfNotExists(artifactEditor, '.settings-accordion-header', '.transitionRequiredFieldMarkInstruction', me.getWorkflowRequiredField());
        // If label element present in other accordion content add to other fields accordion header
        } else if ($j(element).parents('.otherfields-accordion-content').length > 0) {
             me.appendElementToNodeIfNotExists(artifactEditor, '.other-fields-accordion-header', '.transitionRequiredFieldMarkInstruction', me.getWorkflowRequiredField());
        // If element present in comments accordion content add to comments accordion header
        } else if($j(element).parents('.comments-accordion-content').length > 0) {                                  
             me.appendElementToNodeIfNotExists(artifactEditor, '.comments-accordion-header', '.transitionRequiredFieldMarkInstruction', me.getWorkflowRequiredField());  
        }       
        // Add widget instruction to setting accordion header
        me.appendElementToNodeIfNotExists(artifactEditor, '.workflowInstruction', '.transitionRequiredFieldInstructionContainer', me.buildWorkflowRequiredFieldInstruction());
    };

    /**
     * Removes all workflow required widget from editor.
     * @param artifactEditor the artifact editor DOM element
     */
    this.removeAllWorflowRequiredWidget = function(artifactEditor) {
        var requiredFieldWidget = artifactEditor.find('.transitionRequiredFieldMarkInstruction');
        if (requiredFieldWidget.length > 0) {
            me.clearError(requiredFieldWidget);
            requiredFieldWidget.remove();
        }
        var requiredFieldInstructionContainer = artifactEditor.find('.transitionRequiredFieldInstructionContainer');
        if (requiredFieldInstructionContainer.length > 0) {
            requiredFieldInstructionContainer.remove();
        }
    };

    /**
     * Display all the primary attributes, when the status changes
     */
    this.showAllFieldWidget = function(artifactEditor) {
        var allPrimaryData = artifactEditor.find('.settings-column-row');
        if (allPrimaryData !== null && allPrimaryData !== undefined && allPrimaryData.length > 0) {
            allPrimaryData.each(function(index, element) {
                $j(element).show();
            });
        }
        $j(".comments-accordion-header").show();
    };

    /**
     * Builds the workflow required field instruction DOM element
     */
    this.buildWorkflowRequiredFieldInstruction = function() {
        var requiredFieldInstruction = [];
        requiredFieldInstruction.push('<span class="transitionRequiredFieldInstructionContainer">');
        requiredFieldInstruction.push(me.getWorkflowRequiredField());
        requiredFieldInstruction.push(me.messages['artifact.editor.worflow.transition.field.required.instruction']);
        requiredFieldInstruction.push('</span>');
        return requiredFieldInstruction.join('');
    };

    /**
     * Appends element to node if it is not present within node.
     * @param artifactEditor the artifact editor DOM element
     * @param node the node to append the element
     * @param selector the selector to check if present within node
     * @param element the DOM element to be appended to the node
     */
    this.appendElementToNodeIfNotExists = function(artifactEditor, node, selector, element) {
        if (artifactEditor.find(node).children(selector).length === 0) {
            artifactEditor.find(node).append(element);
        }
    };

    /**
     * Sets up the team tree component and selects the assigned team.
     * 
     * @param artifactData the artifact data for the editor
     */
    this.setUpTeam = function(artifactData) {
        var editorID = me.getEditorID(artifactData.id);
        var editorIDs = me.getEditorIDs(editorID);
        var content = $j("#"+editorIDs.team)[0];
        if (!angular.element(content).scope().teamComboTreeModel) {
           angular.element(content).injector().invoke(function($compile) {
                var scope = angular.element(content).scope();
                $compile(content)(scope);
                scope.$apply();
           });
        }

        scope = angular.element(content).scope();
        scope.$apply(function() {
            scope.setupTeamTree(false, true);
            scope.id = editorIDs.team;
            scope.loadData = me.setTeamIdOnSelect;
            $j(content).attr('originalValue', artifactData.assignTeam);
            var assignedTeam = artifactData.assignTeam == '' ? 'None' : artifactData.assignTeam;
            scope.teamComboTreeModel.selected.folderPath = assignedTeam;
        });
    };

    /**
     * Sets the selected team id in the team tree componenet.
     * 
     * @param teamSelectorId the editor team id
     */
    this.setTeamIdOnSelect = function(teamSelectorId) {
        var content = $j("#"+teamSelectorId)[0];
        var selectedTeamId = me.getSelectedTeam(teamSelectorId);
        $j(content).attr('originalValue', selectedTeamId);
    };

    /**
     * Returns the selected team in the team tree componenet.
     * 
     * @param teamSelectorId the editor team id
     * @returns the selected team
     */
    this.getSelectedTeam = function(teamSelectorId) {
        var content = $j("#"+teamSelectorId)[0];
        var selectedTeam = '';
        scope = angular.element(content).scope();
        selectedTeam = scope.teamComboTreeModel.selected.folderPath;
        if (selectedTeam === 'None') {
           selectedTeam = '';
        }

        return selectedTeam;
    };

};
