/*
 * CollabNet TeamForge(r)
 * Copyright 2013 CollabNet, Inc.  All rights reserved.
 * http://www.collab.net
 */
 /*
        Take the value of Effort field (estimated/actual/remaining), divide it by the scalling factor and format it to 2 decimal places.
        Eg.
        3 base units = 1 rock
        We have 2 base units
        Change it to rocks
        Need to display 0.67 rocks
        So, 2 base units
        Multiply this by 100, so it is 200
        Divide by 3, so it is 66.666666666666
        Round it, so it is 67
        Divide by 100, so it is 0.67
        */
  function estimatedEffortComboChange() {
    if (!isNaN($j('#estimatedEffort').val())) {
      $j('#estimatedEff').val(Math.round(100 * parseFloat($j('#estimatedEffort').val()) / getScallingFactor($j('#estimatedEffortUnit').val())) / 100);
    } else {
      $j('#estimatedEff').val("");
    }
  }
  
  function estimatedEffortInputChange() {
    if (!isNaN($j('#estimatedEff').val())) {
        if (getScallingFactor($j('#estimatedEffortUnit').val())== 1) {
            var r = ($j('#estimatedEff').val()) * getScallingFactor($j('#estimatedEffortUnit').val());
          } else {
            var r = Math.round(parseFloat($j('#estimatedEff').val()) * getScallingFactor($j('#estimatedEffortUnit').val()));
          }
          $j('#estimatedEffort').val(r);
    } else {
        $j('#estimatedEffort').val("-1");
    }
     if ($j("#effortSpentOn").is(":checked")) {
             calculateRemainingEffort();
     }
  }

  function effortSpentComboChange() {
       if (!isNaN($j('#effortSpent').val())) {
          $j('#effSpent').val(Math.round(100 * parseFloat($j('#effortSpent').val()) / getScallingFactor($j('#effortSpentUnit').val())) / 100);
       } else {
          $j('#effSpent').val("");
       }
    }

  function effortSpentInputChange() {
      if (!isNaN($j('#effSpent').val())) {
          if (getScallingFactor($j('#effSpent').val())== 1) {
              var r = ($j('#effSpent').val()) * getScallingFactor($j('#effortSpentUnit').val());
          } else {
            var r = Math.round(parseFloat($j('#effSpent').val()) * getScallingFactor($j('#effortSpentUnit').val()));
          }
          $j('#effortSpent').val(r);
      } else {
          $j('#effortSpent').val("-1");
      }
      if ($j("#effortSpentOn").is(":checked")) {
         calculateRemainingEffort();
         calculateActualEffort();
      }
    }
  
  function remainingEffortComboChange() {
    if (!isNaN($j('#remainingEffort').val())) {
        $j('#remainingEff').val(Math.round(100 * parseFloat($j('#remainingEffort').val()) / getScallingFactor($j('#remainingEffortUnit').val())) / 100);
    } else {
        $j('#remainingEff').val("");
    }
  }
	  
  function remainingEffortInputChange() {
    if (!isNaN($j('#remainingEff').val())) {
       if (getScallingFactor($j('#remainingEffortUnit').val())== 1) {
            var r = ($j('#remainingEff').val()) * getScallingFactor($j('#remainingEffortUnit').val());
       } else {
            var r = Math.round(parseFloat($j('#remainingEff').val()) * getScallingFactor($j('#remainingEffortUnit').val()));
       }
       $j('#remainingEffort').val(r);
    } else {
      $j('#remainingEffort').val("-1");
    }
  }

  function actualEffortComboChange() {
      if (!isNaN($j('#actualEffort').val())) {
          $j('#actualEff').val(Math.round(100 * parseFloat($j('#actualEffort').val()) / getScallingFactor($j('#actualEffortUnit').val())) / 100);
      } else {
          $j('#actualEff').val("");
       }
  }

  function actualEffortInputChange() {
    if (!isNaN($j('#actualEff').val())) {
        if (getScallingFactor($j('#actualEff').val())== 1) {
            var r = ($j('#actualEff').val()) * getScallingFactor($j('#actualEffortUnit').val());
        } else {
            var r = Math.round(parseFloat($j('#actualEff').val()) * getScallingFactor($j('#actualEffortUnit').val()));
        }
         $j('#actualEffort').val(r);
    } else {
      $j('#actualEffort').val("-1");
    }
  }
