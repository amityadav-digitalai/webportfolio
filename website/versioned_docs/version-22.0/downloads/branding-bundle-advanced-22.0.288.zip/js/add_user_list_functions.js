/*@COPYRIGHT
*SourceForge(r) Enterprise Edition
*Copyright 2009 CollabNet, Inc. All rights reserved.
*http://www.collab.net
*COPYRIGHT@
*/
 
 
  
  // Function to keep the focus in the searchstring always
  function setFocus() {
    document.addUser.searchString.focus();
  }
  
  
  // This function selects and deselects all the checkboxes
  // With single checkbox on top
  // Calls common methods from SFEE javascript  
  function toggleCheckboxes(checker) {
   
    var chkboxes = document.addUser.userChk;
    if(chkboxes != null) {
      // Check for return value method overloading
      if(chkboxes.type == "checkbox") {
         //it is single node
         chkboxes.checked = checker.checked;
         toggleButtonsCustomized(checker);
       } else {
        for (i = 0; i < chkboxes.length; i++) { 
            chkboxes[i].checked = checker.checked;
        }
        toggleButtonsCustomized(checker);
        }
      }// end of else chkboxes == 0
    }
  
  /**
   * Cross browser function to get
   * document.body.clientHeight correctly
   * */
  function getDocHeight() {
	    var D = document;
	    return Math.max(
	        Math.max(D.body.scrollHeight, D.documentElement.scrollHeight, 
	        		D.body.offsetHeight, D.documentElement.offsetHeight, 
	        		D.body.clientHeight, D.documentElement.clientHeight)
	    );
	}
  
  
  // Resizing function 
  // Responsible for keeping the bottom buttons always visible
  function fitTable() {
      // Rest of all browsers will have resize functionality
      var sheight1= window.innerHeight-300;
      var sheight2= document.body.clientHeight-300;
	  
      //IE8 Hack
      //recalculate sheight2 since document.body.clientHeight does not works fine
      if($j.browser.msie && $j.browser.version.indexOf("8") == 0) {
    	  
    	  if (document.getElementById("maintable").style.height == null) {
	    	  sheight2 = getDocHeight()- 300;
    	  }else {
    		  //if there is already a height set no need to touch anything else
    		  return;
    	  }
      }
      
      if (window.innerHeight){ //checking for browsers that support window.innerWidth
          document.getElementById("maintable").style.height = sheight1 + "px";
          document.getElementById("tbl-container").style.height = sheight1 + "px"; 
          document.getElementById("tbl-containersearch").style.height = sheight1 + "px"; 
      } else if (document.body.clientHeight) { //checking for browsers that support document.body.clientWidth
          document.getElementById("maintable").style.height = sheight2 + "px";
          document.getElementById("tbl-container").style.height = sheight2 + "px"; 
          document.getElementById("tbl-containersearch").style.height = sheight2 + "px"; 
      }
  }
  
  window.onload=fitTable;setFocus;fixFF;
  window.onresize=fitTable;setFocus;fixFF;
   
  window.onload = function() {
    //do onload
    fitTable();
    setFocus();
    fixFF();
   }
  
    window.onresize = function(){
    //do onload
    setFocus();
    fitTable();
    fixFF();
  }


  // Function to handle compression or rows
  // A bug in firefox expands rows in a tbody 
  // This function puts them back to their original size    
  function fixFF() {
    var browser = new Browser();
    if (browser.isNS) {
    var tbodies=document.getElementsByTagName('tbody');
    var mainTbody= document.getElementById("maintbody")
     var tbody = mainTbody;
     if (tbody) {
      var trows = tbody.rows;
      var rowCount = trows.length;
      var rowHeight = trows[0].clientHeight;
      var rowsHeight = rowCount * rowHeight;
      var tbodyHeight = tbody.clientHeight;
      if (rowsHeight >= tbodyHeight) {
       var tbodyStyle = tbody.style;
       if (typeof tbodyStyle != "undefined") {
        var tbodyStyleHeight = tbody.style.height;
        if (typeof tbodyStyleHeight != "undefined") {
         if (rowsHeight >= tbodyHeight) {
               // If real requires size of number of rows are 
               // not fitting in tbody  24 is normal row size 
               if ((rowCount*24) < tbodyHeight ) {
                 tbody.style.height = "auto";
               } else {
                  tbody.style.height = tbodyHeight + "px";
               }
         } else {
            tbody.style.height = "auto";
         }
        }
       }
      }
     }
     
   }
  } 
