/***********************************************
 *                                             *
 *             BEGIN TESTING CODE              *
 *                                             *
 ***********************************************/
var threadCount = 0;
function getTestData() {
    threadCount++;
    return {
	threadId:"" + threadCount,
	startTime:new Date().getTime(),
	url:"/test/url/" + threadCount
    };
}

function setupTestData() {
    var threadData = new Array();
    if (CURRENT_DATA == null) {
	threadData = [getTestData(), getTestData()];
    } else {
	for (var i in CURRENT_DATA) {
	    if (Math.random() < 0.5) {
		threadData.push(CURRENT_DATA[i]);
	    }
	}

	for (var i = 0; i < 6; i++) {
	    if (Math.random() < 0.5) {
		threadData.push(getTestData());
	    }
	}
    }

    var pageData = {"currentDate":new Date().getTime(),
                    "pageData":threadData};
    gotPageData(pageData);
}
/***********************************************
 *                                             *
 *              END TESTING CODE               *
 *                                             *
 ***********************************************/


var baseTime = new Date().getTime();
var MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var THREAD_SPACING = 30;
var GRAPH_DURATION = 10000;

var ATTR_THREAD_ID = "threadName";
var ATTR_START_TIME = "startTime";
var ATTR_URL = "uri";

var CURRENT_DATA = null;
var url = "/sf/sfmain/do/liveActivity?json=1";

function gotPageData(request) {
//    $("ThreadDetails").innerHTML = new Date().getTime();
    var pageData;
    try {
	pageData = eval("(" + request.responseText + ")");
    } catch (e) {
	alert("Error evaluating JSON response: " + e);
    }

    baseTime = pageData["currentDate"];
    CURRENT_DATA = pageData["pageData"];

    if (!isPaused) {
	logDebug("Processing page data");

	drawThreadChart();
	updateLiveActivity();

	logDebug("Done processing page data");
	setTimeout(refreshData, getRefreshDelay());
    }
}

var liveDataFetchFailed = function(request, err) {
    alert("Live data could not be fetched!!!");
};

function refreshData() {
    var doc = new Ajax.Request(url, {'onComplete': gotPageData, 'onFailure': liveDataFetchFailed});
//    setupTestData();
}

// Update the live activity table
var activityTable = "liveActivity";
var rowDisplay = function(row) {
    logDebug("\tCreating row: " + row[0]);

    var rowEl = document.createElement("tr");
    rowEl.setAttribute("id", "lar_" + row[0]);
    if (row != null && row.length != 0 && row[0] == highlightedThreadId) {
	rowEl.setAttribute("style", "background-color: #EEF;");
    }

    for (var i = 0; i < row.length; i++) {
	var cell = document.createElement("td");
	cell.appendChild(document.createTextNode(row[i]));
	rowEl.appendChild(cell);
    }

    logDebug("\tCompleted creating row: " + row[0]);
    return rowEl;
}

var updateLiveActivity = function() {
    var rows = [];
    logDebug("Updating live activity table");
    if (CURRENT_DATA != null && CURRENT_DATA.length != null) {
	for (var i=0; i<CURRENT_DATA.length; i++) {
	    rows.push([ CURRENT_DATA[i].id,  CURRENT_DATA[i].uri, CURRENT_DATA[i].username ]);
	}

	logDebug("\tCreating live activity table");
	var newTable = document.createElement("table");
	newTable.setAttribute("id", "liveActivity");
	newTable.setAttribute("class", "ContainerWithBorder");
	newTable.setAttribute("cellpading", "5");

	var thead = document.createElement("thead");
	var headerRow = document.createElement("tr");
	headerRow.setAttribute("style", "background-color: #AAA;")

	logDebug("Creating table headers");

	var headers = ["Id", "URI", "Username"];
	for (var i = 0; i < headers.length; i++) {
	    var headerCell = document.createElement("td");
	    if (i != 1) {
		headerCell.setAttribute("style", "width: 100px;");
	    }

	    headerCell.appendChild(document.createTextNode(headers[i]));
	    headerRow.appendChild(headerCell);
	}


	// Append the header row to the thead and then the thead to the table
	thead.appendChild(headerRow);
	newTable.appendChild(thead);

	logDebug("Appending display rows");

	// Create the table body
	var tbody = document.createElement("tbody");
	for (var i = 0; i < rows.length; i++) {
	    tbody.appendChild(rowDisplay(rows[i]));
	}

	newTable.appendChild(tbody);

	logDebug("Completed activity table.  Swapping...");

	var activityTableEl = $(activityTable);
	var parent = activityTableEl.parentNode;

	parent.replaceChild(newTable, activityTableEl);
    }

    logDebug("Completed updating live activity table");
}


function getPageData() {
    return CURRENT_DATA;
}

function zeroPad(number, digits) {
    var padded = "" + number;
    while (padded.length < digits) {
	padded = "0" + padded;
    }
    return padded;
}

function getDateString(date) {
    return MONTH_NAMES[date.getMonth()] + " " + date.getDate() + ", " +
	   date.getHours() + ":" + zeroPad(date.getMinutes(), 2) + ":" +
	   zeroPad(date.getSeconds(), 2) + "." + zeroPad(date.getMilliseconds(), 3);
}

function drawTimeLine(chartEl, leftPos, height, label, count) {
    var labelEl;
    var timeLineEl = $("TimeLine_" + count);
    if (timeLineEl == null) {
	var lineDivEl = document.createElement("div");
	lineDivEl.id = "TimeLine_" + count;
	lineDivEl.style.left = leftPos + "px";
	lineDivEl.style.height = height + "px";
	lineDivEl.style.position = "absolute";
	lineDivEl.style.borderLeft = "1px dashed #F00;";

	// First draw the time line
	chartEl.appendChild(lineDivEl);

	// Now draw the label
	labelEl = document.createElement("div");
	labelEl.id = "TimeLabel_" + count;
	labelEl.style.top = "-15px";
	labelEl.style.position = "absolute";
	labelEl.style.fontSize = "9px";
	labelEl.style.whiteSpace = "nowrap";

	labelEl.appendChild(document.createTextNode(label));
	chartEl.appendChild(labelEl);
    } else {
	timeLineEl.style.height = height + "px";
	labelEl = $("TimeLabel_" + count);
	labelEl.innerHTML = label;
    }
    labelEl.style.left = (leftPos - (labelEl.offsetWidth / 2)) + "px";
}

function getElementId(threadData) {
    return threadData[ATTR_THREAD_ID].replace(/[^a-zA-Z0-9]/gm, "_") + "_" + threadData[ATTR_START_TIME];
}

var THREAD_POSITIONS = {};
var THREAD_IDS = [];
function drawPageThread(chartEl, threadData, left, width, overflow) {
    var elementId = getElementId(threadData);

    var newPositions = {};
    var pageEl = $(elementId);
    if (pageEl == null) {
	// Figure out where this thread should go
	var top = 0;
	for (var i = 0; i < THREAD_IDS.length; i++) {
	    if (THREAD_IDS[i] == null) {
		top = 5 + i * THREAD_SPACING;
		THREAD_IDS[i] = elementId;
		newPositions[elementId] = i;
		break;
	    }
	}

	var appendNew = false;
	if (top == 0) {
	    top = 5 + THREAD_IDS.length * THREAD_SPACING;
	    appendNew = true;
	}

	pageEl = document.createElement("div");
	pageEl.setAttribute("id", elementId);
	pageEl.setAttribute("style", "border: 1px solid #999; " +
				     "border-right: 0px none; " +
				     "top: " + top + "px; " +
				     "left: " + left + "px; " +
				     "width: " + width + "px; " +
				     "background-color: #EEE; " +
				     "position: absolute; " +
				     "height: 10px;");

	chartEl.appendChild(pageEl);
	pageEl.onmouseover = function() {
	    showThreadInformation(elementId, threadData);
	};
	pageEl.onmouseout = clearThreadInformation;

	if (appendNew) {
	    THREAD_IDS.push(elementId);
	}
    } else {
	pageEl.style.left = left + "px";
	pageEl.style.width = width + "px";
	newPositions[elementId] = THREAD_POSITIONS[elementId];
    }

    THREAD_POSITIONS = newPositions;

    if (overflow) {
	var currentDuration = baseTime - threadData[ATTR_START_TIME];
	var labelText = threadData[ATTR_URL] + " - " + currentDuration + "ms";

	if (threadData["id"] != highlightedThreadId) {
	    pageEl.style.borderLeft = "0px none;"
	    pageEl.style.borderRight = "0px none;"
	    pageEl.style.borderTop = "1px solid #F00;"
	    pageEl.style.borderBottom = "1px solid #F00;"
	}
	
	// See if the page has a label
	var labelEl = $("OVERFLOW_" + elementId);
	if (labelEl == null) {
	    labelEl = document.createElement("div");
	    labelEl.setAttribute("id", "OVERFLOW_" + elementId);
	    labelEl.setAttribute("style", "text-align: center; font-size: 9px; color: #F00; font-weight: bold;");
	    labelEl.appendChild(document.createTextNode(labelText));

	    pageEl.appendChild(labelEl);
	} else {
	    labelEl.innerHTML = labelText;
	}
    }
}

var isPaused = false;
function drawThreadChart() {
    if (isPaused) {
	return;
    }

    logDebug("Refreshing thread chart");

    // clearThreadInformation();
    var pageData = getPageData();

    logDebug("Got page data.  Figure out existing threads.")
    // Figure out which threads we already have
    var displayed = {};
    for (var i = 0; i < THREAD_IDS.length; i++) {
	displayed[THREAD_IDS[i]] = "foo";
    }

    logDebug("Getting page ids.")
    for (var i = 0; i < pageData.length; i++) {
	var potentialId = getElementId(pageData[i]);
	displayed[potentialId] = null;
    }

    // Now remove any unused elements
    logDebug("Removing unused elements");
    for (var i in displayed) {
	if (displayed[i] != null) {
	    var oldThread = $(i);
	    if (oldThread != null) {
		oldThread.parentNode.removeChild(oldThread);
		for (var j = 0; j < THREAD_IDS.length; j++) {
		    if (THREAD_IDS[j] == i) {
			THREAD_IDS[j] = null;
			break;
		    }
		}
	    }
	}
    }

    var chartContainerEl = $("ThreadChart");

    // First get the start and end time
    var endTime = baseTime;
    var startTime = endTime - GRAPH_DURATION;

    // We have to figure out how far down the lowest thread is drawn
    logDebug("Figure out where lowest thread goes");
    var threadPosition = 0;
    for (var i = 0; i < THREAD_IDS.length; i++) {
	if (THREAD_IDS[i] != null) {
	    threadPosition = i + 1;
	}
    }
    threadPosition = Math.max(threadPosition, pageData.length);

    var chartHeight = threadPosition * THREAD_SPACING;
    var chartWidth = chartContainerEl.offsetWidth;
    chartContainerEl.style.height = chartHeight + 20;

    var tickDuration = Math.round(GRAPH_DURATION / 6);
    var tickSpacing = chartWidth / 5;

    // draw the time lines
    for (var i = 0; i < 6; i++) {
	drawTimeLine(chartContainerEl,
		     tickSpacing * i,
		     chartHeight,
		     getDateString(new Date(startTime + (tickDuration * i))),
		     i);
    }

    // draw the pages
    var top = 5;
    for (var i = 0; i < pageData.length; i++) {
	var threadData = pageData[i];
	var threadDuration = endTime - threadData[ATTR_START_TIME];
	var overflow = false;
	if (threadDuration > GRAPH_DURATION) {
	    overflow = true;
	    threadDuration = GRAPH_DURATION;
	}

	var adjustedStart = Math.max(0, threadData[ATTR_START_TIME] - startTime);

	var width = (threadDuration / GRAPH_DURATION) * chartWidth;
	var left = Math.round((adjustedStart / GRAPH_DURATION) * chartWidth);
	drawPageThread(chartContainerEl, threadData, left, width, overflow);
    }

    logDebug("Completed refreshing thread chart");
}

function getRefreshDelay() {
    var timeoutRegexp = new RegExp("^[0-9]+$");
    var timeout = $("UpdateDelay").value;
    if (timeout < 250 || !timeoutRegexp.test(timeout)) {
	window.status = "Illegal timeout: " + timeout + ".  Defaulting to 2000.";
	timeout = 2000;
    } else {
	window.status = "";
    }

    return timeout;
}

function togglePause() {
    isPaused = !isPaused;
    if (isPaused) {
	$("PauseButton").value = "Resume Updates";
    } else {
	$("PauseButton").value = "Pause Updates";
	refreshData();
    }
}

var THREAD_DETAIL_NAME_STYLE = "width: 5%; white-space: nowrap; padding-right: 5px;";

var highlightedThread = null;
var highlightedThreadId = null;
function showThreadInformation(threadId, threadData) {
    highlightedThread = threadId;
    $(highlightedThread).style.border = "1px solid #DD0";

    var tableRow = $("lar_" + threadData.id);
    if (tableRow != null) {
	tableRow.style.backgroundColor = "#eef";
    }
    highlightedThreadId = threadData.id;
}

function clearThreadInformation() {
    if (highlightedThreadId != null) {
	var tableRow = $("lar_" + highlightedThreadId);
	if (tableRow != null) {
	    tableRow.style.backgroundColor = "inherit";
	}
	highlightedThreadId = null;
    }

    if (highlightedThread != null) {
	var pageEl = $(highlightedThread);

	if (pageEl.childNodes.length > 0) {
	    pageEl.style.borderLeft = "0px none;"
	    pageEl.style.borderTop = "1px solid #F00;"
	    pageEl.style.borderBottom = "1px solid #F00;"
	} else {
	    pageEl.style.border = "1px solid #999";
	}

	pageEl.style.borderRight = "0px none;"

	highlightedThread = null;
    }
}

var logDebug = function(message) {
    return;

    // do nothing for now.
    var bodyEl = document.getElementsByTagName("body")[0];
    bodyEl.appendChild(document.createTextNode(message));
    bodyEl.appendChild(document.createElement("br"));
}