

var $j = jQuery.noConflict();

var pageLimit = 99;
var rowsPerPage = pageLimit / 3;
var showMore = "Show more results...";

// report info
var reportInfo = null;
// report columns
var reportColumns = null;
// list of users
var userList = []
// number of pages loaded
var pagesLoaded = 0;
// itempath - report path for UserGrap
var itemPath = null;
var imageHeight = 0;
var imageWidth = 0;

function setgraphDetails(reportitemPath, reportInfoQueryString, imgHeight, imgWidth){
	itemPath = reportitemPath;
	reportInfo = reportInfoQueryString;
	imageHeight = imgHeight;
	imageWidth = imgWidth;
}

function addgraphUser(userName){
	userList.push(userName);
}

function setshowMoreMessage(showmoreMsg){
	showMore = showmoreMsg;
}

function getgraphUser(fromIndex, toIndex) {
	return userList.slice(fromIndex-1, toIndex);
}

function showuserGraphRows(fromIndex, toIndex) {
	// show the records
	var data = getgraphUser(fromIndex, toIndex); 
	// get the number of rows -> pagesLoaded  
	var noofRows = pagesLoaded * rowsPerPage; 
	var currRowNum = noofRows +1; 
	var tdCount = 0;
	var domRow = null;
	var rowId = null;
	var domCell = null;
	var domI = null;
	for (user in data) {	
		if(tdCount %3 == 0) {
			// create a new row and append it
			rowid = "row_" + currRowNum;			
			domRow = document.createElement("tr");
			domRow.setAttribute("id",rowid); 
			tdCount = 0;
			// add the row to the table
			if(currRowNum == 1) {
				// first time
				$j("#dummyHeader").after(domRow);
			} else {
				var prevrowId = currRowNum - 1;
				var prevRow = "row_" + prevrowId;
				$j("#" + prevRow).after(domRow);
			}
			currRowNum++;
		}
		domCell = document.createElement("td");
		domCell.setAttribute("width","33%");
		domCell.setAttribute("align","centre");
		domCell.setAttribute("class","ItemDetailContainerCell");
		domI = document.createElement("img");
		domI.setAttribute("src","/sf/reporting/do/userGraph/"+itemPath +"?username="+data[user]+"&"+reportInfo);
		domI.setAttribute("width",imageWidth);
		domI.setAttribute("height",imageHeight);
		domI.setAttribute("border",0)
		domCell.appendChild(domI);
		// 3 graphs per row
		domRow.appendChild(domCell);
		tdCount++;
	}
	pagesLoaded++;
	addshowMore();
}

function addrowtoTable(newElement,beforeElement){
	$j(beforeElement).before(newElement);
}

function addshowMore() {
    $j("#moreMsg").remove();
	frmIndex = pagesLoaded * pageLimit + 1;
	if(frmIndex > userList.length) {
		return;
	}
	toIndex = frmIndex + pageLimit - 1 ;
	if(toIndex > userList.length) {
		toIndex = userList.length;
	}
	
	$j("#treeFooter").before("<tr id='moreMsg'><td colspan=\"3\" align=\"left\"><a href=\"javascript:showuserGraphRows(" + frmIndex + "," + toIndex +")\">" + showMore + "</a> </tr>");
}

