/*@COPYRIGHT
 *TeamForgeForge(r) Enterprise Edition
 *Copyright 2013-2014 CollabNet, Inc. All rights reserved.
 *http://www.collab.net
 *COPYRIGHT@
 */

/**
 * Modules.
 */

Artifacts = new ArtifactsHandler(WebClient);

/**
 * Helps create artifact widgets.
 */

function ArtifactsHandler(webClientHandler) {
        this.webClient = webClientHandler;
        var projectPathString;
        this.permissions = {};
        this.messages = {};
        this.columnOptions = {};
        this.expanded = new Array();
        var me = this;

        /**
         * Set project path.
         * @param projectPathString the project path.
         */
        this.setProjectPath = function(projectPathString) {
             me.projectPathString = projectPathString;
        };

        /**
         * Sets the permissions required for planing board.
         * @param permissions the permission JSON.
         */
        this.setPermissions = function(permissions) {
             me.permissions = permissions;
        };

        /**
         * Sets the messages required for planing board.
         * @param messages the messages JSON.
         */
        this.setMessages = function(messages) {
            me.messages = messages;
        };
        
        /**
         * Sets url key for further use by artifact cards
         */
        this.setReturnUrlKey = function(returnUrlKey) {
      	  this.returnUrlKey = returnUrlKey;
        }

        /**
         * Sets the options on the planning columns.
         * @param the planning column options.
         */
        this.setUpPlanningOptions = function(planningColumnOptions) {
           columnOptions = planningColumnOptions;
        }

        /**
         * Creates a header for the Artifacts widget.
         * @param artifact the artifact JSON data.
         * @param hideExpander whether to hide the expander icon
         */
         this.createHeaderHTML = function(artifact, hideExpander, columnName) {
                var data = [ '<div class="item-common item-header">',
                             me.createDependencySign(artifact, hideExpander, columnName)];
                data.push(me.createTrakerIcon(artifact));
                data.push('<div class="item-key">',
                	'<a href="/sf/go/',	artifact.artifactId, '?returnUrlKey=' + me.returnUrlKey + '" target="_blank">',
                   artifact.artifactId, '</a></div>',
                   '<div class="item-priority">(',
                   ((artifact.priority) ? ('P' + artifact.priority) : me.messages['artifact.priority.value.'+artifact.priority]), ')</div>');
                  if(artifact.canEdit){ 
                   data.push('<i class="artifact-edit"><img src="/sf-images/pngs/edit_artifact.png" alt="',me.messages['edit.artifact.details'],'" /></i>');                   
                  } else {
                    data.push('<i class="artifact-edit"><img src="/sf-images/icons/sidebar-viewTeam.png" style="width: 15px; height: 10px" alt="',me.messages['view.artifact.details'],'" /></i>');                   
                  }
                   
                   data.push(me.createEffortDisplayHTML(artifact));
                data.push('</div>');
                return data.join('');
         };

         /**
          * Creates the tracker icon in the artifact card.
          *
          * @param artifact the artifact JSON.
          * @returns html which makes up the tracker icon HTML in the card.
          */
         this.createTrakerIcon = function(artifact) {
             var data = [];
             data.push('<div class="item-key-icon trackerIcon" title="', me.messages['application.Tracker'], ': ', artifact.trackerName, '">');
             (artifact.trackerIcon) ? data.push('<img src="/sf-images/tracker/icons/', 
                       artifact.trackerIcon, '" alt="\', me.messages[\'application.Tracker\'], \': \', artifact.trackerName, \'"' +
                 '>') :  data.push('');
             data.push('</div>');
             return data.join('');
         }

         /**
          * Creates the effort HTML displayed in the artifact card.
          *
          * @param artifact the artifact JSON.
          * @returns html which makes up the effort display HTML in the card.
          */
         this.createEffortDisplayHTML = function(artifact) {

             var data = [];
             var effortDisplay;
             if (artifact.points !== undefined) {
                 effortDisplay = me.getStoryPointsHTML(artifact);
             } else if (artifact.estimatedEffort !== undefined) {
                 effortDisplay = me.getEffortHTML(artifact.trackerUnit, artifact.estimatedEffort);
             }

             if (effortDisplay) {
                 data.push('<div class="item-efforts" title="');
                 data.push(me.createEffortHoverText(artifact), '">');
                 data.push(effortDisplay);
                 data.push('</div>');
             }

             return data.join('');
         }

         /**
          * Creates the story point HTML in the artifact card.
          *
          * @param artifact the artifact JSON.
          * @returns html which makes up the story point HTML
          */
         this.getStoryPointsHTML = function(artifact) {
             if (artifact.points == 0 && artifact.estimatedEffort > 0) {
                 return me.getEffortHTML(artifact.trackerUnit, artifact.estimatedEffort);
             }

             return me.getEffortHTML(me.messages['artifact.card.points'], artifact.points);
         }

         /**
          * Creates the effort HTML in the artifact card.
          *
          * @param artifact the artifact JSON.
          * @returns html which makes up the effort HTML
          */
         this.getEffortHTML = function(unit, value) {
             var data = [
                          '<span class="effort-unit">', unit, '</span>',
                          ':',
                          '<span class="effort-value">', value, '</span>'
                        ];
             return data.join('');
         }

         /**
          * Creates the hover text for the effort fields in the artifact card.
          *
          * @param artifact the artifact JSON
          * @returns the hover text for effort fields
          */
         this.createEffortHoverText = function(artifact) {
             var data = [];
             if (artifact.points !== undefined) {
             data.push(me.createEffortFieldText(me.messages['artifact.card.points'], 
                     artifact.points, ';'));
             }

             var effortArr = [];

             if (artifact.estimatedEffort !== undefined) {
             effortArr.push(me.createEffortFieldText(me.messages['artifact.card.estimated'], 
            		 artifact.estimatedEffort, '/'));
             }
             effortArr.push(me.createEffortFieldText(me.messages['artifact.card.remaining'], 
            		 artifact.remainingEffort, '/'));
             effortArr.push(me.createEffortFieldText(me.messages['artifact.card.actual'], 
            		 artifact.actualEffort, '/'));
             var effortText = effortArr.join('')
             if (effortText.length > 0) {
            	 data.push(artifact.trackerUnit, ': ');
            	 data.push(effortText);
             }
             
             return data.join('').slice(0,-1);
         }

         /**
          * Creates the hover text for each effort field in the artifact card.
          *
          * @param text the effort text
          * @param value the effort value
          * @param seperator the field separator
          * @returns the hover text for effort field
          */
         this.createEffortFieldText = function(text, value, separator) {
        	 var data = [];
             if (value !== undefined) {
            	 var data = [text, ': ', value, ' ', separator];
             } 

             return data.join('');
         }

         /**
          * Creates artifact dependency handler.
          * @param artifact the artifact JSON data.
          * @param hideExpander whether to hide the expander icon
          */
         this.createDependencySign = function(artifact, hideExpander, columnName) {
             var data = [];
             
             if(artifact.hasChildren) {
                 if(hideExpander) {
                     data.push('<div class="dependency"><span class="artifact-expander-grey" title="', me.messages['planning.child.restriction.level'],'">+</span></div>');                         
                 } else {
                     data.push('<div class="dependency clickable"><span class="artifact-expander ', columnName, '-', artifact.artifactId, '-expander">+</span></div>');
                 }   
             }
             
             return data.join('');
         };

        /**
         * Generate markup for a draggable DIV containing the artifact information.
         *
         * @param artifact the artifact JSON.
         * @param hideExpander whether to hide the expander icon
         * @returns html which makes up a visible artifact widget
         */
        this.createHTMLWidget = function(artifact, hideExpander, columnName) {
                var artifactId = artifact.artifactId;
                var version = artifact.version;
                var itemClasses = 'item ui-corner-all ui-draggable';
                var artifactClasses=['artifact-priority '] ;
                if(artifact.priority >= 0) {
                    priorityClass = ' priority' + artifact.priority;
                    artifactClasses.push(priorityClass);
                }
                var artifactPriorityHTML = artifactClasses.join('');
                var columnNameWithArtifactId = columnName + "-" +artifactId;
                var data = [ '<div id="', columnNameWithArtifactId, '" class="', itemClasses,'"data-id="', artifactId, '" data-key="', artifactId, '" data-parent-id="', artifact.parentArtifactId, '" data-version="', version,'">',
                             '<div class="displayNone tracker" data-id="', artifact.tracker, '"></div>',
                             '<div class="artifact' + ((artifact.statusClass == 'Close') ? ' artifact-closed ' : ''),
                             '"><table class="artifact-card"><tr id="item">',
                             '<td class="',artifactPriorityHTML,'" title="', me.messages['Task.priority'], ' ',
                             me.messages['artifact.priority.value.'+artifact.priority], '"></td>',
                             '<td>',
                             me.createHeaderHTML(artifact, hideExpander, columnName),
                             me.createTitleHTML(artifact, artifactPriorityHTML),
                             me.createAssignedToHTML(artifact),
                            '</td></tr></table></div>'];
                if(artifact.hasChildren) {
                    data.push('<div class="childContainer item-destination-'+artifactId+'"></div>');
                }               
                data.push('</div>');
                return data.join('');
        };

        /**
         * Creates the assigned to HTML in the artifact card.
         *
         * @param artifact the artifact JSON.
         * @returns html which makes up the assigned to HTML
         */
        this.createAssignedToHTML = function(artifact) {
        	var assignedTo = artifact.assignedTo;
        	if (assignedTo == null) {
        		assignedTo = me.messages['common.none'];
        	} 
        	var data = [
        	            '<div class="item-common item-assigned-to">', 
        	            '<div class="assigned-to" title="', assignedTo, '">'];
        	
        	data.push('<img class="avatar avatar24" src="', artifact.avatarUrl,'" alt="Assigned To"/>');

            data.push(assignedTo,'</div>',
        	            '<div class="item-status item-right-wrap item-status-margin">', artifact.status, '</div>',
                        '</div>');
        	return data.join('');
        };

        /**
         * Creates the title HTML in the artifact card.
         *
         * @param artifact the artifact JSON.
         * @param artifactPriorityHTML the predefined priority classes
         * @returns html which makes up the title HTML
         */
        this.createTitleHTML = function(artifact, artifactPriorityHTML) {
        	var data = [
        	            '<div class="item-common item-title" title="', artifact.title,'">', 
                         artifact.title,
                        '</div>']
        	return data.join('');
        };

        /**
         * Saves the current location of the artifact widget.
         *
         * @param artifactWidget {jQuery} the widget to save the location for
         */
        this.rememberLocation = function(artifactWidget) {
           var previousArtifact = artifactWidget.prev('.item');
           var parentContainer;
           var sourcePlanningFolderPath = artifactWidget.closest('.table-column').find('.content-selector').combo('getValue');
           var sourceTeamScope = artifactWidget.closest('.table-column').find('.widgets-team-tree').scope();
           var sourceTeamId = sourceTeamScope.teamComboTreeModel.selected.folderPath;
           var sourceTeamName = sourceTeamScope.teamComboTreeModel.selected.text;
           var sourceColumnId = artifactWidget.closest('.table-column').attr('id');
           var parentArtifactId = me.webClient.getItemId(artifactWidget.parents('.item'));
           if(parentArtifactId) {
               parentContainer = artifactWidget.parents('.item-destination-'+parentArtifactId);
           } else {
               parentContainer = artifactWidget.parents('.item-destination');
           }
           artifactWidget.data('previousArtifact', previousArtifact).data('parentContainer', parentContainer).data('sourcePlanningFolderPath', sourcePlanningFolderPath).data('sourceTeamId', sourceTeamId).data('sourceTeamName', sourceTeamName).data('sourceColumnId', sourceColumnId);
        };

        /**
         * Removes the previous location information from the widget.
         *
         * @param artifactWidget {jQuery} the widget to clean up.
         */
        this.forgetLocation = function(artifactWidget) {

                artifactWidget.removeData('previousArtifact').removeData('parentContainer').remove('sourcePlanningFolderPath');
        };

        /**
         * Determines whether the widget is dropped to its original location in the column.
         * @param artifactWidget the artifact widget
         * @returns {Boolean} true if the widget is dropped to its original location in the column.
         */
        this.isDroppedToOriginalLocation = function(artifactWidget) {
           var targetPreviousArtifact = artifactWidget.prev('.item');
           var targetPreviousArtifactId = me.webClient.getItemId(targetPreviousArtifact);

           var artifactId = me.webClient.getItemId(artifactWidget);

           if (artifactId === targetPreviousArtifactId) {
              return true;
           }

           var originalPreviousArtifactId = me.webClient.getItemId(artifactWidget.data('previousArtifact'));
           
           return (targetPreviousArtifactId === originalPreviousArtifactId &&
                 me.isDroppedToOriginalContainer(artifactWidget));
        };

        /**
         * Returns true if the artifact widget is being dropped to the source container
         * or into a copy of the container.
         *
         * @param artifactWidget the widget
         * @returns true if the artifact widget is dropped into its original parent.
         */
        this.isDroppedToOriginalContainer = function(artifactWidget) {
           var targetContainer = this.getColumn(artifactWidget);
           var originalContainer = this.getOriginalColumn(artifactWidget);
           var sourceColumnId = artifactWidget.data('sourceColumnId');
           var destinationColumnId = artifactWidget.closest('.table-column').attr('id');
           return targetContainer.attr('class') === originalContainer.attr('class') &&
              sourceColumnId === destinationColumnId;
        };

        /**
         * Get the jQuery object for the containing planning column.
         *
         * @param {jQuery} artifactWidget one or more artifact widgets to locate
         */
        this.getColumn = function(artifactWidget) {
           return artifactWidget.parents('.item-destination').parent();
        };

        /**
         * Get the jQuery object for the original containing planning column.
         *
         * @param {jQuery} artifactWidget artifact widget to locate
         */
        this.getOriginalColumn = function(artifactWidget) {
           return artifactWidget.data('parentContainer').parent();
        };

        /**
         * Handles dropping artifact items.
         *
         * @param artifactWidget {jQuery} the widget being moved
         * @param planningFolderSelections the column selections
         */
        this.handleDropRequest = function(artifactWidget, planningFolderSelections) {
           var moveData = this.getMoveArtifactData(artifactWidget, planningFolderSelections);
           if (moveData.sourceColumnId == moveData.destinationColumnId &&
           moveData.destinationPlanningFolderPath == me.projectPathString) {
             //trying to move within PF-None..hence throw error ranking will not be done
               me.webClient.alert(me.messages['planning.rank.artifact.none'],  me.messages['error.text'],
               me.moveWidgetToOriginalLocation(artifactWidget));
               return;
           }
           this.moveArtifact(artifactWidget, moveData);
        };
        
        /**
         * Hides no results found message if it exists
         * 
         * @param Artifact widget being moved
         */
        this.hideNoResultsMessageIfExists = function(artifactWidget) {
        	artifactWidget.closest('.planningColumn').find('.item-nodata').hide();
        }
        
        /**
         * Shows no results found message if it exists
         * 
         * @param Artifact widget being moved
         */
        this.showNoResultsMessageIfExists = function(artifactWidget) {
        	artifactWidget.closest('.planningColumn').find('.item-nodata').show();
        }
        
        /**
         * Displays info message for child artifacts when the Child is hidden
         * inside Parent and closed artifact hidden after the change planning folder move.
         * 
         * @param moveData the artifact move data.
         * @param isClosedArtifact true if artifact is closed
         */        
        this.handleSucessMessage = function(moveData, isClosedArtifact) {  
        	var artifactId = moveData.actualArtifactId;
        	var destinationPlanningFolderPath = moveData.destinationPlanningFolderPath;
            var artifactWidget = me.getArtifactWidgets(artifactId);
            var planningContainer = me.findTargetParentWidgets(destinationPlanningFolderPath);
            var planningFolderName = planningContainer.closest('.table-column').find('.content-selector').combo('getText');
            var artifactKey = '<a href=/sf/go/'+artifactId+'?returnUrlKey=' + me.returnUrlKey + ' target="_self">'+artifactId+'</a>';
            
        	if (moveData.destinationPlanningFolderPath !== moveData.sourcePlanningFolderPath) {
        		var arguments = [artifactKey, '<b>'+encodeHtmlAttribute(planningFolderName)+'</b>'];
                //Default success message for artifact move
                var successMessage = me.messages['artifact.moved.success.message'];
                
                if(!artifactWidget.is(':visible')) {
                    if (isClosedArtifact) {
                    	successMessage = me.messages['artifact.closed.moved.success.message'];
                    } else {
                    	successMessage = me.messages['artifact.child.moved.success.message'];
                    }
                } 
                var formatedMessage = me.webClient.formatMessage(successMessage, arguments);
                me.webClient.successMessage(formatedMessage);
            } else if (moveData.destinationTeamId !== moveData.sourceTeamId) {
                var arguments = [artifactKey];
                if (moveData.destinationTeamId === 'None') {
                    arguments.push('');
                    me.webClient.successMessage(me.webClient.formatMessage(me.messages['artifact.team.unassigned.success.message'], arguments));
                } else if (moveData.destinationTeamId.indexOf('team') != -1) {
                    arguments.push('<b>'+encodeHtmlAttribute(moveData.destinationTeamName)+'</b>');
                    me.webClient.successMessage(me.webClient.formatMessage(me.messages['artifact.team.assigned.success.message'], arguments));
                }
           }
        };

        /**
         * Creates the data for moving the artifact represented by the widget.
         *
         * @param widget the widget.
         * @param planningFolderSelections the column selections
         * @returns the data for moving the backlog item
         */
        this.getMoveArtifactData = function(widget, planningFolderSelections) {

           var previousArtifact = widget.prev('.item');
           var destinationPlanningFolderPath = this.webClient.getItemId(widget.parents('.planningColumn'));
           var teamScope = widget.closest('.table-column').find('.widgets-team-tree').scope();
           var destinationTeamId = teamScope.teamComboTreeModel.selected.folderPath;
           var destinationTeamName = teamScope.teamComboTreeModel.selected.text;
           var nextArtifact = widget.next('.item');
           var sourcePlanningFolderPath = widget.data('sourcePlanningFolderPath');
           var sourceTeamId = widget.data('sourceTeamId');
           var sourceTeamName = widget.data('sourceTeamName');
           var sourceColumnId = widget.data('sourceColumnId');
           var parentArtifactId = widget.data('parentId');
           var destinationColumnId = widget.closest('.table-column').attr('id');
           return {
              actualArtifactId: this.webClient.getItemId(widget),
              previousArtifactId: this.webClient.getItemId(previousArtifact),
              nextArtifactId: this.webClient.getItemId(nextArtifact),
              destinationPlanningFolderPath: destinationPlanningFolderPath,
              sourcePlanningFolderPath: sourcePlanningFolderPath,
              planningFolderSelections: planningFolderSelections,
              sourceTeamId: sourceTeamId,
              destinationTeamId: destinationTeamId,
              sourceTeamName: sourceTeamName,
              destinationTeamName: destinationTeamName,
              sourceColumnId: sourceColumnId,
              destinationColumnId: destinationColumnId,
              parentArtifactId: parentArtifactId,
              artifactVersion:this.webClient.getItemVersion(widget)
           };
        };

        /**
         * Send the move request to the server.
         *
         * Schedule callbacks for handling the results of the move.
         * @param {jQuery} artifactWidget artifact element being moved.
         * @param moveData javascript object containing move metadata.
         */
        this.moveArtifact = function(artifactWidget, moveData) {
           var url = '/sf/projectboards/do/moveArtifact/' + me.projectPathString;
           var cleanup = function() {
              me.forgetLocation(artifactWidget);
              me.clearPending(moveData.actualArtifactId);
           };
           var parentArtifact = "#" + moveData.sourceColumnId + "-" + moveData.parentArtifactId;
           var data = $j(parentArtifact).data();
           me.expanded = [];
           if (data != null) {
           var containerLevel = data.containerLevel;
           while(containerLevel >= 1) {
                me.expanded.push(moveData.sourceColumnId + "-" + data.id + "-expander");
                if (data.parentId === "") {
                   break;
                }
                parentArtifact = "#" + moveData.sourceColumnId + "-" + data.parentId;
                data = $j(parentArtifact).data();
                if(data !=null) {
                  containerLevel = data.containerLevel;
                } else {
                  containerLevel = 0;
                  }
           }
           }

           var moveBackAndCleanup = function() {
              me.moveWidgetToOriginalLocation(artifactWidget);
              cleanup();
           };

           var failure = function(request) {
                   me.webClient.alert(me.messages['projectboard.planning.refresh.error'],  me.messages['error.text'], moveBackAndCleanup);
           };

           var success = function(response) {
              if ((response.action !== undefined) && (response.action === "render")){
                  if(columnOptions.updateAction && response.artifacts) {
                      columnOptions.updateAction(response.artifacts, moveData);
                      var isClosedArtifact = artifactWidget.find('.artifact').hasClass('artifact-closed');
                      me.handleSucessMessage(moveData, isClosedArtifact);
                  } else {
                      var parentArtifactId = me.webClient.getItemId(artifactWidget.parents('.item'));
                      me.moveArtifacts(moveData, parentArtifactId);
                      var selectors = me.webClient.getAsJquery('.content-selector');
                      $j.each(selectors, function(key, value){
                        var columnId = $j(value).closest('.table-column').attr('id');
                        var planningFolderName = $j(value).closest('.table-column').find('.content-selector').combo('getValue');
                        if(columnId !== moveData.sourceColumnId && moveData.sourcePlanningFolderPath === planningFolderName) {
                          columnOptions.updateColumnData($j(value), true);
                        }
                      });
                  }
                  cleanup();
                  me.highlightArtifact(moveData.actualArtifactId);
              } else if ((response.action !== undefined) && (response.action === "refresh")) {
                  me.webClient.handleLogout();
              } else {
                  if (response.message && me.messages[response.message]) {
                      me.webClient.alert(me.messages[response.message],  me.messages['error.text'], moveBackAndCleanup);
                  } else {
                      me.webClient.alert(me.messages['projectboard.planning.refresh.error'],  me.messages['error.text'], moveBackAndCleanup);
                  }
              }
           };
           me.hideNoResultsMessageIfExists(artifactWidget);
           me.markPending(moveData.actualArtifactId);
           me.webClient.postJSON(url, moveData, success, failure);
        };
        
        /**
         * Handle page updates when a move operation succeeds.
         *
         * @param moveData the artifact data for the widget being moved
         */
        this.moveArtifacts = function(moveData, parentArtifactId) {
           var oldWidgets = this.getArtifactWidgets(moveData.actualArtifactId);
           $j.each(oldWidgets, function(key, value){
        	 var artifactWidget = $j(value);
        	 var coulmnId = $j(value).closest('.table-column').attr('id');
        	 if(coulmnId === moveData.sourceColumnId) {
               $j(value).remove();           
               me.insertArtifact(artifactWidget, moveData, parentArtifactId);
        	 }
           });
        };

        /**
         * Insert a artifact into the given position on the page.
         *
         * @param artifactWidget {jQuery} the artifact to insert
         * @param moveData the artifact data for the widget being moved.
         */
        this.insertArtifact = function (artifactWidget, moveData, parentArtifactId) {
            
           var newContainers = this.findTargetParentWidgets(moveData.destinationPlanningFolderPath);
           if (moveData.previousArtifactId != null) {
              var items = this.getArtifactWidgets(moveData.previousArtifactId);
              $j.each(items, function(key, value){
                var coulmnId = $j(value).closest('.table-column').attr('id');
                if(coulmnId === moveData.sourceColumnId) {
                  $j(value).after(artifactWidget);
                }
              });
           } else {
               var destination;
               if(parentArtifactId) {
                   destination = newContainers.find('.item-destination-'+parentArtifactId);
               } else{
                   destination = newContainers.find('.item-destination');
               }
               $j.each(destination, function(key, value){
                 var coulmnId = $j(value).closest('.table-column').attr('id');
                 if(coulmnId === moveData.sourceColumnId) {
                   $j(value).prepend(artifactWidget);
                 }
               });
           }

        };

        /**
         * Mark the artifact as having pending updates.
         *
         * @param artifactId
         * @returns the Widgets that were updated
         */
        this.markPending = function(artifactId) {
           var allArtifactWidgets = this.getArtifactWidgets(artifactId);
           return allArtifactWidgets.addClass('pending');
        };

        /**
         * Mark the artifact as done updating.
         *
         * @param artifactId
         * @returns the Widgets that were updated
         */
        this.clearPending = function(artifactId) {
           var allArtifactWidgets = this.getArtifactWidgets(artifactId);
           return allArtifactWidgets.removeClass('pending');
        };

        /**
         * Highlights the artifact after move.
         *
         * @param artifactId
         * @returns the updated widget
         */
        this.highlightArtifact = function(artifactId) {
           var artifactWidgets = this.getArtifactWidgets(artifactId);
           return artifactWidgets.find('.artifact').addClass('artifact-edited');
        };

        /**
         * Returns all of the artifact Widgets with the given ID
         *
         * @param id the ID of the widget
         */
        this.getArtifactWidgets = function(id) {
           var selector = '.item[data-id="' + id + '"]';
           return this.webClient.getAsJquery(selector);
        };


        /**
         * Moves the artifact widget back to its original location.
         *
         * @param widget the widget to move back.
         */
        this.moveWidgetToOriginalLocation = function(widget) {
        	me.showNoResultsMessageIfExists(widget);
           if (widget.data('previousArtifact').length > 0) {
              widget.insertAfter(widget.data('previousArtifact'));
           } else {
              widget.prependTo(widget.data('parentContainer'));
           }
        };
        
        /**
         * Finds all parent widgets the artifact can be part of on the screen.
         *
         * @param destinationPlanningFolderPath the planning folder Path
         */
        this.findTargetParentWidgets = function(destinationPlanningFolderPath) {
              return this.webClient.getAsJquery('.planningColumn[data-id="' + destinationPlanningFolderPath + '"]');
        };


}
