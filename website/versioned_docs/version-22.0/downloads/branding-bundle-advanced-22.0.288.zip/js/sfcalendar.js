
var _JS_CALENDAR_FORMAT

function setJsCalendarFormat(format) {
    _JS_CALENDAR_FORMAT = format;
}

var calendar = null;

function calSelected(cal, date) {
    cal.sel.value = date;

    var updateFlexElements = document.getElementsByName('updateF' + cal.sel.name.substring(1));
    if ((typeof updateFlexElements != "undefined") && (updateFlexElements.length > 0)) {
        var elem = updateFlexElements[0];
        if (elem.type == "checkbox") {
            elem.checked = true;
        }
    }
    cal.callCloseHandler();
} // calSelected

function calCloseHandler(cal) {
    cal.hide();

    if (typeof calendarCloseHandle == 'function') {
        calendarCloseHandle(cal);
    }
} // calCloseHandler

function calShow(id) {
    var el = document.getElementById(id);

    if (calendar != null) {
        calendar.hide(); // hide the existing calendar
    } else {
        var cal = new Calendar(false, null, calSelected, calCloseHandler);

        calendar = cal;
        calendar.setDateFormat(_JS_CALENDAR_FORMAT);
        calendar.weekNumbers = false;
        calendar.create();
    }
    calendar.parseDate(el.value, _JS_CALENDAR_FORMAT); // set it to a new date
    calendar.sel = el;
    calendar.showAtElement(el);
    // calendar.addEvent(document, "mousedown", checkCalendar);
    return false;
} // calShow
