/*
 * CollabNet TeamForge(r)
 * Copyright 2007-2014 CollabNet, Inc.  All rights reserved.
 * http://www.collab.net
 * 
 * This code snippet handles the in line editing functionality over Artifact tables 
 * 
 * @author Rodrigo Jaen (rodrigo.jaen@bvision.com)
 * 
 * See MassUpdateArtifactsInLineEditAction for more details
 */

//to know if we are in a tracker view or planning folder view

var itsTracker = (contains(window.location.href,'listArtifacts') || contains(window.location.href,'/go/tracker') || contains(window.location.href,'/tracker.')); 
//the index of the data in the artifact table
var trIndex = (itsTracker) ? 5 : 6;
var rowTableConstant = (itsTracker) ? 4 : 5;

var progressBar = false;
var continueAsking;
var timeoutValue;
var progress = 0;
var errorCount = 0;
var updateMessage = "";
var errorMap;
var errorMapKeys = [];
var textFlexFieldResultSpanPattern = "_fv_result";
var editMode = false;
var artifactsThatShouldNotBeCollapsed = new Object();
var artifactsModified = [];
var visibleColumns = "";
var fieldsCache = new Object();
var hiddenValuesCache = new Object();
var trkUnitMultiplier = 0;
var MESSAGE_URL_PARAMETER = "_message=";
var ACTUAL_EFFORT_FIELD_CONSTANT = "Actual Effort";
var ESTIMATED_EFFORT_FIELD_CONSTANT = "Estimated Effort";
var REMAINING_EFFORT_FIELD_CONSTANT = "Remaining Effort";
var NON_EDITABLE_FIELDS = ["submittedByFullname_head", "lastModifiedDate_head", "submittedDate_head", "closeDate_head", "folderTitle_head", "tags_head"];
function getEffortFieldErrorMessage() {
    return EFFORT_FIELD_ERROR_MESSAGE;
}

function getEffortFieldDecimalErrorMessage() {
    return EFFORT_FIELD_DECIMAL_ERROR_MESSAGE;
}

/**
 * return name or description cannot be empty message
 * */
function getDescriptionOrTitleFieldCannotBeEmptyMessage(headerName) {
    
    if (contains(headerName ,"description_head")) {
        return DESCRIPTION_FIELD_MESSAGE + REQUIRED_MESSAGE;
    } else {
        return TITLE_FIELD_MESSAGE  + REQUIRED_MESSAGE;      
    }
} 

//cache that holds the map [fieldName|fieldId]
var fieldNameIds ;
var isPlanningFolderFrozen = false;
var frozenPlanningFolders = [];
var planningFolderPathMap = {};

var userDatePattern;

var CALCULATOR_ON = "/sf-images/tracker/autosummingOn.png";
var CALCULATOR_OFF = "/sf-images/tracker/autosummingOff.png";
var BELL_ON = "/sf-images/icons/monitored_item.png";        
var BELL_OFF = "/sf-images/icons/unmonitored_item.png";

/*hierarchy vars*/
var flexFieldMapIdName;
var removeFromCache = false;
var hierarchyFieldsAttributesCache = new Object();

/**
 * Switch to edit mode
 * */
function changeToEditMode(inlineHelpText){
    editMode = !editMode;

    //disble filter row 
    $j.each($j("input[name^=_filter]"), function(i, value) {
      $j(this).prop("disabled",true);
    });

    //disable angular widget based filters
     $j.each($j("div[id^='_filter']"), function(i,value) {
       $j(this).children("multi-select-tree").remove();
     });

    //disable multiselect filter widget if present
	var $autoSummingPointSelect = $j('select[name^=_filter]:not([name*=dateRange], [name$=autosumming],[name$=autoSummingPoints])');
	if ($autoSummingPointSelect.length > 0 && $autoSummingPointSelect.multiselect) {
		$autoSummingPointSelect.multiselect("disable");
	}

    $j("table#ArtifactListTableData > tbody > tr:first").before(inlineHelpText);
    $j('#_SfButton_inLineEditSaveButton').show();
    $j('#_SfButton_inLineEditCancelButton').show();
    $j('#_SfButton_inLineEditModeButton').hide();

    //floatingFooter buttons
    $j(".floatingFooter").find("#_SfButton_inLineEditSaveButton").show();
    $j(".floatingFooter").find("#_SfButton_inLineEditCancelButton").show();
    $j(".floatingFooter").find("#_SfButton_inLineEditModeButton").hide();
    $j(".floatingFooter").find("#_SfButton_MassUpdate").attr("id", "_SfButton_MassUpdate1");
    setButtonState("_SfButton_MassUpdate1", "disabled");
    $j("li.contextual-menu").attr("style", "visibility: hidden");
    //collect data for the init of the field ids
    collectColumnsNamesToInitFieldIds();


    //initialize a map with the ids of the fields that have and can be edited on the current view
    initFieldsIds();
    
    //disable if present
    var $autoSummingSelect = $j('select[name^=btn_filter]:not([name*=dateRange], [name$=autosumming])');
    if ($autoSummingSelect.length > 0 && $autoSummingSelect.multiselect)  {
    	$autoSummingSelect.multiselect("disable");
    }
    
    //if its planning folder we need the server response to do this, so call it from initFieldsIds()
    if (itsTracker) {
    	renderTheRestOfTheTable();
    }

    unbindSaveButtonFromBeforeUnloadEvent();
    
    //if the user leaves the page without saving, alert of the situation only if there are changes.
    setLeavingPageWithOutSavingAlert();

}

/**
 * Perform the dom manipulations on the artifact table in order to edit
 * */
function renderTheRestOfTheTable() {

    //disabled footer bar buttons and links before editing
    $j.each( $j("#ArtifactListTableFooter").children().find(".Button"), function(i, value) {
    
        if ($j(this).attr("id") == null){
            $j(this).attr("id", "temp" + i);
        }
        
        if (!contains($j(this).attr("id"),"_SfButton_inLineEditCancelButton")
                && !contains($j(this).attr("id"),"_SfButton_inLineEditSaveButton")){
            setButtonState($j(this).attr("id"), "disabled");
        }
        
        if (contains($j(this).attr("id"),"_SfButton_Monitor")){
            setButtonState("_SfButton_Monitor", "disabled");
            addDisabledStyleToElement($j(this));
            $j("#selectionMenuButton_MonitorMenu_selectArtifactsForm").attr("onclick","").unbind("click");
        }
        
    });
    
    if (!itsTracker) {
        //in order to successfully remove all possible event handlers
        //clone the element and remove current ones
        var $clonedSubmitArtifactButton = $j(".visibleFooter").last().children().find(".Button").last().clone();
        
        $j(".visibleFooter").first().children().find(".Button").last().remove();
        $j(".visibleFooter").last().children().find(".Button").last().remove();
        
        //add the cloned and dead button to the footer bars
        $j("#_SfButton_Monitor").first().parent().append($clonedSubmitArtifactButton);
        $j("#_SfButton_Monitor").last().parent().append($clonedSubmitArtifactButton);
        addDisabledStyleToElement($j("#_SfButton_Monitor"));
        addDisabledStyleToElement($j(".ButtonSelection"));
        addDisabledStyleToElement($j("#selectionMenuButton_createArtifactMenu1"));
        addDisabledStyleToElement($j("#selectionMenuButton_createArtifactMenu"));
    }
    addDisabledStyleToElement($j("#selectionMenuButton_MonitorMenu_selectArtifactsForm"));
    
    //disabling links    
    $j.each($j(".OddRow td").children("a"), function(i, value) {
        $j(this).attr("href","#");
        $j(this).unbind("click");
        $j(this).bind("click",stopHrefClickDefaultBehaviour);
    });
    
    $j.each($j(".EvenRow td").children("a"), function(i, value) {
        $j(this).attr("href","#");
        $j(this).unbind("click");
        $j(this).bind("click",stopHrefClickDefaultBehaviour);
    });
    
    //remove sort arrows on the columns
    $j.each($j("a[id^=_sort_]"), function(i, value) {
        $j(this).remove();
    });
    
    //disable filter selects
    $j.each($j("select[name^=_filter]"), function(i, value) {
        $j(this).prop("disabled",true);
    });
    
    //disable filter inputs
    $j.each($j("input[name^=_filter]"), function(i, value) {
        $j(this).prop("disabled",true);
    });
    
    //disable user-flex field
    $j.each($j("input[name^=_FullName]"), function(i, value) {
        $j(this).prop("disabled",true);
        $j(this).siblings().attr("class", "inline-edit-disabled");
        $j(this).siblings().children("a").attr("onclick", "");
    });
    
    //add pencil edit images    
    $j.each($j(".edit"), function(i, value) {
 
    	//avoid the pencil if the column its not editable
    	if (!allowedToEditColumnFields($j(this).attr("headers"))) {
    		return;
    	}
    	
    	//Shows a hand hovering on the cell background of editable text
    	$j(this).css("cursor", "pointer");
    	
    	 //in case of some artifacts that belong to a view only permission tracker
    	 //we don't allow the user to edit
    	 if (!itsTracker) {
	  		var id = $j(this).parent().attr("id");
			id = id.substring(id.lastIndexOf("_") + 1, id.length);
			if (!getFieldItsFromANonEditableTracker($j(this).attr("headers"), id)) { 
				$j(this).removeClass("edit");
	            $j(this).removeClass("numeric");
	            $j(this).unbind('click');
	            return;
			}
   	  	}
    	
    	var fieldName    = name.substring(0, name.lastIndexOf("_"));
    	
        //if it is alien should not be editable
        if (!itsTracker && isAlien($j(this).parent())){
            $j(this).removeClass("edit");
            $j(this).removeClass("numeric");
            $j(this).unbind('click');
        }
        
        setAutoSummingAndMonitoringIcons($j(this));
        
    });
    
    //replace expand and collaps images with inlineedit src images
    var expandCollapseImg = $j("#ArtifactListTableData").find("img[class=Branch][id^=img_]");
    if (!itsTracker && expandCollapseImg != null) {
    	$j.each(expandCollapseImg, function(i, value){
    		var srcImage = $j(value).attr('src');
    		if (contains(srcImage,"nolines.gif")) {
    			$j(value).attr('src',srcImage.replace("nolines", "nolines_inlineedit"));
    		}
	
    		$j(value).attr('style','cursor: pointer !important;');
    	});
    }
    
    greyOutNonEditableFields(null);
    
    //remove if exist the link to show more artifacts
    if ($j("#moreMsg") != null ) {
        $j("#moreMsg").remove();
    }
    
    $j.each( $j("[class='FilterAppButton last-button'][id='ChooseColumns']").parent().children(), function(i, value){
		 $j(this).attr("onclick", "");
		 addDisabledStyleToElement( $j(this));
		 $j.each($j(this).find("a"), function(i, value){
			 $j(this).attr("onclick", "");
			 $j(this).css("cursor","default");
		 });

		 $j.each($j(this).find("img"), function(i, value){
			 $j(this).css("cursor","default");
		 });
	 });
    
     // disable the planning folder view select field.
    var viewSelectField = $j("select#planning_folder_view_select");
    addDisabledStyleToElement(viewSelectField);
    viewSelectField.prop("disabled", "disabled");
    
    var extraClassName = "";
    if (!itsTracker) {
        extraClassName = " last-button";
    }
    
    //disable the buttons for the configure column 
    if (!itsTracker) {
        //handle ranking button
        var rankButtonOffImg = $j(".TreeListGridButtonOff").find("img");
        rankButtonOffImg.parent().first().attr("href", "#");
        rankButtonOffImg.parent().first().bind("click",stopHrefClickDefaultBehaviour);
        rankButtonOffImg.parent().last().attr("href", "#");
        rankButtonOffImg.parent().last().bind("click",stopHrefClickDefaultBehaviour);
        rankButtonOffImg.css("cursor","default");
        $j(".TreeListGridButtonOff").first().attr("onclick", "");
        addDisabledStyleToElement($j(".TreeListGridButtonOff").last());
        addDisabledStyleToElement($j(".TreeListGridButtonOff").first());
        $j(".TreeListGridButtonOff").last().attr("onclick", "");
        //removing hand in sort button.
        addDisabledStyleToElement($j(".TreeListGridButtonOn"));
        $j.each ($j("[class='FilterAppButton FirstButton" + extraClassName + "'][id='ChooseColumns']"), function(i, value) {
        	$j(this).attr("onclick", "");
        	addDisabledStyleToElement($j(this));
        	$j(this).find("img").css("cursor","default");
        });

        $j.each($j(".TreeListGridButtonOff").children().children().children().children(), function(i, value){ 
        	addDisabledStyleToElement($j(this));
            $j(this).attr("onclick", "");
        });
    }else {
        //disable filter, saved and apply button
    	 $j.each($j("#applyfilterbutton").parent().children(), function(i, value){
    		 $j(this).attr("onclick", "");
    		 addDisabledStyleToElement($j(this));
    		 $j.each($j(this).find("a"), function(i, value){
    			 $j(this).attr("onclick", "");
    			 $j(this).css("cursor","default");
    		 });
    		 
    		 $j.each($j(this).find("img"), function(i, value){
    			 $j(this).css("cursor","default");
    		 });
    	 });
    }
    $j.each($j("input[name='autosumming_value']"), function(i, value) {
        if ($j(this).val() == "true") {
            $j(this).parent().css("cursor","not-allowed");
            $j(this).parent().css("opacity","0.6");
    	}
    });
    $j.each($j("input[name='autoSummingPoints_value']"), function(i, value) {
        if ($j(this).val() == "true") {
            $j(this).parent().css("cursor","not-allowed");
            $j(this).parent().css("opacity","0.6");
        }
    });
    //remove the hability to togle buttons on click for the checkbox
    //since we are on edit mode it does not make any effect.
    $j("input[type=checkbox]").removeAttr('checked').prop("disabled",true);
    refreshFooterButtons();
    unbindSaveButtonFromBeforeUnloadEvent();
}

/**
 * prevent the default jumping top event triggered by clicking on a <a> link
 * @param e event
 * */
function stopHrefClickDefaultBehaviour(e) {
  e = e || window.event;
  if (e.preventDefault) {
	  e.preventDefault();
  } else { 
	  e.returnValue = false;
  }
}

/**
 * set the disabled look and feel to an html element
 * @param element to be updated
 * */
function addDisabledStyleToElement(element) {
	element.css("cursor","default");
	element.css("opacity","0.4");
}

/**
 * if the cell its empty add the correct calculator or bell icon
 * */
function setAutoSummingAndMonitoringIcons(currentTd) {
	
	  if (contains(currentTd.attr("headers"),"monitoring") && currentTd.children().length == 0){
          var img = $j('<img border="0" alt="Unmonitored item" id="'+ "monitor_off"  +'" src="' + BELL_OFF  + '">');
          img.attr("style","float:left");
          currentTd.append(img);
      }
      
      if (contains(currentTd.attr("headers"),"autosumming") && currentTd.children("img").length == 0){
          var img = $j('<img border="0" alt="" id="'+ "autosumming_off"  +'" src="' + CALCULATOR_OFF  + '">');
          img.attr("style","float:left");
          currentTd.append(img);    
      }

      if (contains(currentTd.attr("headers"),"autoSummingPoints") && currentTd.children("img").length == 0){
          var img = $j('<img border="0" alt="" id="'+ "autosumming_off"  +'" src="' + CALCULATOR_OFF  + '">');
          img.attr("style","float:left");
          currentTd.append(img); 
      }
}

/**
 * set grey background color to any cell that belongs
 * to non editable fields
 * @param specificRow a specific TR element table row
 * */
function greyOutNonEditableFields(specificRow) {
	
	var skipFilterRow = false;
	
	if (!itsTracker) {
		NON_EDITABLE_FIELDS = ["submittedByFullname_head", "lastModifiedDate_head", "submittedDate_head", "closeDate_head", "folderTitle_head", "artf_head", "tags_head"];
	} else {
		//skip the first as its the filter cell on tracker view
		skipFilterRow = true;
	}

	if (specificRow == null ) {
		$j.each( NON_EDITABLE_FIELDS, function(i, value) {
			$j.each( $j("[headers='" + value  + "']"), function(i, value) {
				if (!skipFilterRow || i > 0) {
					$j(this).addClass("inline-edit-disabled");
				}
			});
		});
	} else {
			$j.each( specificRow, function(i, value) {
				if ((!skipFilterRow || i > 0) && ($j.inArray($j(this).attr("headers"), NON_EDITABLE_FIELDS) > -1)) {
					$j(this).addClass("inline-edit-disabled");
				}
			});
	}	
		
	
}

/**
 * Remove the before unload event from buttons to avoid
 * */
function unbindSaveButtonFromBeforeUnloadEvent(){

	//if we are saving remove the on before unload so the browser won't ask before reloading.
	$j('#_SfButton_inLineEditSaveButton').bind("click",function(event) {
	    $j('body').removeAttr('onbeforeunload');
	    return true;
	});
	

	$j('#_SfButton_inLineEditSaveButton').bind("click",function(event) {
	    $j('body').removeAttr('onbeforeunload');
	    return true;
	});

	if ($j.browser.msie) {
		// if it is IE we need to change the href attributte from the button
		// otherwise it will fire the onbeforeunload button, generating the popup on saving
		// or the popup fired twice when canceling the operation
		$j(".floatingFooter").find("#_SfButton_inLineEditSaveButton").children().find("a").attr("href","#");
		$j(".floatingFooter").find("#_SfButton_inLineEditSaveButton").children().find("a").bind("click",stopHrefClickDefaultBehaviour);
		$j(".floatingFooter").find("#_SfButton_inLineEditSaveButton").children().find("a").attr("onclick","saveChanges();");
		$j(".floatingFooter").find("#_SfButton_inLineEditCancelButton").children().find("a").attr("href","#");
		$j(".floatingFooter").find("#_SfButton_inLineEditCancelButton").children().find("a").bind("click",stopHrefClickDefaultBehaviour);
		$j(".floatingFooter").find("#_SfButton_inLineEditCancelButton").children().find("a").attr("onclick","reloadPage();");
		$j("#_SfButton_inLineEditCancelButton").children().find("a").attr("href","#");
		$j("#_SfButton_inLineEditCancelButton").children().find("a").bind("click",stopHrefClickDefaultBehaviour);
		$j("#_SfButton_inLineEditCancelButton").children().find("a").attr("onclick","reloadPage();");
	}

}

/**
 * Generate a new Progress object and store it in cache 
 * */
function updateProgressCache() {
  jQuery.ajax({
               type: 'GET',
               url: '/sf/ctf-api/main/updateProgressCache',
               async: false,
               dataType: 'html',
              }).done(function(data) {
                   var data1 = data.split(',');
                   data = data1[1].replace('"', '').replace('"', '').replace('\n','');
                   $j("[name=progressGuid]").val(data);
                   saveChanges();
              });
} 

/**
 * Save user changes on the table
 * */
function saveChanges(){

  if(!isHttpTest && !isSessionActive()) {
    showSessionTimeoutDiv('updateProgressCache');
    return;
  }
	//errors
    var errors = new Object();
    //error key array to keep order
    var errorsIndex = []; 
    
    //if there were  no modifications then just reload
    if (artifactsModified.length == 0){
          reloadPage();
          return;
    }
    
    editMode = !editMode;
    
    //prepare the json object that will contain maps of artfid-[field:value]
      var artifactChanges = buildArtifactFieldChangesToJSON(errors, errorsIndex);

      if (getObjectSize(artifactChanges) == 0) {
          //maybe the user click on a editable field, but it returned no value from server
          //so the artifact is marked to update but there were no changes
          //is that is the case skip the saving;
          
          return reloadPage();
      }
      
      //there were validation error so hold the horses
      if (getObjectSize(errors) > 0) {
          
          var errorCount = getObjectSize(errors);
          var errorAdded = 0;
          var errorMaxToDisplay = 20;
          
          var errorMessage = errorCount + " " + PENDING_ERRORS_VALIDATION + " \n \n";
          errorsIndex.sort();
          
          $j.each(errorsIndex, function(i, value){
              
        	  if (errorAdded < errorMaxToDisplay) {
	        	  errorMessage = errorMessage + " " + errors[value] + "\n";
	              errorAdded++;
              }
        	  
          });
          
          alert(errorMessage);
          editMode = !editMode;
          setLeavingPageWithOutSavingAlert();
          unbindSaveButtonFromBeforeUnloadEvent();
          
          return;
      }
    
    //remove the alert of leaving the page since the user its confirming the changes
    window.onbeforeunload = null;
      
    //prepare the overlay pop up that contain the progress bar
    initOverlay();
        
    //start asking the server about the progress of the save and display the % on the progress bar
    checkAndUpdateProgress();
        
    var saveUrl = "/sf/tracker/do/massUpdateArtifactsInLineEdit/" + getUrlExtraParams() + "?progressGuid=" + $j("[name=progressGuid]").val();

    if (contains(window.location.href,'/go/')) {
        saveUrl = "/sf/tracker/do/massUpdateArtifactsInLineEdit" + getProject()  + "?progressGuid=" + $j("[name=progressGuid]").val();
    }
    //post changes to server
    $j.ajax({    
      type: "POST",
      cache: false,
      url: saveUrl,
      contentType: "application/json; charset=utf-8",
      data: JSON.stringify(artifactChanges),
      success: function(data){
          $j('.ajax').html(encodeHtml($j('.ajax input').val()));
          $j('.ajax').removeClass('ajax');
      }
      });
      
      return;
}

/**
 * Start the overlay pop up that will cover the screen with a shade and show the progress bar
  */
function initOverlay(){
	
	$j('#boxes').modal({'backdrop': 'static'});
	$j('.btn').click(function (e) {
          reloadPage();
	});

	//add an empty element to force the footer of the modal to show up
	//hide the button we don't need it unless there are errors
	$j('.btn').hide();
}


function hideOverlay(){
    $j('#mask, .window').hide();
}

/**
 * Start the progress bar box which will consume the progress value, that comes from the server
 * */
function setProgressBar(){

        $j('#progressBar').show();    
            running = true;
            var $this = $j(this);
            var inter = null;
            function run(){
            	var totalWidth = 200;
            	var progressBarElement = '<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tr>';
            		
            		//first part of the progress bar
            		if (progress == 0) {
            			progressBarElement = progressBarElement + '<td><div style=\"background-color:#dfebb7; width:2; height:20;\">&nbsp;</div></td>';
            		} else {
            			progressBarElement = progressBarElement + '<td><div style=\"background-color:#aecd4c; width:2; height:20;\">&nbsp;</div></td>';
            		}
            		totalWidth = totalWidth - 2;
            		
            		//the content on the middle: empty bar or full bar
            		if (progress == 0) {
            			var tempTotalWidth = totalWidth - 2;
            			progressBarElement = progressBarElement + '<td><div style=\"background-color:#dfebb7; width:' + tempTotalWidth + '; height:20\">&nbsp;</div></td>';
            			progressBarElement = progressBarElement + '<td><div style=\"background-color:#dfebb7; width:2; height:20;\">&nbsp;</div></td>';	
            		} else if (progress == 100) {
            			var tempTotalWidth = totalWidth - 2;
            			progressBarElement = progressBarElement + '<td><div style=\"background-color:#aecd4c; width:' + tempTotalWidth + '; height:20\">&nbsp;</div></td>';
            			progressBarElement = progressBarElement + '<td><div style=\"background-color:#aecd4c; width:2; height:20;\">&nbsp;</div></td>';	
            		} else {
            			//some progress done, render the completed progress plus the empty parts
            			var leftWidth =  (totalWidth - 3) / 100 * progress;
            			totalWidth = totalWidth - leftWidth;
            			var tempTotalWidth = totalWidth - 2;
            			progressBarElement = progressBarElement + '<td><div style=\"background-color:#aecd4c; width:' + leftWidth + '; height:20\">&nbsp;</div></td>';
            			progressBarElement = progressBarElement + '<td><div style=\"background-color:#aecd4c; width:5; height:20;\">&nbsp;</div></td>';
            			progressBarElement = progressBarElement + '<td><div style=\"background-color:#dfebb7; width:' + tempTotalWidth +'; height:20\">&nbsp;</div></td>';
            			progressBarElement = progressBarElement + '<td><div style=\"background-color:#dfebb7; width:2; height:20;\">&nbsp;</div></td>';
            		}
            		
            		progressBarElement = progressBarElement + '</tr></table>';
            	
            		var totalArtifacts = artifactsModified.length;
            		var currentCompleted = Math.round((progress * totalArtifacts) / 100);
            		$j('#progressBar').html(progressBarElement);
            		$j('.completed-text').html(POP_UP_COMPLETED + " " + currentCompleted + " " + POP_UP_OF + " " + totalArtifacts  + " " + POP_UP_ARTIFACTS + "("+progress+"%" + ")");
            		
                if(progress == 100){
                    clearInterval(inter);
                    running = false;
                }
            }
            inter = setInterval(run, 50);
}

/**
 * Ask the server the progress of the instance which id is saved on the hidden input progressGuid.
 * The response will be a % value, which will update the progress var and decides to finish
 * and reload the page or not based on if there are or not issues
 * */
function checkAndUpdateProgress(){
    
    if (continueAsking){
        var progressUrl = "/sf/tracker/do/massUpdateArtifactsInLineEditProgress"+ "?progressGuid="+ $j("[name=progressGuid]").val();

        console.log('progressUrl '+progressUrl);
        //if it is IE it sometimes use cache instead using the ajax, hence adding a random parameter to avoid cache.
        if ($j.browser.msie) {
            progressUrl =  progressUrl + "&" + Math.random();
        }
        
        $j.getJSON(progressUrl, function(data) {
            if (data === undefined) {
                // We had an issue.
                alert(SERVER_ERROR_MESSAGE);
              } else{
                  progress = parseInt(data["progress"]);
                  errorCount = parseInt(data["errors"]);
                  errorMap = data["errorMap"];
                  updateMessage = data["updateMessage"];
              }
          });

        //while progress is < 100, we keep asking server and refreshing the progress bar every 1 second
        if (progress < 100){
            timeoutValue = setTimeout(checkAndUpdateProgress,1000);
        }else{

            //once we are done, clear the timer and display error with accept button, or reload if there are no errors
            continueAsking = false;
            clearTimeout(timeoutValue);

            if (errorCount != null && errorCount > 0 && errorMap != null){
            	
            	//show the close button
            	$j('.modal-footer').children().first().show();

            	var temp = $j.map(errorMap, function(value, key) {
                     errorMapKeys.push(key); 
                    });

                 //show errors
                 $j("#inLineEditErrorsContainer").show();
                 
                 $j.each( errorMapKeys, function(i, value) {
                        $j("#inLineEditErrorsContainer").append("<ul>");
                        $j("#inLineEditErrorsContainer").append("<div class=\"progress-bar-warning\"><p><b>" + value +"</b>: " + errorMap[value] + " </p></div>");
                        $j("#inLineEditErrorsContainer").append("</ul>");
                    });

            }else{
                reloadPage();
            }
        }
         
    }
    
}

/**
 * Reload the current page and add update message on the url
 * */
function reloadPage(){
	
	if(!isHttpTest && !isSessionActive()) {
          showSessionTimeoutDiv('reloadPage');
          return;
	 }
	
	var currentHref = window.location.href;
	if (contains(currentHref, "#")) {
		currentHref = currentHref.replace("#", "");
        }
	
	if (updateMessage != undefined && updateMessage.length > 0) {
		
		
		var paramSeparator = "?"
		
		if (contains(currentHref, MESSAGE_URL_PARAMETER)) {
			currentHref = currentHref.substring(0, currentHref.indexOf(MESSAGE_URL_PARAMETER));
			
			//handle if only param of there is already another param
			paramSeparator  = "";
		} else if (contains(currentHref, "?")) {
			paramSeparator  = "&";
		}
		
		currentHref = currentHref + paramSeparator + MESSAGE_URL_PARAMETER + updateMessage;
		window.location = currentHref;
	} else {
		window.location = currentHref;
	}
}

/**
 * Initialize the progress bar and bind the click for each td.
 * Based on the column name it will know how to handle the click in order to know
 * which type of fields data needs to be retrieved from server.
 * This is the main place where Harry Js Potter start with the magic.
 * */
function setInLineEditor(rowTdCollection){
    setProgressBar();
    continueAsking = true;
    var tdToSet = rowTdCollection != null ? rowTdCollection : $j('td.edit');
    tdToSet.click(function(){
    	if(editMode && (!contains($j(this).attr("class"),"ajax") || contains($j(this).attr("class"),"popup"))){
    		// edit mode and the field has been populated
            
            var column = $j(this).parent().children().index(this);

            
            // adding the number so it will be the right tr position over the dom table
            var row = $j(this).parent().parent().children().index($j(this).parent()) + rowTableConstant;
            
            var HEADER_OF_TD = $j(this).attr("headers");
            
            //grab the id of the artifact which is on each checkbox
            var idOfTheCheckBox = $j('#ArtifactListTable tr:eq('+ row +') td:eq(0)').children().children().children(".primary-checkbox").val();

            //if the clicked column its not mean to be editable don't do anything
            if(!allowedToEditColumnFields(HEADER_OF_TD, idOfTheCheckBox)){
            	$j(this).addClass("inline-edit-disabled");
                return;
            }
            
            if((contains(HEADER_OF_TD,"artf_head") && itsTracker) || contains(HEADER_OF_TD,"title_head")){
                $j(this).addClass('ajax');
                var title ="";
                if (itsTracker) {
                	title = encodeHtml($j(this).children().next().first().text());
                	$j(this).children().next().remove();
                	$j(this).on("input", null, null, function() {
                    	if ($j(this).children().last().val().length >= 255) {
                    		$j(this).children().last().addClass("inlineeditInputError");
                    	} else {
                    		$j(this).children().last().removeClass("inlineeditInputError");
                    	}
                    });
                } else {
                	title = encodeHtml($j(this).children().first().text());
                	$j(this).children().first().remove();
                	$j(this).on("input", null, null, function() {
                    	if ($j(this).children().first().val().length >= 255) {
                    		$j(this).children().first().addClass("inlineeditInputError");
                    	} else {
                    		$j(this).children().first().removeClass("inlineeditInputError");
                    	}
                    });
                } 
                $j(this).append('<input class="inputfield" id="editbox_'+ idOfTheCheckBox + '" maxlength="255" style="width:260px" type="text" value="' + title + '">');
                updateOnResize(!itsTracker);
                $j("#editbox_"+ idOfTheCheckBox).focus();
            } else if (isRegularTextOrNumberField(HEADER_OF_TD)) {
                //if it is a regular text fields goes this way
                

            	//if its effort field and autosumming is set to on, we don't want to enable this fields
            	 if(isEffortField(HEADER_OF_TD)){
                 	
                 	//if effort field and autosumming its disabled, nothing to do here
                     if ($j(this).children("[type=hidden]").attr("name") != null) {
                         
                     	if (contains($j(this).children("[type=hidden]").attr("name"), "autosumming_value")) {

                     		autosummingValue = "true" === ($j(this).children("[type=hidden]").val());
                     		
                     		if (autosummingValue) {
                     			return;
                     		} else {
                     			$j(this).children("[name='autosumming_value']").remove();
                     		}
                     		
                     	} 
                     }
            	 }
            	 
            	//if its point field and autoSummingPoints is set to on, we don't want to enable this fields
            	 if (isPointField(HEADER_OF_TD)) {
                 	
                     //if point field and autoSummingPoint is disabled, nothing to do here
                     if ($j(this).children("[type=hidden]").attr("name") != null) {

                        if (contains($j(this).children("[type=hidden]").attr("name"), "autoSummingPoints_value")) {

                            autoSummingPointValue = "true" === ($j(this).children("[type=hidden]").val());

                            if (autoSummingPointValue) {
                               return;
                            } else {
                               $j(this).children("[name='autoSummingPoints_value']").remove();
                            }
                         } 
                     }
                  }
            	
                $j(this).addClass('ajax');
                $j(this).addClass('editing');
                
                
                // default width text
                var styleContent = "width:99%";
                if ((HEADER_OF_TD == 'estimatedEffort_head') || (HEADER_OF_TD == 'remainingEffort_head') || (HEADER_OF_TD == 'actualEffort_head') || (HEADER_OF_TD == 'points_head')) {
                	// appropriate width for 8 characters
                	styleContent = "width: 43px; padding: 2px";
                }
                
                if (HEADER_OF_TD == 'description_head') {
                	$j(this).html('<textarea class="inputfield" id="editbox_' + idOfTheCheckBox + "_" + HEADER_OF_TD + '" rows = "10" cols = "60"  >' + $j(this).text() + ' </textarea>');
                } else {
	                if ($j(this).text().length > 100){
	                    $j(this).html('<textarea class="inputfield" id="editbox_' + idOfTheCheckBox + "_" + HEADER_OF_TD + '" rows = "10" cols = "60"  >' + $j(this).text() + ' </textarea>');
	                }else {
	                    $j(this).html('<input  class="inputfield" id="editbox_' + idOfTheCheckBox + "_" + HEADER_OF_TD + '" style="' + styleContent + '" type="text" value="' + $j(this).text() + '"/>');
	                }
                }
                
                //if it is any of the efforts fields we also need to add the tracker unit combo
                if(isEffortField(HEADER_OF_TD)){
                	
                    //bind the input
                    $j("#"+ "editbox_"+ idOfTheCheckBox+ "_" +HEADER_OF_TD).bind('keyup change', effortInputChange);
                    $j("#"+ "editbox_"+ idOfTheCheckBox+ "_" +HEADER_OF_TD).attr("maxlength" , "6");

                    //add a hidden input to save default value
                    $j(this).append(('<input id="original_value_'+ idOfTheCheckBox + "_" +HEADER_OF_TD+ '" type="hidden" value="' +getEffordFieldValue(HEADER_OF_TD, idOfTheCheckBox) + '"/>'));
                    
                    retrieveFieldData("trackerUnit_", $j(this), idOfTheCheckBox);
                    
                    var helpText = getHelpText(getFormatedCellName(HEADER_OF_TD));
                    if (helpText != null) {
                            helpText.appendTo($j(this));
                    }
                    
                }
                
                if (HEADER_OF_TD == 'points_head') {
                	$j("#"+ "editbox_"+ idOfTheCheckBox+ "_" +HEADER_OF_TD).attr("maxlength" , "4");
                }
                
                updateOnResize(!itsTracker);
                $j('.editing').children().focus();
                $j(this).removeClass('editing');
                
            } else if (contains(HEADER_OF_TD,"monitoringUserId_head") ||
                    contains(HEADER_OF_TD,"autosumming_head") ||
                    contains(HEADER_OF_TD, "autoSummingPoints_head")) {
                //monitoring or autosumming or autoSummingPoints
                
                if ($j(this).children("[type=hidden]").attr("id") != null){
                    return;
                }
                var idImgRef;
                var imgSrcPath;
                var imgOffSrcPath;
                var offImgParameter = "";
                if (contains(HEADER_OF_TD,"monitoringUserId_head")) {
                    idImgRef = "bell_";
                    imgSrcPath = BELL_ON;
                    imgOffSrcPath = BELL_OFF;
                    offImgParameter = "monitor_off";
                } else if (contains(HEADER_OF_TD,"autosumming_head")) {
                    idImgRef = "sum_";
                    imgSrcPath = CALCULATOR_ON;
                    imgOffSrcPath = CALCULATOR_OFF;
                    offImgParameter = "autosumming_off";
                } else {
                    idImgRef = "sumPoints_";
                    imgSrcPath = CALCULATOR_ON;
                    imgOffSrcPath = CALCULATOR_OFF;
                    offImgParameter = "autosumming_off";
                }
                
                $j(this).addClass('ajax');
                
                var hiddenInput = $j('<input type="hidden"></input>');
                
                //if we currently have the shadow image remove it, the new image will contain the hidden field. 
                if (startsWith($j(this).children().attr("id"), offImgParameter)) {
                    $j(this).children().remove();
                }
                
                var imagePathToUse;
                var inputValueToUse;
                
                if ($j(this).children().val() != null){
                    imagePathToUse = imgOffSrcPath;
                    inputValueToUse = "false";
                    //if by default we have this selected, remove the image and add the one with logic
                    $j(this).children().remove();
                }else{
                    imagePathToUse = imgSrcPath;
                    inputValueToUse = "true";
                }

                var img = $j('<img border="0" alt="" id="' + idImgRef + idOfTheCheckBox + '" src="' + imagePathToUse + '">');
                $j(this).attr("onclick","changeStatus('" + img.attr("id") + "')");
                img.attr("style","float:left");
                $j(this).append(img);
                hiddenInput.attr("value",inputValueToUse);
                
                hiddenInput.attr("id",$j(this).children().attr("id") + "_val");
                $j(this).append(hiddenInput);
                
                if (contains(HEADER_OF_TD,"autosumming_head")) {
	                var helpText = getHelpText(getFormatedCellName(HEADER_OF_TD));
	                if (helpText != null) {
	                        helpText.appendTo($j(this));
	                }
                }
                if (contains(HEADER_OF_TD,"autoSummingPoints_head")) {
                    var helpText = getHelpText(getFormatedCellName(HEADER_OF_TD));
                    if (helpText != null) {
                       helpText.appendTo($j(this));
                    }
                }
            } else if(startsWith(HEADER_OF_TD,"user-")
                    || (startsWith(HEADER_OF_TD,"d") && !contains(HEADER_OF_TD,"description")) 
                    || startsWith(HEADER_OF_TD,"text")){
                //flex fields of type user, text and date are handled here
                
                $j(this).addClass('ajax');
                 $j(this).addClass('onEditNow');
                 retrieveFieldData(HEADER_OF_TD, $j(this), idOfTheCheckBox);
                 $j(this).removeClass("onEditNow");
                 updateOnResize(!itsTracker);
                 if (startsWith(HEADER_OF_TD,"user-")) {
                	 $j(this).attr("nowrap", "true");
                 }
            } else if (contains(HEADER_OF_TD,"planningFolderTitle_head")){
                if ((!itsTracker && !isPlanningFolderFrozen) || itsTracker) {
                var assignedToPlanningFolderKey = $j(this).children("input").val();
                var isFrozen = false;
                if (frozenPlanningFolders && frozenPlanningFolders.length > 0 &&
                    planningFolderPathMap && planningFolderPathMap[assignedToPlanningFolderKey]) {
                    for( i = 0; i < frozenPlanningFolders.length; i++) {
                        if (planningFolderPathMap[assignedToPlanningFolderKey] === frozenPlanningFolders[i] ||
                            startsWith(planningFolderPathMap[assignedToPlanningFolderKey], frozenPlanningFolders[i] + ".")) {
                            isFrozen = true;
                        }
                    }
                }
                if (!isFrozen) {
                //planning folder
                $j(this).addClass('ajax');
                if (!contains($j(this).attr('class'),'popup')) {
                	$j(this).addClass('popup');
                } else {
                	// lauching on click execution
                	launchPlanningFolderPopup(row);
                	return;
                }
                var assignedPlanningFolderPathName = "assignedPlanningFolderPath_" + row;
                var assignedPlanningFolderName = "assignedPlanningFolder_" + row;
                var assignedPlanningFolderDisplayName = "assignedPlanningFolderDisplay_" + row;
                var currentFolderPath = encodeHtml($j(this).children("input").attr("name"));
                if(currentFolderPath.length == 0){
                    currentFolderPath = $j("[name=noneValue]").val();
                }



                $j(this).html("");
                $j(this).html('<input type=\"hidden\" name=\"' + assignedPlanningFolderPathName + '\" id=\"' + assignedPlanningFolderPathName + '\"></input><input type=\"hidden\" name=\"' + assignedPlanningFolderName + '\" id=\"' + assignedPlanningFolderName + '\" value= \"' + assignedToPlanningFolderKey + '\"></input><a class="planningFolderPopup\" href=\"#\" onclick=\"launchPlanningFolderPopup(' + '\'' + row +'\')\"><span id=\"' + assignedPlanningFolderDisplayName + '\">' + currentFolderPath + '</span></a>');

                // lauching on click execution
                launchPlanningFolderPopup(row);
                }
                }
            } else if (contains(HEADER_OF_TD,"teamTitle_head")){
                //team popup
                $j(this).addClass('ajax');
                if (!contains($j(this).attr('class'),'popup')) {
                	$j(this).addClass('popup');
                } else {
                	// lauching on click execution
                	launchTeamPopup(row);
                	return;
                }
                var assignedTeam = "assignedTeam_" + row;
                var assignedTeamTitle = "assignedTeamTitle_" + row;
                var assignedTeamDisplayName = "assignedTeamDisplay_" + row;
                var assignedTeamKey = $j(this).children("input").val();
                var selectedTeamUrl = "selectedTeamUrl_" + row;
                var currentTeamTitle = encodeHtml($j(this).children("input").attr("name"));
                if(currentTeamTitle.length == 0){
                	currentTeamTitle = $j("[name=noneValue]").val();
                }
                
                $j(this).html("");
                $j(this).html('<input type=\"hidden\" name=\"' + assignedTeam + '\" id=\"' + assignedTeam + '\" value= \"' + assignedTeamKey + '\"><input type=\"hidden\" name=\"' + selectedTeamUrl + '\" id=\"' + selectedTeamUrl + '\" value= \"' + getFolderPath() + '?teamId=' + assignedTeamKey + '&teamTitle=' + currentTeamTitle + '\"><a class="planningFolderPopup\" href=\"#\" onclick=\"launchTeamPopup(' + '\'' + row +'\')\"><span id=\"' + assignedTeamDisplayName + '\">' + currentTeamTitle + '</span></a>');
                // lauching on click execution
                launchTeamPopup(row);
            } else {
                //any field that is a drop down that might have or not id, but the data needs to be seeked
                //on the server or cache, is handled here
            	if (contains(HEADER_OF_TD,"assignedToFullname_head")) {
                	$j(this).attr("nowrap", "true");
            	}
            	
                 $j(this).addClass('ajax');
                 $j(this).addClass('onEditNow');
                 retrieveFieldData(HEADER_OF_TD, $j(this), idOfTheCheckBox);
                 $j(this).removeClass("onEditNow");
            }
            
            updateOnResize(!itsTracker);
            
            //if not in the map, we add it
            if($j.inArray(idOfTheCheckBox, artifactsModified) < 0) {
                artifactsModified.push(idOfTheCheckBox);
            }
            
            if ($j(this).parent().attr("id") != null) {
            	addArtifactToWarnUserIfCollapse($j(this).parent().attr("id"));
            }
            
        }
    });
    
    
}

/**
 *For monitoring or autosumming show selected or unselected icon and value 
 */
function changeStatus(imgId){
    var itsBell = startsWith(imgId, "bell_");
    var itsSelected = $j("#"+imgId+"_val").val();
    var imgToUpdate;
    
    if (itsBell) {
        if (itsSelected == "true") {
            imgToUpdate = BELL_OFF;
        } else {
            imgToUpdate = BELL_ON;
        }
    } else {
        if (itsSelected == "true") {
            imgToUpdate = CALCULATOR_OFF;
        } else {
            imgToUpdate = CALCULATOR_ON;
        }
    }
    
    if (itsSelected == "true") {
        itsSelected = "false";
    } else {
        itsSelected = "true";
    }
    

    $j("#"+imgId).attr("src" , imgToUpdate);
    $j("#"+imgId+"_val").val(itsSelected);
    updateOnResize(!itsTracker);
    
}


/**
 * Prepare a string containing the field columns names that are present, it will be used
 * to bring from the servers the ids of those field who have id on the db example : status have id, description has no id.
 * */
function collectColumnsNamesToInitFieldIds() {
    var colCount = $j("#ArtifactListTable").find('tr')[trIndex].cells.length;
    
    var tempString;
    //skipping 0 which is filter td and we dont need that one
    var k = 1;
    
    while( k < colCount){
        
    	
    	if ($j('.ItemListHeader').first().children().get(k).id != null){
            var firstIndex = $j('.ItemListHeader').first().children().get(k).id.lastIndexOf("_");
            tempString = $j('.ItemListHeader').first().children().get(k).id.substring(0, firstIndex);
        }

        if (tempString) {
        	tempString = contains(tempString,"artifactGroup") ? "group" : tempString;
        	tempString = contains(tempString,"resolvedInReleaseTitle") ? "resolvedInRelease" : tempString;
        	tempString = contains(tempString,"reportedInReleaseTitle") ? "reportedInRelease" : tempString;
        	tempString = contains(tempString,"user-") ? tempString.substring("user-".length, tempString.length) : tempString;
        	tempString = contains(tempString,"multiselect-") ? tempString.substring("multiselect-".length, tempString.length) : tempString;
        	
        	
        	if(visibleColumns == ""){
                visibleColumns = tempString; 
            }
            else{
                visibleColumns = visibleColumns+ ":" + tempString;
            }
        }
        k++;
    }

}

/**
 * Check that all the artifact that are marked as modified are
 * still present on the page. Which can be the case of collapsed
 * childrens
 * */
function verifyAllArtifactsExistOnPage() {
	var newFilteredArray = [];
	
	$j.each(artifactsModified, function(i, value){
		//filter out any artifact that is not present on the page
		if ($j("tr[id*=" + value + "]").length > 0) {
			newFilteredArray.push(value);
		}
	});
	
	artifactsModified = newFilteredArray;
}

/**
 * Before saving we need to pick up the changes and create the json objet that will go to the server
 * For each modified artifact we grab the value of those fields which are located on a TD which 
 * contains the ajax class, which means it was clicked.
 */
function buildArtifactFieldChangesToJSON(errors, errorsIndex){
    
    var colCount = $j("#ArtifactListTable").find('tr')[trIndex].cells.length;
    var iterate = true;
    var i = 0;
    var artifactFieldMap = new Object();
    var artifactsChanges = new Object();
    
    if (!itsTracker) {
    	verifyAllArtifactsExistOnPage();
    }
    
    $j.each( artifactsModified, function(i, value) {
        var artElement = $j('input[value="'+ value +'"][name=_listItem]');
        var row = artElement.parent().parent().parent().parent().parent().children().index(artElement.parent().parent().parent().parent()) + rowTableConstant;

        var iterate = true;
        var i = 0;
        var artifactRowPositionMap = new Object();
        var artifactFieldChangesArray = [];
        while (iterate && colCount > 0){
            var $currentDataTd;
            var fieldValueMap = new Object();
                
        
            $currentDataTd = $j("#ArtifactListTable" + ' tr:eq('+ row +') td:eq('+ i +')');
            
            if($currentDataTd.attr("class") != null && contains($currentDataTd.attr("class"),'ajax')){

                var valueOfTheField = $currentDataTd.children().is("select") ? $currentDataTd.children().children("option:selected").val() : $currentDataTd.children().val();

                //this is the none value for frs
                if ((contains($currentDataTd.attr("headers"),"resolvedInReleaseTitle_head") || 
                        contains($currentDataTd.attr("headers"), "reportedInReleaseTitle_head")) &&
                        valueOfTheField != undefined &&
                        contains(valueOfTheField, "none")) {
                    
                    valueOfTheField = "";
                }
                
                if (contains($currentDataTd.attr("headers"),"priority_head") || 
                    contains($currentDataTd.attr("headers"), "assignedToFullname_head")) {
                    valueOfTheField = $currentDataTd.children().children("option:selected").val();
                } else if (contains($currentDataTd.attr("headers"), "multiselect-")) {
                    var tempParamMap = new Object();
                    if (contains($currentDataTd.children().attr("id"), "_")) {
                        var fieldName = $currentDataTd.attr("headers").substring("multiselect-".length , $currentDataTd.attr("headers").lastIndexOf("_"));
                        $currentDataTd.children().attr("id", getFieldId(fieldName, value));
                    }
                    tempParamMap[$currentDataTd.children().attr("id")] = $currentDataTd.children().val();
                    
                    checkRequiredFieldContentBeforeSending(
                            $currentDataTd.children().attr("id"), artifactFieldMap, $currentDataTd.children().val(), value, errors, errorsIndex);
                    
                    valueOfTheField = tempParamMap; 
                } else if (contains($currentDataTd.attr("headers") ,"artf_head") ||
                		contains($currentDataTd.attr("headers") ,"title_head")){
                    
                	valueOfTheField = itsTracker ? $currentDataTd.children().next().val() : $currentDataTd.children().val() ;
                    if (stringIsEmptyOrIsWhiteSpaces(valueOfTheField)) {
                        errors[value + "_" + $currentDataTd.attr("headers")] = value + " : " + getDescriptionOrTitleFieldCannotBeEmptyMessage($currentDataTd.attr("headers"));
                        errorsIndex.push(value + "_" + $currentDataTd.attr("headers"));
                    } else if (valueOfTheField.length > 255) {
                    	errors[value + "_" + $currentDataTd.attr("headers")] = value + " : " + " " + TITLE_LENGTH_ERRORS_VALIDATION;
                        errorsIndex.push(value + "_" + $currentDataTd.attr("headers"));
                    }  
                } else if(contains($currentDataTd.attr("headers"),"monitoringUserId_head")  ||
                        contains($currentDataTd.attr("headers") , "autosumming_head") ||
                        contains($currentDataTd.attr("headers") , "autoSummingPoints_head")) {
                    valueOfTheField = $currentDataTd.children().next().val(); 
                } else if (contains($currentDataTd.attr("headers") ,"planningFolderTitle_head")) {
                    fieldValueMap["planningFolder_id"] = $currentDataTd.children().next().val(); 
                } else if (contains($currentDataTd.attr("headers") ,"status_head")
                        || contains($currentDataTd.attr("headers") ,"category_head") 
                        || contains($currentDataTd.attr("headers"), "artifactGroup_head")
                        || contains($currentDataTd.attr("headers"), "customer_head")) {
                    valueOfTheField = $currentDataTd.children().children("option:selected").text();
                    var fieldValue = $currentDataTd.children().children("option:selected").val(); 
                    if ((contains($currentDataTd.attr("headers"), "artifactGroup_head") || 
                            contains($currentDataTd.attr("headers") ,"category_head") ||
                            contains($currentDataTd.attr("headers"), "customer_head")) && 
                            contains(valueOfTheField, $j('input[name=noneValue]').val()) &&
                            contains(fieldValue, $j('input[name=noneId]').val())){
                        valueOfTheField = "";
                    }
                                        
                } else if (contains($currentDataTd.attr("headers") ,"fv")) {
                    var tempParamMap = new Object();
                    
                    if (contains($currentDataTd.children().attr("id"), "_")) {
                        var fieldName = $currentDataTd.attr("headers").substring(0 , $currentDataTd.attr("headers").indexOf("_"));
                        $currentDataTd.children().attr("id", getFieldId(fieldName, value));
                    }
                    
                    tempParamMap[$currentDataTd.children().attr("id")] = $currentDataTd.children().children("option:selected").text();
                    var fieldValue = $currentDataTd.children().children("option:selected").val();   
                    //case of single select which are not required and have none value selected,
                      //it should be sent as ""
                      if (contains($currentDataTd.children().children("option:selected").text(),
                          $j('input[name=noneValue]').val()) &&
                          contains(fieldValue, $j('input[name=noneId]').val())) {
                          tempParamMap[$currentDataTd.children().attr("id")] = "";
                      }
                    valueOfTheField = tempParamMap; 
                } else if (isEffortField($currentDataTd.attr("headers"))) {
                    valueOfTheField = $currentDataTd.children("[type=hidden]").val();
                    var result = validatePositiveInt(valueOfTheField);
                    if (result.length == 0) {
                        result = validateDecimalNo(valueOfTheField);
                    }
                    if (result.length > 0) {
                        errors[value + "_" + $currentDataTd.attr("headers")] = value +" : "+ whichEffortField($currentDataTd.attr("headers")) +" "+ result;
                        errorsIndex.push(value + "_" + $currentDataTd.attr("headers"));
                    }
                    
                } else if (isRegularTextOrNumberField($currentDataTd.attr("headers"))) {
                    valueOfTheField = $currentDataTd.children().val();
                    if (valueOfTheField == null) {
                        valueOfTheField = $currentDataTd.text();
                    }

                    if (contains($currentDataTd.attr("headers") ,"description_head") &&
                            stringIsEmptyOrIsWhiteSpaces(valueOfTheField)){
                            errors[value + "_" + $currentDataTd.attr("headers")] = value + " : " + getDescriptionOrTitleFieldCannotBeEmptyMessage($currentDataTd.attr("headers"));
                            errorsIndex.push(value + "_" + $currentDataTd.attr("headers"));
                    } else if (contains($currentDataTd.attr("headers"),"points_head")) {
                    var result = validatePositiveInt(valueOfTheField);
                        if (result.length > 0) {
                            errors[value + "_" + $currentDataTd.attr("headers")] = value +" : "+ STORY_POINTS_FIELD_MESSAGE +" "+ result;
                            errorsIndex.push(value + "_" + $currentDataTd.attr("headers"));
                        }
                    }
                } else if ((startsWith($currentDataTd.attr("headers") ,"d") && !contains($currentDataTd.attr("headers"), "description")) 
                        || contains($currentDataTd.attr("headers"), "text")) {
                    var fieldName = $currentDataTd.attr("headers").substring(0 , $currentDataTd.attr("headers").indexOf("_"));
                    var tempParamMap = new Object();
                    tempParamMap[getFieldId(fieldName, value)] = $currentDataTd.children().first().val();
                    
                    checkRequiredFieldContentBeforeSending(
                            getFieldId(fieldName, value), artifactFieldMap, 
                            $currentDataTd.children().first().val(), value, errors, errorsIndex);
                    
                    valueOfTheField = tempParamMap; 
                } else if (startsWith($currentDataTd.attr("headers"), "user-")) {
                    var tempParamMap = new Object();
                    tempParamMap[$currentDataTd.find("[type=hidden]").attr("id")] = $currentDataTd.find("[type=hidden]").val();
                    
                    checkRequiredFieldContentBeforeSending(
                            $currentDataTd.find("[type=hidden]").attr("id"), artifactFieldMap, 
                            $currentDataTd.find("[type=hidden]").val(), value, errors, errorsIndex);
                    
                    valueOfTheField = tempParamMap;
                } else if (contains($currentDataTd.attr("headers") ,"teamTitle_head")){
                    fieldValueMap["team_id"] = $currentDataTd.children().val(); 
                }
                
                fieldValueMap[$currentDataTd.attr('headers')] = valueOfTheField;
                artifactFieldChangesArray.push(fieldValueMap);
            }
            
            if (i < colCount){
                i++
            }else {
                iterate = false;
            }
            
        }
        if(artifactFieldChangesArray.length > 0){
            artifactFieldMap[value] = artifactFieldChangesArray;
        }
        
        
    });
    return artifactFieldMap;
}

/**
 * Validate if the field is required and its empty in that case the user must be informed
 * and the update process must be stopped
 * */
function checkRequiredFieldContentBeforeSending(fieldId, artifactFieldMap, fieldValueContent, artfId, errors, errorsIndex) {
    
      if ((fieldValueContent == null || fieldValueContent.length === 0) && getIsRequiredField(fieldId)){
          errors[artfId + "_" + fieldId] = artfId + " " + getRequiredFieldName(fieldId) + REQUIRED_MESSAGE;
          errorsIndex.push(artfId + "_" + fieldId);
    }
}

/**
 * Get data for a given field there could be 3 cases.
 * 1) we have the id, then go to the api that handles artifacts fields by field id
 * 2) we don't have the id or the values are not saved on the field it self, the go to another api that handles those artifacts.
 * 3) we already have the field, we have it on cache, avoid going to the server when possible.
 * */
function retrieveFieldData(name, parentElement, artfId){

    //for the multiselect fields
    var isMultiple = startsWith(name,"multiselect");
    
    //parse the name from the column name
    var fieldName = getFormatedCellName(name);

    //first try cache Case 3)
    if (fieldExistOnCacheAndItsCloneable(fieldName, artfId)){
        if (itsTracker || !startsWith(fieldName,"assignedToFullname")) {
            cloneAndRender(fieldsCache[fieldName], fieldName, parentElement,artfId);
        } else {
            var trackerId = fieldNameIds["artifactTrackerMap"][artfId];
            cloneAndRender(fieldsCache[fieldName + "_" + trackerId], fieldName, parentElement,artfId);
        }
        if (startsWith(fieldName,"assignedToFullname")) {
          retrieveFieldData("userPicker_", parentElement, artfId)
          }
        
        return;
    }else if (fieldExistOnCacheAndItsCloneable(getFieldId(fieldName, artfId), artfId)){
        cloneAndRender(fieldsCache[getFieldId(fieldName, artfId)], fieldName, parentElement, artfId);
            return;
    }
    
    /**
     * handle flex datefield, no need to go to the server.
     * */
    if (startsWith(fieldName,"d") && !contains(fieldName,"description")){
        var input = $j('<input id="'+ artfId + "_" + fieldName + "_id" +'"></input>');
        input.attr("class","inputfield cal-icon");
        input.val(parentElement.html());
        parentElement.html("");
        var img = $j('<img class="calendar" align="absmiddle" width="16" height="16" onclick="return calShow(' + "'" + input.attr("id") + "'" +');" alt="Select Date" src="/sf-images/icons/date_popup.png">');
        var message = "(" + userDatePattern + ")";
        input.appendTo(parentElement);
        input.css("width", "50px");
        img.appendTo(parentElement);
        parentElement.append(message);
        
        //some flex fields may have help text
        if (itsTracker ){
            var helpText = getHelpText(getFieldId(fieldName, artfId));
            if (helpText != null) {
                    helpText.appendTo(parentElement);
            }
        }
         
        updateOnResize(!itsTracker);
        return;
    }
    
    /**
     * handle flex user field, no need to go to the server.
     * */
    if (startsWith(fieldName,"user-")){
        //create the field that shows the full names and also the field that olds the hidden values
        var input = $j('<input id="'+artfId + "_" + fieldName + "_id" +'"></input>');
            input.attr("name","_FullName_" + artfId + "_" + fieldName);
            input.attr("class","UserPickerInput");
            input.attr("readonly","readonly");
            input.css("width", 110);

            input.val(parentElement.html().substring(0,parentElement.html().indexOf("<")));
            var hiddenInput = $j('<input type="hidden"></input>');
            hiddenInput.attr("name",artfId + "_" + fieldName);
            var fieldKey = fieldName.substring(fieldName.indexOf("user-") +  "user-".length , fieldName.length);
            hiddenInput.attr("id",getFieldId(fieldKey, artfId));
            hiddenInput.val(parentElement.children().val());
            parentElement.html("");
            input.appendTo(parentElement);
            hiddenInput.appendTo(parentElement);

            var userFilterType = getFlexFieldUserFilter(getFieldId(fieldKey, artfId), artfId);
            
            var editedArtfId = artfId;
            
            if (userFilterType != null) {
            	editedArtfId = editedArtfId + "_" + userFilterType; 
            }
            
            //create the user picker link for the field
            retrieveFieldData("userPicker-"+fieldName+"_", parentElement, editedArtfId);
            
            //some flex fields may have help text
          if (itsTracker ){

                  var helpText = getHelpText(getFieldId(fieldKey, artfId));
                  
                  if (helpText != null) {
                      helpText.appendTo(parentElement);
                  }
          }
          
        return;
    }
    
    if (startsWith(fieldName,"fv") && isPartOfHierarchyFields(getFieldId(fieldName, artfId))) {
        if (!isFullFamilyViewActive(getFieldId(fieldName, artfId), getFlexFields(artfId))) {
            parentElement.removeClass('ajax');
            parentElement.removeClass('edit');
            alert(HIERARCHY_FIELD_FAMILY_NOT_COMPLETE_ERROR);
            return;
        } else {
                //if not in the map, we add it
                var row = parentElement.parent().index();
                var hierarchy = new HierarchyReader(fieldName, artfId, row, null, null);
                hierarchy.init();
                hierarchy.processHierarchy();
                $j(window).trigger("resize");
                removeFromCache = true;
                if ($j.inArray(artfId, artifactsModified) < 0) {
                    artifactsModified.push(artfId);
                }
        }
        return;
    }
    
    //if not in the cache and has id go to the server for the api that handles fields by id
    if (getFieldId(fieldName, artfId) != null){
        if (!contains(fieldName, "reportedInRelease") 
                && !contains(fieldName,"resolvedInRelease") 
                && !contains(fieldName,"text")
                && !contains(fieldName,"priority")){

            retrieveFieldDataFromId(getFieldId(fieldName, artfId), parentElement, isMultiple, artfId);
            
          return;
        } 
    }
    
    
    if (startsWith(fieldName,"text")){

         var input = $j('<input id="'+artfId + "_fv_id_" + '" type="text" size ="20" ></input>');
         input.attr("name",artfId+"_flexFieldValue(" + getFieldId(fieldName, artfId) + ")");
         input.addClass("inputfield");
         
         var span = $j('<span></span>');
         span.attr("class", "fv_result");
         span.attr("id", input.attr("id")+ textFlexFieldResultSpanPattern + getFieldId(fieldName, artfId));
         
         input.val(parentElement.html());
         parentElement.html("");
         
         input.bind('change keyup', j.debounce(500, function() {
              validateText(this,textFlexFieldResultSpanPattern);
            }));
         
         
         input.appendTo(parentElement);
         span.appendTo(parentElement);
         updateOnResize(!itsTracker);
         
         //some flex fields may have help text
          if (itsTracker ){

                  var helpText = getHelpText(getFieldId(fieldName, artfId));
                  
                  if (helpText != null) {
                      helpText.appendTo(parentElement);
                  }
          }
         return;
    }
    
    
    //after all if we get to here then we go to server to bring the values data Case 2)
    var fieldDataUrl = "/sf/tracker/do/massUpdateArtifactsInLineEditFieldDataHandler/" + getUrlExtraParams()  + "?fieldName=" + fieldName + "&artfId=" + artfId;
    
    if (contains(window.location.href,'/go/')) {
    fieldDataUrl = "/sf/tracker/do/massUpdateArtifactsInLineEditFieldDataHandler" + getProject()  + "?fieldName=" + fieldName + "&artfId=" + artfId;
    }

    //if the field has no id means its a case to handle using the name
    $j.getJSON(fieldDataUrl, function(data) {
        if (data === undefined) {
            // We had an issue.
            alert(SERVER_ERROR_MESSAGE);
          } else{

              if (startsWith(fieldName,"userPicker")){
                  var dataElem = $j(data["userPickerLink"])
                  var directiveAttr = dataElem.attr('class');
                  parentElement.append(data["userPickerLink"]);
                  if (directiveAttr === 'core-user-picker' && typeof angular !== undefined) {
                    var $element = angular.element(parentElement);
                    var fieldId, val, inputHidden = angular.element($element[0].querySelector('[type="hidden"]'));
                    if (inputHidden) {
                      fieldId = inputHidden.attr('id');
                      val = inputHidden.val();
                    }
                    var $injector = $element.injector(),
                    $compile = $injector.get('$compile'),
                    userPickerDirective = angular.element(data["userPickerLink"]);
                    if (userPickerDirective) {
                      // Get the field id from inputHidden and set it to user picker
                      // input hidden field
                      userPickerDirective.attr('data-field-id', fieldId);
                      userPickerDirective.attr('data-user-keys', val);
                    }
                    var newContent = $compile(userPickerDirective);                   
                    $element.html(newContent($element.scope()));                  
                  }                
              }else {
                  
                  var select = $j('<select id="'+artfId + "_" + fieldName+'"></select>');
                  if (contains(fieldName,"trackerUnit")) {
                	  // adjust width in unit for efforts
                	  select.attr("style","width: 74px;");
                  }
                  select.attr("class","FilterInput");
                  select.attr("name",artfId + "_" + fieldName);
                  
                  var parentText = parentElement.children().text().length == 0 ? parentElement.text() : parentElement.children().text();
                  
                  var currentHtmlOnTheTD = parentElement.html();
                  if(!isEffortField(parentElement.attr("headers"))){
                      parentElement.html("");
                  }
                  
                  //for the priority combo colors
                  var apendStyleClass = contains(fieldName, "priority") ? 'class="priority' : "";
                  
                  var supportMapForFirefoxDropDown = new Object();
                  var supportSelected;
                  
                  var orderArray = data["orderElementsArray"];
                  var abortFieldRendering = false;
                  var setClass = "";
                  
                  $j.each( orderArray, function(i, value) {
                  
                	  
                	  var mapValue = data[value];
                	  var key = value;

               	    //priority combo style its like priority + level
                      
                      if (apendStyleClass.length > 0){
                          setClass = apendStyleClass + key + '"';
                      }
                      
                      if ((startsWith(fieldName, "resolvedInRelease") || startsWith(fieldName, "reportedInRelease")) 
                              && startsWith(mapValue, "noPermission")) {
                          abortFieldRendering = true;
                          
                          //restore the value sice we are not editing this one.
                          parentElement.html(currentHtmlOnTheTD);
                      }
                      
                      //if it is tracker unit with the data also comes the selected value parameter
                      if (startsWith(fieldName, "trackerUnit")) { 
                    	  //save the value for later
                    	  parentText = data["selectedUnit"];
                          
                      }
                      
                      
                      select.append('<option value=\"' + encodeHtmlAttribute(String(key)) + '\" ' + setClass + ' >' + encodeHtml(mapValue) + '</option>');
                          
                      if ($j.browser.mozilla) {
                          supportMapForFirefoxDropDown[key] = mapValue;
                      }
                  
                      
                      //set selected value, different case between any dropdown and the one for tracker units
                      if ((!startsWith(fieldName, "trackerUnit") && startsWith(parentText, mapValue)) 
                    		  || (parentText == key)) {
                          select.val(key);
                          supportSelected = key;
                      }

                  });
                  
                  if (abortFieldRendering) {
                      return;
                  }

                  //if it is firefox element.val() setter wont work, so we need to add the option element
                  //with the selected attribute 
                  if ($j.browser.mozilla) {
                      select.children().remove();
                      
                      var mapKeysSupport = $j.map(supportMapForFirefoxDropDown, function(value, key) {
                          
                    	  setClass  = apendStyleClass + key + '"';
                          var selectedValue = "";
                          if (supportSelected == key) {
                              selectedValue = ' selected="selected" ';
                          }
                          
                          select.append('<option value="' + encodeHtmlAttribute(key) +'" '+ selectedValue + setClass+'>' + encodeHtml(value) + '</option>');
                      });
                  }
                  
                  select.appendTo(parentElement);
                                    
                  if (startsWith(fieldName, "trackerUnit")){
                      select.attr("id", select.attr("id") + "_" + parentElement.attr("headers"));
                      parentElement.children("select").bind('change', effortFieldComboChange);
                  }else{
                      if (startsWith(fieldName,"assignedToFullname")) {
                          if (itsTracker) {
                              fieldsCache[fieldName] = artfId + "_" + fieldName;
                          } else {
                              var trackerId = fieldNameIds["artifactTrackerMap"][artfId];
                              fieldsCache[fieldName + "_" + trackerId] = artfId + "_" + fieldName;
                          }
                      } else {
                          fieldsCache[fieldName] = artfId + "_" + fieldName;
                      }
                  } 
              }

              if (startsWith(fieldName,"assignedToFullname")) {
                  retrieveFieldData("userPicker-"+fieldName+"_", parentElement, artfId);
              }
              
              var helpText = getHelpText(getFieldId(fieldName, artfId));
        	  if (helpText != null) {
        	      helpText.appendTo(parentElement);
        	  }
        	  
              updateOnResize(!itsTracker);
              
          } 
      });
    
}

/**
 * return whether the element exist on cache and
 * also its available on the page to be rendered
 * */
function fieldExistOnCacheAndItsCloneable(fieldName, artfId) {
    if (fieldName && startsWith(fieldName,"assignedToFullname")) {
        if (itsTracker) {
            return fieldsCache[fieldName] && $j("#" + fieldsCache[fieldName]).length > 0;
        } else {
            var trackerId = fieldNameIds["artifactTrackerMap"][artfId];
            return fieldsCache[fieldName + "_" + trackerId] && $j("#" + fieldsCache[fieldName + "_" + trackerId]).length > 0;
        }
    }
	return fieldsCache[fieldName] && $j("#" + fieldsCache[fieldName]).length > 0; 
}

/**
 * Set the onbefore unload with the unsaved changed messages
 * */
function setLeavingPageWithOutSavingAlert() {
    window.onbeforeunload = function(e) { 
          if (artifactsModified.length > 0) {
              e.preventDefault();

              return UNSAVED_CHANGES_MESSAGE;
          }
        }
}

function isPartOfHierarchyFields(fieldId) {
    return fieldNameIds['hierarchyIdentifierMap'][fieldId] != null;
}

/**
* @param fieldName
* @param hierarchyFieldMap map of children pointing to parents.r
* @returns {Boolean} true in case the Full Hierarchy view is complete.
*/
function isFullFamilyViewActive(fieldName, visibleFlexFields) {
    var familyFieldMap = fieldNameIds['familyFieldMap'];
    var relationshipExists = familyFieldMap[fieldName];
    if (relationshipExists != undefined) {
        var i;
        for (i = 0; i < relationshipExists.length; i++) {
            if (!contains(visibleFlexFields, relationshipExists[i])) {
                return false;
            }
        }
    }
    return true;
}
 

 /**
* @param artfId id of the artifact.
* @returns {Array} array of field names of visible flex fields.
*/
function getFlexFields(artfId) {
    var arr = visibleColumns.split(':');
    var flexFields = new Array(); 
    var i;
    for( i = 0; i < arr.length; i++) { 
        if (startsWith(arr[i],'fv')) {
            flexFields.push(getFieldId(arr[i], artfId));
       }
    }
    return flexFields;
}

/**
 * Clone and element that is on the cache, updating its properties and id
 * */
function cloneAndRender(elementId, fieldName, parent, artfId){
    var clonedTemp = $j("#"+elementId).clone();
    var parentText = parent.children().text().length == 0 ? parent.html() : parent.children().text();
    var multipleValues = [];
    if(!isEffortField(parent.attr("headers"))){
        parent.html("");
    }
    clonedTemp.attr("id",artfId + "_" + fieldName);
    clonedTemp.attr("name",artfId + "_" + fieldName);
    
    var hiddenValues = hiddenValuesCache[elementId];
    $j.each( clonedTemp.children(), function(i, value) {
        //set selected value
        if (contains(parentText, $j(this).text())) {
            if ($j.browser.msie && $j(this).is('span')) {
                var children = $j(this).children();
                var value = children.val();
                clonedTemp.val(value);
                multipleValues.push(value);
                children.attr('selected', 'selected').show().unwrap('span');
            } else {
              $j(this).show();
              clonedTemp.val($j(this).val());
              multipleValues.push($j(this).val());
            }
        } else if (hiddenValues != null) {
            $j.each(hiddenValues, function(idx, hiddenValue) {
                if (contains(hiddenValue.val(), $j(value).val())) {
                    if ($j.browser.msie) {
                      $j(value).wrap('<span>').hide();
                    } else {
                      $j(value).hide();
                    }
                }
            });
        }
    });
    
    //set selected value for multiselect field.
    if(startsWith($j(parent).attr("headers"),"multiselect")) {
        clonedTemp.val(multipleValues);
    }
    
    parent.append(clonedTemp);
    
	  var helpText = getHelpText(elementId);
	  
	  if (helpText != null) {
	      helpText.appendTo(parent);
	  }
      updateOnResize(!itsTracker);
}

/**
 * Get the help text for the given field
 * */
function getHelpText(fieldId) {
    if (fieldNameIds["helpTextMap"] != null && fieldNameIds["helpTextMap"][fieldId] != null) {
          return  $j("<script>initTooltip();</script><img height=\"16px\" width=\"16px\" data-toggle=\"tooltip\" title=\"" + fieldNameIds["helpTextMap"][fieldId] + "\" src=\"/sf-images/misc/helpText.png\" alt=\"Help Text\" >");

    }else {
        return null;
    }
}

/**
 * Get the user filter for theflex field 
 * */
function getFlexFieldUserFilter(fieldId) {
	if (fieldNameIds["flexFieldUserFilterMap"] != null) {
		return fieldNameIds["flexFieldUserFilterMap"][fieldId]; 
	}
}


/**
 * Get a field from the server using ID case 1)
 * Mostly used for dropdowns and multiple select elements
 * */
function retrieveFieldDataFromId(fieldID, parentElement, isMultiple, artifactId){

    var appUrlVar = itsTracker ? "tracker" : "planning";
    
    var initFieldDataUrl = "/sf/" + appUrlVar + "/do/getFieldValuesJSON/" + getUrlExtraParams() + "?fieldid=" + fieldID
                             + "&artifactId=" + artifactId;
    
    if (contains(window.location.href,'/go/')) {
        initFieldDataUrl = "/sf/" + appUrlVar + "/do/getFieldValuesJSON" + getProject()  + "?fieldid=" +
                            fieldID + "&artifactId=" + artifactId;
    }

     
    $j.getJSON(initFieldDataUrl, function(data) {
        if (data === undefined) {
            // We had an issue.
            alert(SERVER_ERROR_MESSAGE);
          } else{
              
              var select = $j('<select id="'+fieldID+'"></select>');
              
              if (isMultiple){
                  select.attr("multiple","multiple");
                  select.attr("class","inputfield");
              }else {
                  //add the localizaed none value to the combo
                  if (!startsWith(parentElement.attr("headers"), "status")) {
                          select.append('<option value="' + $j('input[name=noneId]').val() +'">' + $j('input[name=noneValue]').val() + '</option>');
                          
                  }
                  select.attr("class","FilterInput");
              }

              var parentText = parentElement.children().text().length == 0 ? parentElement.html() : parentElement.children().text();
              
              if(!isEffortField(parentElement.attr("headers"))){
                  parentElement.html("");
              }

              var multipleValues = [];
              var hiddenValues = [];
              var mapKeys = $j.map(data.values, function(value, key) {
                  var dataKeyToUse = isMultiple ? "name" : "id";
                  var option = $j('<option value="' + encodeHtmlAttribute(value[dataKeyToUse]) + '">' + encodeHtml(value["name"]) + '</option>');
                  select.append(option);
                  //set selected value
                  if (contains(parentText, value["name"])) {
                      select.val(value[dataKeyToUse]);
                      multipleValues.push(value[dataKeyToUse]);
                      if (value["visible"] === false) {
                          hiddenValues.push(option);
                      }
                  } else if (value["visible"] === false) {
                      if ($j.browser.msie) {
                        option.wrap('<span>').hide();
                      } else {
                        option.hide();
                      }
                      hiddenValues.push(option);
                  }
              });

              if (hiddenValues.length > 0) {
                  hiddenValuesCache[fieldID] = hiddenValues;
              }

              // For multiple select flex fields.
              if(isMultiple) {
                 select.val(multipleValues);
              }
              fieldsCache[fieldID] = fieldID;
              if (data.fieldIsStatus) {
                   delete fieldsCache[fieldID];
              }
              if (removeFromCache) {
                  delete fieldsCache[fieldID];
              }
              //none value so set the none to the select
              if (select.children().length == 1 &&
                      !startsWith(parentElement.attr("headers"), "status") &&
                      !startsWith(parentElement.attr("headers"), "fv")){
                  select.children().val("");
              }

              select.appendTo(parentElement);
                  
              var helpText = getHelpText(fieldID);
              
              if (helpText != null) {
                  helpText.appendTo(parentElement);
              }

              updateOnResize(!itsTracker);

          } 
      });
    
}

/**
 * get the project path used for go url
 * */
function getProject() {
    var pathLength = $j('input[name=projectPath]').val().length;
    return $j('input[name=projectPath]').val().substring(0,pathLength -1);
}

/**
 * Return the ids of the fields which have ids and that are currently present on the page
 * Those id's will be used in order to bring the values and save them once its done.
 * */
function initFieldsIds(){

    var initFieldDataUrl = "/sf/tracker/do/massUpdateArtifactsInLineEditFieldDataHandler/" + getUrlExtraParams() + "?initParameters=" + "true"+
    "&preferredColumns="+ visibleColumns;
    
    if (contains(window.location.href,'/go/')) {
        initFieldDataUrl = "/sf/tracker/do/massUpdateArtifactsInLineEditFieldDataHandler" + getProject()  + "?initParameters=" + "true"+
        "&preferredColumns="+ visibleColumns;
    }

    
    $j.getJSON(initFieldDataUrl, function(data) {
        if (data === undefined) {
            // We had an issue.
            alert(SERVER_ERROR_MESSAGE);
          } else{
              userDatePattern = data.datePattern;
              fieldNameIds = data.fieldNameIds;
              isPlanningFolderFrozen = data.isPlanningFolderFrozen;
              frozenPlanningFolders = data.frozenPlanningFolders;
              planningFolderPathMap = data.planningFolderPathMap;
          }
      }).done(function() {
    	  //only for planning folder
    	  if (!itsTracker) {
            	renderTheRestOfTheTable();
          } 
      });
}

/**
 * Using the current url return the extra parameters of project path and if
 * Used on the ajax calls
 * */
function getUrlExtraParams(){
    
    if (!contains(window.location.pathname,'/go/')){
        
        var offset = "";
        var index;
        if (!itsTracker) {
            offset = window.location.href.indexOf('viewPlanningFolderSort') > 0 ? 'viewPlanningFolderSort'.length : 'viewPlanningFolder'.length;
            index = window.location.href.indexOf('viewPlanningFolder');
        } else {
            index = window.location.href.indexOf('listArtifacts');
            offset = 'listArtifacts'.length;
        }

            //plus 1 because of the /
            offset = offset + 1;
        var urlParameters = window.location.href.substring(index + offset); 
        if (contains(urlParameters,"?")){

            urlParameters = urlParameters.substring(0,urlParameters.indexOf("?"));
        }

        if (contains(urlParameters, "#")) {
            urlParameters = urlParameters.replace("#", "");
        }
        
        return  urlParameters;
    }else {
        
        var index = window.location.href.indexOf('/go/') + 4;
        
        var urlParameters = window.location.href.substring(index, window.location.href.length);
        
        if (contains(urlParameters, "#")) {
            urlParameters = urlParameters.replace("#", "");
        }

        if (contains(urlParameters,"?")){

            urlParameters = urlParameters.substring(0,urlParameters.indexOf("?"));
        }

        return urlParameters;
    }
    
}

/**
 * Get folder path from current url
 * */
function getFolderPath(){
    
    var currentUrl = getUrlExtraParams();
    return  currentUrl.substring(0, currentUrl.lastIndexOf("/"));
}


/**
 * return true if a column is not listed here and can be editable
 * */
function allowedToEditColumnFields(fieldName, artfId) {
    
    if (contains("checkbox_head",fieldName)  
            || contains("submittedByFullname_head",fieldName)  
            || contains("lastModifiedDate_head",fieldName)  
            || contains( "submittedDate_head",fieldName)  
            || contains("closeDate_head",fieldName)
            || contains("folderTitle_head",fieldName)
            || contains("tags_head", fieldName)
            || (contains("artf_head",fieldName) && !itsTracker)
            || getFieldIsDisabled(fieldName, artfId)) {
        return false;
    }
    
    return true;
    
}

/**
 * return true if source string starts with the value of target string
 * */
function startsWith(source, target){
    return source.indexOf(target) == 0;
}

/**
 * return true if source string contains the value of target string
 * */
function contains(source, target){
	if ($j.browser.msie && $j.isArray(source)) {
		// If IE we have to iterate key per key.
		var max = source.length;
		var found = false;
		for (var i = 0; i < max && !found; i++) {
			if (source[i] == target) {
				found = true;
			}
		}
		return found;
		
	}
    return source.indexOf(target) > -1;
}

/**
 * Return true if the column/field its the type text of number, which means
 * just adding the input without going to the server
 * */
function isRegularTextOrNumberField(columnName){
    if (contains(columnName,"remainingEffort_head") 
        || contains(columnName,"actualEffort_head")
        || contains(columnName,"description_head")
        || contains(columnName,"estimatedEffort_head")
        || contains(columnName,"points_head")) {

        return true;
        
    }else {
        return false;
    }
}

/**
 * Return true if the source field name its from the efford kind
 * */
function isEffortField(source){
    
    if (contains(source,"remainingEffort_head") 
            || contains(source,"actualEffort_head")
            || contains(source,"estimatedEffort_head")) {
        return true;
    }else{
        return false;
    }
}

/**
 * Return true if the source field name contains point field
 * */
function isPointField(source){
    return contains(source,"points_head");
}

/**
 * Get the cell name in a format we can validate againts data from server
 * */
function getFormatedCellName(name){
    
	//parse the name from the column name
    var fieldName    = name.substring(0, name.lastIndexOf("_"));
    
    
    if(contains(fieldName,"artifactGroup")){
        fieldName = "group";
    }
    

    if(contains(fieldName, "resolvedInReleaseTitle")){
        fieldName = "resolvedInRelease";
    }
    
    if(contains(fieldName,"reportedInReleaseTitle")){
        fieldName = "reportedInRelease";
    }
    
    if(contains(fieldName,"multiselect-")){
        fieldName = fieldName.substring("multiselect-".length, fieldName.length);
    }
    
    return fieldName;
}

/**
 * Based on the header return the correct string name of the field
 * */
function whichEffortField(source) {
    if (contains(source,"remainingEffort_head")) {
         return REMAINING_EFFORT_FIELD_CONSTANT;
    }else if (contains(source,"actualEffort_head")) {
        return ACTUAL_EFFORT_FIELD_CONSTANT;
    } else {
        return ESTIMATED_EFFORT_FIELD_CONSTANT;
    }
}

/**
 * Return true if the source field name its the type numeric
 * */
function isNumericField(source) {
    if (contains(source,"points_head") 
            || isEffortField(source)) {
        return true;
    }else{
        return false;
    }
}


/**
 * For each actual, remaining or estimated effor field we will have 1 hidden field and combo in order
 * to handle the tracker unit changes, refreshing it values on change
 * */


/**
 * return the jquery instance of the hidden field
 * */
function hiddenField(bigBrotherId){
    //the id of the hidden input that holds the original value will be almost the same
    //just changing 'original_value_' for 'editbox_'
    var elementId = "original_value_"  + bigBrotherId.substring("editbox_".length, bigBrotherId.length);
    return $j("#"+elementId);
}

 
/**
 * Handle the changes on the tracker unit combo for the given field
 * */
 function effortFieldComboChange() {
      var field = $j(this);
      var $inputField = field.parent().children("input").first();
      //the value of the unit multiplier that was selected
      var $selectedTrackerUnitMultiplier = field.children("option:selected").val();

      $inputField.val(Math.round(100 * parseFloat(hiddenField($inputField.attr("id")).val() / $selectedTrackerUnitMultiplier)) / 100);
  }
      
 
 /**
  * Handle the changes on the value of the effor field 
  * */
  function effortInputChange() {
    var field = $j(this);
    var $hiddenValueField = hiddenField(field.attr("id"));
    //the value of the unit multiplier that was selected
    var $selectedTrackerUnitMultiplier = field.parent().children("select").children("option:selected").val();
    trkUnitMultiplier = $selectedTrackerUnitMultiplier
    if (!isNaN(field.val())) {
        if (trkUnitMultiplier == 1) {
            var r = (parseFloat(field.val()) * $selectedTrackerUnitMultiplier);
        } else {
            var r = Math.round(parseFloat(field.val()) * $selectedTrackerUnitMultiplier);
        }
        $hiddenValueField.val(r);
    } else {
        $hiddenValueField.val("-1");
    }
 }
  
  function getObjectSize(object){
      var count = 0;

      for (i in object) {
          if (object.hasOwnProperty(i)) {
              count++;
          }
      }
      
      return count;
  }

  
  /**
   * return the field id if it has one, from the info that was retrieved from the server
   * 
   * */
  function getFieldId(fieldName, artfId){
      
      if (itsTracker) {
          
          var fieldID ;
          //if it is tracker there is only 1 tracker key on the map
          var mapKeys = $j.map(fieldNameIds, function(value, key) {
              
              //handle help text map
              if (!contains(key,"helpTextMap") && !contains(key,"effordFieldMap") && 
                      !contains(key,"hierarchyFieldMap") && 
                      !contains(key,"hierarchyIdentifierMap") &&
                      !contains(key,"requiredFlexFieldMap") &&
                      !contains(key,"flexFieldUserFilterMap") &&
                      !contains(key,"familyFieldMap")) {
                  fieldID = fieldNameIds[key][fieldName];
              }
              
          });
          
          return fieldID; 
      }else {
          var trackerId = fieldNameIds["artifactTrackerMap"][artfId];
          
          if (trackerId == null) {
              return null;
          }
          
          //return the id of the field for that tracker using the name
          return fieldNameIds[trackerId][fieldName];
      }
      
  }
  
  /**
   * return if a field its disabled, only used on planning folder view
   * as for tracker columns for disabled fields are not available
   * */
  function getFieldIsDisabled(fieldName, artfId) {
	  
	  fieldName = getFormatedCellName(fieldName);
	  
	  if (fieldName == null || artfId == null || itsTracker) {
		  return false;
	  }
	  
	  var trackerId = fieldNameIds["artifactTrackerMap"][artfId];
      
      if (trackerId == null) {
          return null;
      }
      
      var fieldIsDisabled = fieldNameIds[trackerId]["disabledFields"][fieldName];
      
      return fieldIsDisabled != null;
	  
  }
  
  /**
   * return if a field belongs to a tracker where the user has no permission to edit
   * */
  function getFieldItsFromANonEditableTracker(fieldName, artfId) {
	  
	  fieldName = getFormatedCellName(fieldName);
	  
	  if (fieldName == null || artfId == null || itsTracker) {
		  return false;
	  }
	  
	  var trackerId = fieldNameIds["artifactTrackerMap"][artfId];
      
      if (trackerId == null) {
          return null;
      }
      
      var canEdit = fieldNameIds[trackerId]["_has_permission"];
      return canEdit === "true";
	  
  }
  
  /**
   * open the planning folder windows for the selection
   * */
  function launchPlanningFolderPopup(row) {
      var folderPathValue = "" ;
      var url;
      if ( $j("#assignedPlanningFolderPath_" + row).val().length > 0 ){
             folderPathValue = $j("#assignedPlanningFolderPath_" + row).val();
             url = '/sf/tracker/do/planningFolderPopup/' + folderPathValue + "?field_row=" + row;
      }else {
          url = '/sf/tracker/do/planningFolderPopup/' + getFolderPath()  +"?folderKey=" + $j("#assignedPlanningFolder_" + row).val() + "&field_row=" + row;
    	  if (contains(window.location.href,'/go/')) {
    	  url = '/sf/tracker/do/planningFolderPopup' + getProject()  +"?folderKey=" + $j("#assignedPlanningFolder_" + row).val() + "&field_row=" + row;
    	  }
      }
      NewWindow(url, 'sfassignplanning', 540, 535, 'yes');
    }

  /**
   * open the team windows for the selection
   * */
  function launchTeamPopup(row) {
      var url;
      var selectedTeamUrl = $j("#selectedTeamUrl_" + row).val();
      if(selectedTeamUrl.indexOf("teamId") > 0) {
        selectedTeamUrl = selectedTeamUrl.replace('&amp;', '&');
        url = '/sf/tracker/do/teamSelectionPopup/' + selectedTeamUrl + "&field_row=" + row;
      }else {
        url = '/sf/tracker/do/teamSelectionPopup/' + selectedTeamUrl + "?field_row=" + row;  
      }

      NewWindow(url, 'sfassignteam', 400, 455, 'yes');
    }

  /**
   * Used to handle artifacts that are dynamically inserted on the table, for the planning folder view
   * */
  function handleChildArtifactOnPlanningFolder(parentArtfId) {
      
        //child artifact row using parent artf id
        var row = $j('input[value="'+ parentArtfId +'"]').parent().parent().parent().children().index($j('input[value="'+ parentArtfId +'"]').parent().parent()) + rowTableConstant + 1;
        
        if (isAlien($j("#ArtifactListTable tr:eq(" + row + ")"))){
            //it can't be edited
            return;
        }
        
        if (editMode) {
        	var childrenRows = $j("tr[id*=" + parentArtfId + "]");

        		$j.each(childrenRows, function(i, value) {
            		
        			if (i == 0){
                		//skip as its the parent
                	}else {
                		//disabling links    
                        $j.each($j(this).children().children("a"), function(i, value) {
                            $j(this).attr("href","#");
                            $j(this).bind("click",stopHrefClickDefaultBehaviour);
                        });

                        greyOutNonEditableFields($j(this).children());
                        
                        $j.each($j(this).children(), function(i, value) {
                        	setAutoSummingAndMonitoringIcons($j(this));
                        	
                        	if (!$j(this).hasClass("inline-edit-disabled")) {
                        		$j(this).css("cursor", "pointer");
                        		$j(this).addClass("edit");
                        	}
                        });
                        
                        $j.each($j(this).find("img[class=Branch][id^=img_]"), function(i, value) {
                        	$j(value).attr('style','cursor: pointer !important;');
                        });

                        setInLineEditor($j(this).children());
                        

                	}
            });
        	
        } else {
        	
        	var childrenRows = $j("tr[id*=" + parentArtfId + "]");
        	
        		$j.each(childrenRows, function(i, value) { 

                	if (i == 0){
                		//skip as its the parent
                	}else {
                		setInLineEditor($j(this).children());
                	}		
        			
        		});
        }
  }
  
  
  /**
   * Return if an artifact its infested or not (read: if it is alien or if it can be editable)
   * */
  function isAlien(trElement) {
      
      //if it has the span class alien.... means its contaminated
      var alienSeed = $j(trElement).children('[headers=artf_head]').children('span').attr("class");
      if (alienSeed != null && startsWith(alienSeed, "alien")) {
          //its alien! call Ripley!
          return true;
      } else {
          return false;
      }
      
  }
  
  /**
   * returnt the value  for the efford field, value that comes from the server for each artf
   * */
  function getEffordFieldValue(effordHeader, artfId) {
      
      if (contains(effordHeader, "actualEffort")) {
          return fieldNameIds["effordFieldMap"][artfId].efforts[0].actualEffort; 
      }else if (contains(effordHeader, "estimatedEffort")) {
          return fieldNameIds["effordFieldMap"][artfId].efforts[0].estimatedEffort; 
      }else {
          return fieldNameIds["effordFieldMap"][artfId].efforts[0].remainingEffort;
      }
      
  }
  
  /**
   * check that the given value its positive and numeric
   * */
  function validatePositiveInt(valueOfTheField){
        var errors = "";
        
        if(valueOfTheField != "") {
            var value = valueOfTheField.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
            var intRegex = /^\d+$/;
            if(!intRegex.test(value)) {
                errors += getEffortFieldErrorMessage();
                success = false;
            }
        } 
        return errors;
    }

  function validateDecimalNo(valueOfTheField) {
     var errors = "";
     if (valueOfTheField != "") {
         var value = valueOfTheField.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
         if (trkUnitMultiplier == 1 && value.indexOf('.') > -1) {
            var tmpValue = value.split('.');
            if (tmpValue[1] != 0) {
                errors += getEffortFieldDecimalErrorMessage();
            }
         }
     }
     return errors;
   }
  
  
  /**
    * Handle the selected family and render the fields.
    * @param fieldName the name of the field.
    * @param artfId the artfid.
    * @param row the clicked position on the table.
    * @param parentFieldDepthFromClickedElement the depth of parent field from the combo that the user is clicking. (This is used when the combos are rendered)
    * @param clickedSelectedValue this is the value of the combo HTMLelement that the user is choosing. (This is used when the combos are rendered)
    **/
  function HierarchyReader (fieldName, artfId, row, parentFieldDepthFromClickedElement, clickedSelectedValue) {
          this.fromParentToChild;
          this.hierarchyValuesMap;
          this.sortedValueFieldsMap;
          this.select;
          var valueKeySelected;
          var itsRequired;
          var noneValueIfRequiredIsNecessary;
     
          /**
          * Init the Hierarchy Reader.
          */
          this.init = function() {
              var hierarchyIdentifierMap = fieldNameIds['hierarchyIdentifierMap'];
              var hierarchyIdentifier = hierarchyIdentifierMap[getFieldId(fieldName, artfId)];
              var hierarchyField = fieldNameIds['hierarchyFieldMap'][hierarchyIdentifier];
              this.fromParentToChild = hierarchyField['fromParentToChild'];
              this.hierarchyValuesMap = hierarchyField['hierarchyValuesMap'];
              this.sortedValueFieldsMap = hierarchyField['sortedValueFieldsMap'];
              this.isRequired = hierarchyField['required'];
          }
    

    /**
     * Reads from a collection and writes the options on html select.
     */
    this.loadOptionsFrom = function(select, collectionIterator, currentHierarchyValuesMap, isComboFirstCreation, selectedHtmlOptionValue, isRequired, sortedValues) {
        if (!isComboFirstCreation && ((currentHierarchyValuesMap === undefined) || (getObjectSize(currentHierarchyValuesMap) == 0))) {
            // The hierarchy is undefined and enabling the flag to show a 'None' value on the option.
            noneValueIfRequiredIsNecessary = true;
             return;
         }

        if (selectedHtmlOptionValue === undefined) {
            // if the selectedHtmlOptionValue is still undefined assuming the value of the current select
            selectedHtmlOptionValue = select.val();
        }
        
        var iterator = currentHierarchyValuesMap;

        //make iterator sorted by display order
        if (sortedValues != undefined) {
            var currentHierarchyValuesList = new Array();
            var convertMap2List = collectionIterator(iterator, function(values, key) {
                currentHierarchyValuesList.push(key);
            });
            //The collectionIterator variable can be a map iterator or an array iterator. Bounded to an array iterator when sortedValues variable exists. 
            collectionIterator = $j.each;
            
            var sortedIterator = new Array();

            $j.each(sortedValues, function(index, value) {
            	if ($j.inArray(value, currentHierarchyValuesList) >= 0) {
            		sortedIterator.push(value);
            	}
            });
            
            iterator = sortedIterator;
        }
        
        var already = false;
        var size = 0;
        var mapKeys = collectionIterator(iterator, function(values, key) {
            var setSelectedProperty = "";

            if ((selectedHtmlOptionValue.length > 0 || isRequired) && contains(key, selectedHtmlOptionValue) && (selectedHtmlOptionValue.length > 0) && (!already)) {
                setSelectedProperty = 'selected=\"selected\"';
                valueKeySelected = key;
                already = true;
             }
            size++;
            select.append('<option value="' + encodeHtmlAttribute(key) + '" ' + setSelectedProperty + ' >' + encodeHtml(key) + '</option>');
        });
        if (!already && selectedHtmlOptionValue != undefined && (isComboFirstCreation || size === 0)) {
            select.append('<option value="' + encodeHtmlAttribute(selectedHtmlOptionValue) + '" selected="selected">' + encodeHtml(selectedHtmlOptionValue) + '</option>');
        }
    }
    
    /**
     * Indicates the index of the column by its flex field name.
     */
          this.getColumnIndex = function(currentFlexFieldName) {
             var column = 0; 
              $j.each(visibleColumns.split(':'), function(index, flexFieldValue) {
                  if (currentFlexFieldName == flexFieldValue) {
                      column = index;
                      return false;
                  }
              });
              return column;
          }


    /**
     * Process all the hierarchy building the HTML selects.
     */
    this.processHierarchy = function() {
        var currentHierarchyValuesMap = this.hierarchyValuesMap;
        // isComboFirstCreation indicates if combos are creating for first time
        var isComboFirstCreation = (parentFieldDepthFromClickedElement == null);
        var immediateParentHtmlOptionValue = undefined;

        var parentFieldDepth = 0;
        for (parentFieldDepth = 0; parentFieldDepth < this.fromParentToChild.length; parentFieldDepth++) {
            var currentField = this.fromParentToChild[parentFieldDepth];
            currentFlexFieldName = getFlexFieldName(currentField, artfId);
            var sortedValues = this.sortedValueFieldsMap[currentField];
            
            // Building select html per each family column
            this.select = $j('<select id="' + currentField +'"></select>');
            this.select.attr("class", "FilterInput");
            this.select.attr("name", artfId + "_" + currentFlexFieldName);

            var column = this.getColumnIndex(currentFlexFieldName);
            var selectParentElement = $j("#ArtifactListTableData tr:eq(" + row + ") td:eq(" + (column + 1) + ")");
            
            noneValueIfRequiredIsNecessary = false;

            var selectedHtmlOptionValue = undefined;
            if (isComboFirstCreation) {
                // Recovering the value when the data has been already set
                if (selectParentElement.children().length == 0) {
                    selectedHtmlOptionValue = selectParentElement.text().length == 0 ? selectParentElement.html() : selectParentElement.text();
                } else {
                    selectedHtmlOptionValue = selectParentElement.children().val();
                }
             }
            if (selectedHtmlOptionValue === undefined) {
                // If not html option value has been already set
                selectedHtmlOptionValue = (parentFieldDepthFromClickedElement == 0)? clickedSelectedValue : selectedHtmlOptionValue;
                if (valueKeySelected != undefined) {
                    selectedHtmlOptionValue = selectParentElement.children().val();
                    if (selectedHtmlOptionValue == null) {
                        // This could be happening in case the element has no child options and is leaf not in last level
                        noneValueIfRequiredIsNecessary = true;
                    }
                }
            }

            if (parentFieldDepth == 0) {
                // The top parent is a map
                if (selectedHtmlOptionValue === undefined) {
                    selectedHtmlOptionValue = selectParentElement.children().val();
                }
                this.loadOptionsFrom(this.select, $j.map, currentHierarchyValuesMap, isComboFirstCreation, selectedHtmlOptionValue, this.isRequired, sortedValues);
            } else if (parentFieldDepth != this.fromParentToChild.length - 1) {
                    // The middle elements are maps
                    if ((valueKeySelected === undefined) || (valueKeySelected.length == 0)) {
                        valueKeySelected = this.select.val();
                        if (valueKeySelected == null && this.isRequired) {
                            // A value key selection must be mandatory in requiered mode
                            valueKeySelected = immediateParentHtmlOptionValue;
                        }
                    }

                    if (valueKeySelected != null) {
                        // Crossing inside the hierarchy values map
                        var copyCurrentMap = currentHierarchyValuesMap[valueKeySelected];
                        this.loadOptionsFrom(this.select, $j.map, copyCurrentMap, isComboFirstCreation, selectedHtmlOptionValue, this.isRequired, sortedValues);
                        // Saving the new hierarchy for further use
                        currentHierarchyValuesMap = copyCurrentMap;
                    }

                    if ((valueKeySelected == null) && (this.isRequired)) {
                        // Enable the flag to use 'None' value in required after loading the options for map
                        noneValueIfRequiredIsNecessary = true;
                    }

                    if (isComboFirstCreation || (parentFieldDepthFromClickedElement <= parentFieldDepth)) {
                        if (((selectedHtmlOptionValue != undefined) || (selectedHtmlOptionValue != "null")) && (currentHierarchyValuesMap[selectedHtmlOptionValue] != undefined)) {
                            valueKeySelected = selectedHtmlOptionValue;
                            if ((selectedHtmlOptionValue == "null") && this.isRequired) {
                                valueKeySelected = getfirstKey(currentHierarchyValuesMap);
                            }
                        } else {
                            valueKeySelected = getfirstKey(currentHierarchyValuesMap);
                        }
                    }
            } else {
                // The last child of the map is an array
                if (valueKeySelected == null) {
                	valueKeySelected = immediateParentHtmlOptionValue;
                }

                var array = undefined;
                if ((currentHierarchyValuesMap != undefined) && (valueKeySelected != undefined) && (valueKeySelected != "")) {
                    array = currentHierarchyValuesMap[valueKeySelected];
                }

                this.loadOptionsFrom(this.select, $j.each, array, isComboFirstCreation, selectedHtmlOptionValue, this.isRequired, sortedValues);
            }

            // Adding ajax behaviour to select parent element
            selectParentElement.html('');
            selectParentElement.unbind('click');
            selectParentElement.addClass('ajax');

            if (!this.isRequired || noneValueIfRequiredIsNecessary) {
                // Adding None value as first option of the html select
                var selectedActivated = "";
                if ((isComboFirstCreation && (selectedHtmlOptionValue == "")) || (!isComboFirstCreation && (parentFieldDepth > parentFieldDepthFromClickedElement))) {
                    selectedActivated = "selected=\"selected\"";
                }
                this.select.prepend('<option value="' + $j('input[name=noneId]').val() +'" ' + selectedActivated + '>' + $j("[name=noneValue]").val() + '</option>');
                var orderedChildren = this.select.children().get();
                this.select.children().remove();
                this.select.append(orderedChildren);
                if ($j.browser.msie || $j.browser.mozilla) {
                	//because ff mess up with selected values on select elements
                    var comboValueSelected = "null";
                    if (selectedHtmlOptionValue != "") {
                        comboValueSelected = selectedHtmlOptionValue;
                        if ((this.select.children("option[value='" + comboValueSelected + "']").val() === undefined) || ((parentFieldDepth > parentFieldDepthFromClickedElement) && (parentFieldDepthFromClickedElement != null))) {
                            comboValueSelected = "null";
                        }
                    }
                    this.select.children("option[value='" + comboValueSelected + "']").prop('selected','selected');
                }

                // disabling because it is only none
                if (this.select.children().length == 1) {
                    this.select.prop("disabled", true);
                }
            }

            var thisIsNotTheLastElementOnTheHierarchy = (parentFieldDepth < parentFieldDepthFromClickedElement + 2);
            if ((this.isRequired || thisIsNotTheLastElementOnTheHierarchy) && (this.select.prop('disabled') === false)) {
                var comboAttributes = new Object();

                // Set those values to use when the fields gets clicked
                comboAttributes["artf"] = artfId;
                comboAttributes["fieldname"] = fieldName;
                comboAttributes["parentFieldDepth"] = parentFieldDepth;
                hierarchyFieldsAttributesCache[this.select.attr("id")] = comboAttributes;

                this.select.change(function() {
                    var comboAttributes = hierarchyFieldsAttributesCache[$j(this).attr("id")];
                    reRenderTheFamily($j(this).parent(), comboAttributes["artf"], comboAttributes["fieldname"], comboAttributes["parentFieldDepth"], this.value);
                });

            }
            
            if ((immediateParentHtmlOptionValue != undefined) && startsWith(immediateParentHtmlOptionValue, "null")) {
                // Disabling if the previous html value option is null. 
                this.select.prop("disabled", true);
            }
            
            if (!this.isRequired && ((isComboFirstCreation && parentFieldDepth != 0) || ((!isComboFirstCreation) && (parentFieldDepth > parentFieldDepthFromClickedElement + 1)))) {
                // Disabling the following selects of the next select because the selection has not been done in not required mode.
                this.select.prop("disabled", true);
            }
            
            if (!this.isRequired && (parentFieldDepth == parentFieldDepthFromClickedElement) && (clickedSelectedValue != null)) {
                this.select.attr('value', clickedSelectedValue);
                this.select.children("option[value='" + clickedSelectedValue + "']").prop('selected','selected');
            }
            // Saving the value of the previous immediate select
            immediateParentHtmlOptionValue = this.select.val();
            this.select.appendTo(selectParentElement);

            var helpText = getHelpText(currentField);
            if (helpText != null) {
                helpText.appendTo(selectParentElement);
            }
        }
     }

  }
  
  /**
   * Render the family again
   * @param parentElement the td that contains the field
   * @param artfId the artfid
   * @param fieldName the name of the field
   * */
function reRenderTheFamily(parentElement, artfId, fieldName, parentFieldDepthFromClickedElement, clickedSelectedValue) {
    var row = parentElement.parent().index();
    var hierarchy = new HierarchyReader(fieldName, artfId, row, parentFieldDepthFromClickedElement, clickedSelectedValue);
    hierarchy.init();
    hierarchy.processHierarchy();
    $j(window).trigger("resize");
    removeFromCache = true;
    if ($j.inArray(artfId, artifactsModified) < 0) {
        artifactsModified.push(artfId);
      }
  }
  
  /**
  * return the flex field name if it has one, from the info that was retrieved from the server
  * @param fieldId the id of the field
  * @param artfId the artfid
  * */
    function getFlexFieldName(fieldId, artfId){
  
          if (itsTracker) {          
                  if (flexFieldMapIdName === undefined) {
                      flexFieldMapIdName = new Object();
                      var flexFieldName;
                      // if it is tracker there is only 1 tracker key on the map
                      var mapKeys = $j.map(fieldNameIds, function(value, key) {                  
                          // handle help text map, skip other maps to use the tracker
                          if (!contains(key, "helpTextMap") && !contains(key, "effordFieldMap")
                              && !contains(key, "hierarchyFieldMap")
                              && !contains(key, "hierarchyIdentifierMap")
                              && !contains(key, "familyFieldMap")) {
                          $j.each(value, function(key2, value2) {
                          flexFieldMapIdName[value2] = key2;
                  });
              }
                    
              });
          }
      return flexFieldMapIdName[fieldId];
      } else {
        //for now, flex fields only for tracker.
      }
      return flexFieldName;
  } 
    
    
/**
 * Get the fisrt key of the map
 * @param data the map
 * @return the first key element
 * */
    function getfirstKey(data) {
        for (var prop in data)
          return prop;
    }
  
/**
 * return if it is a "" or " " string
 * */
function stringIsEmptyOrIsWhiteSpaces(stringToEvaluate) {
     return stringToEvaluate.replace(/\s/g, '').length < 1;
}


/**
 * return true if the field exist on the map which mean its required
 * */
function getIsRequiredField(fieldId) {
    return fieldNameIds["requiredFlexFieldMap"][fieldId] != null;
}

/**
 * return the localized name of the field
 * */
function getRequiredFieldName(fieldId) {
    return fieldNameIds["requiredFlexFieldMap"][fieldId];
}

/**
 * as the tr id of a child artifact will contain:
 * row_artParent_child1_child2_childx
 * we will store ids in case it is a child
 * @param rowId the complete string 
 * */
function addArtifactToWarnUserIfCollapse(rowId) {
	var artfIds = rowId.split('_');
	var currentArtifactId = artfIds[artfIds.length -1]; 
	//first is the "row" word, second the parent artf
	if (artfIds.length > 2) {
		var tempArray = []; 
		
		for (var i = 1 ; i < artfIds.length -1; i++) {
				 tempArray[i-1] = artfIds[i];
		 }
		 artifactsThatShouldNotBeCollapsed[currentArtifactId] = tempArray;
	}
}

/**
 * return wheter the the selected artifact has expanded child
 * that were edited
 * @param artfId
 * */
function artifactHasEditedChildrens(artfId) {
	var result = false;
	$j.each(artifactsThatShouldNotBeCollapsed, function(i, value){
		if ($j.inArray(artfId, $j(this)) > -1) {
			result = true;
			return;
		}
	});
	
	return result;
}

/**
 * Remove the reference to artifacts that were edited but they re being collapsed
 * meaning the changes get discarded after user acceptance
 * @param artfId
 * */
function removeArtifactsThatWereEditedAndAreBeingCollapsed(artfId) {
	var tempObject = new Object();
	
	 $j.map(artifactsThatShouldNotBeCollapsed, function(value, key) {
		 
		 if ($j.inArray(artfId, value) > -1) {
				artifactsModified = $j.grep(artifactsModified, function(newValue) {
					  return newValue != key;
				});
		 } else {
				tempObject[key] = value;
		 }
	 });                  
	
	artifactsThatShouldNotBeCollapsed = tempObject;
}
