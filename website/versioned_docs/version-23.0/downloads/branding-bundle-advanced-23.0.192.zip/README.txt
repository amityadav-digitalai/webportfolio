The CollabNet TeamForge branding archive

This package contains default content for a number of files that you can use to 
override the default look and feel of your TeamForge site. You can customize your 
CollabNet TeamForge site's visual appearance (via changes to images, CSS, 
JavaScript), the content of emails sent from the site, and even some
application behaviors.

Among the things you can override:

* Images
* Style sheets
* JavaScript
* Resource bundle strings (internationalized label text for all UI elements on
* the site)
* Email templates (internationalized)
* Velocity templates (certain page elements, such as headers and footers,
* which are
  rendered using the Velocity templating language)
* HTML snippets at the top and bottom of particular application pages
* Domain home page (instead of static image)

Every instance of CTF contains a "look" project, which includes a special
Subversion repository called "branding." You override a particular file by
committing
your modified version into this repository. For detailed instructions, see
http://help.collab.net/topic/teamforge820/action/branding.html

The files packaged with this document are the default, original versions of
most of these files. Only the particular files being overridden should be committed to
the branding repository. 

You must have the most recent available version of this archive as a starting
point. If the version number at the top of this file does not match your version of
TeamForge, check www.collab.net for a more recent version.

