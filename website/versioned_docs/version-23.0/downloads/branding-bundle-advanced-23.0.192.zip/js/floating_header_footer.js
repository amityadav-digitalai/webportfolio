/*
 * CollabNet TeamForge(r)
 * Copyright 2007-2013 CollabNet, Inc.  All rights reserved.
 * http://www.collab.net
 * 
 * This code snippet handles the floating header and footer over artifact list, 
 * planning folder list, ranking view and User-Role matrix view. 
 * 
 * @author Rodrigo Jaen (rodrigo.jaen@bvision.com)
 */
/***
 * offset left of the header
 * */
var startingOffSetLeft;

/***
 * offset top of the footer
 * */
var startingPointForFooter;

/***
 * Extra pixel for offset top in IE and chrome.
 * */
var topDelta = 0;

/**
 * add the necessary class to handle the footer and header 
 * that will be float
 * */
function setFloatingComponentsData(isPlanningFolder) {

    if ($j(".visibleHeader").length == 0) {
        $j(".ItemListHeader").parent().addClass("visibleArea");
        $j(".ItemListHeader").addClass("visibleHeader");
        
        var $footerContainer;
        
        if (isPlanningFolder) {
            $footerContainer = $j("#treeFooterLast");
        } else {
            $footerContainer = $j(".ContainerFooter");
        }
        
        $footerContainer.addClass("visibleFooter");
        startingOffSetLeft = $j("#tableContainer").offset().left;
        startingPointForFooter = $j(window).height() - $footerContainer.height();

        //bind check boxes to trigger a refresh on the footer every time
        //any of them is checked
        $j("input[type=checkbox]").bind("click", refreshFooterButtons);
    }
    
}

/**
 * Every time the scroll event is triggered refresh header and footer position 
 * */
function updateTableHeaders() {
  $floatingFooter = $j(".floatingFooter");

    $j(".visibleArea").each(function() {
        var el = $j(this),
        offset = el.offset(),
        scrollTop = $j(window).scrollTop(),
        $floatingHeader = $j(".floatingHeader", this),
        fixedTopNavHeight = 41;
        
        var pageXOffset = $j(window).scrollLeft();

        helpTxtHt = 0;
        if ($j('#EditInlineHelpText').is(":visible")) {
            helpTxtHt = $j('#EditInlineHelpText').height();
        }
        /**
         * Header
         * */
        if ((scrollTop > ((offset.top - fixedTopNavHeight) + helpTxtHt)) && (scrollTop < (offset.top - fixedTopNavHeight)  + el.height() - 2 * $floatingHeader.height())) {
           
            $floatingHeader.css({"visibility": "visible"});
            $floatingHeader.css("width",  $j("#tableContainer").outerWidth() + "px");
            //handle left scroll
            $floatingHeader.css("left", startingOffSetLeft - pageXOffset + "px");
        } else {
            $floatingHeader.css({"visibility": "hidden"});
        }
        if( $floatingFooter.length != 0 ) {
        /**
         * Footer
         * */
        var footerOffset = $floatingFooter.offset();
        var $firstRow = $j('#ArtifactListTableData .OddRow:eq(0)');
        var firstArtfRowOffsetTop = 0;
        if ($firstRow.length) {
            firstArtfRowOffsetTop = $firstRow.offset().top;
        }
        var firstRowHeight = $firstRow.height();
        var $tableContainer = $j("#tableContainer");

        /**
         * Monitoring menu Window
         * */
        var $floatingMonitoringWindow;
        var $floatingImportWindow;
        $floatingMonitoringWindow = $j("#MonitorMenu_selectArtifactsForm");
        $floatingImportWindow = $j("#ImportArtifactsMenu");

        /**
         * Planning Folder create artifact in tracker
         * */
        var $floatingCreateArtifactMenu = $j("#createArtifactMenu");
        var $footerHeight = 0;

        //If footer within visibleArea then include footer height in offset calculation.
        if ($j(".visibleArea .visibleFooter").length) {
            $footerHeight = $floatingFooter.height();
        }

        if (($tableContainer.offset().top + $tableContainer.height() - $footerHeight > footerOffset.top) &&
                ($tableContainer.offset().top + $floatingHeader.height() + 40 < footerOffset.top)) {

            //footer
            //Fix: artf197541, when having multiple session messages the footer may overlap artifacts, the fix prevent that.
        	if ((firstArtfRowOffsetTop) < footerOffset.top) {
                $floatingFooter.css({"visibility": "visible"});
            }
            $floatingFooter.css("left", startingOffSetLeft - pageXOffset + "px");

            //monitoring menu
            $floatingMonitoringWindow.css("top", startingPointForFooter - $floatingMonitoringWindow.height());
            $floatingMonitoringWindow.css("position", "fixed");

            if ($j("#selectionMenuButton_MonitorMenu_selectArtifactsForm").length > 0) {
                var leftFixedOffset = $j("#selectionMenuButton_MonitorMenu_selectArtifactsForm").offset().left - pageXOffset;
                $floatingMonitoringWindow.css("left", leftFixedOffset + "px");
            }

            //import menu
            $floatingImportWindow.css("top", startingPointForFooter - $floatingImportWindow.height());
            $floatingImportWindow.css("position", "fixed");

            if ($j("#selectionMenuButton_ImportArtifactsMenu").length > 0) {
                var leftFixedOffset = $j("#selectionMenuButton_ImportArtifactsMenu").offset().left - pageXOffset;
                $floatingImportWindow.css("left", leftFixedOffset + "px");
            }
                        
            //create artifact in tracker menu
            if ($floatingCreateArtifactMenu.length > 0 && $floatingCreateArtifactMenu != null) {
                var menuIsCurrentVisible = $floatingCreateArtifactMenu.css("visibility") == "visible";
                $floatingCreateArtifactMenu.css("position", "fixed");
                
                if ($j("#selectionMenuButton_createArtifactMenu1").length > 0) {
                    var leftFixedOffset2 = $j("#selectionMenuButton_createArtifactMenu1").offset().left - pageXOffset - $floatingCreateArtifactMenu.width();
                    $floatingCreateArtifactMenu.css("left", leftFixedOffset2 + "px");
                }
                
                if (menuIsCurrentVisible) {
                    $j("#selectionMenuButton_createArtifactMenu").trigger("click");
                }
            }
        } else {
            //footer
            $floatingFooter.css({"visibility": "hidden"});
            
            //monitoring menu
            $floatingMonitoringWindow.css("position", "absolute");
            $floatingMonitoringWindow.css("top", $j(".visibleFooter").first().position().top - $floatingMonitoringWindow.height());
            
            //if the length its < than 0, means the element is not present
            if ($j("#selectionMenuButton_MonitorMenu_selectArtifactsForm").length > 0) {
                $floatingMonitoringWindow.css("left", $j("#selectionMenuButton_MonitorMenu_selectArtifactsForm").offset().left + "px");
            }

            //import menu
            $floatingImportWindow.css("position", "absolute");
            $floatingImportWindow.css("top", $j(".visibleFooter").first().position().top - $floatingImportWindow.height());

            //if the length its < than 0, means the element is not present
            if ($j("#selectionMenuButton_ImportArtifactsMenu").length > 0) {
                $floatingImportWindow.css("left", $j("#selectionMenuButton_ImportArtifactsMenu").offset().left + "px");
            }
            
            //create artifact in tracker menu
            if ($floatingCreateArtifactMenu.length > 0 && $floatingCreateArtifactMenu != null) {
                var menuIsCurrentVisible = $floatingCreateArtifactMenu.css("visibility") == "visible";
                $floatingCreateArtifactMenu.css("position", "absolute");
                if (menuIsCurrentVisible) {
                    $j("#selectionMenuButton_createArtifactMenu").trigger("click");
                }
            }
        }
    }
    
    });

}


/**
 * The footer buttons change the state from enabled to disabled depending the amount of
 * checkboxes (artifacts) that are selected. So to keep the floating footer synchronized
 * we just re clone the footer and refresh the floating version.
 * */
function refreshFooterButtons(){
    /*Footer*/
    var $clonedFooterRow;
    $clonedFooterRow = $j(".visibleFooter").first().clone();
    $j(".visibleFooter").last().remove();
    $clonedFooterRow.css("width", $j(".visibleFooter").width());
    $clonedFooterRow.children().first().css("width", $j(".visibleFooter").width());
    $clonedFooterRow.addClass("floatingFooter");
    $clonedFooterRow.find("#selectionMenuButton_createArtifactMenu").attr("id","selectionMenuButton_createArtifactMenu_cloned");
    $clonedFooterRow.find("#selectionMenuButton_createArtifactMenu_cloned").bind("click", attachSelectionMenu);
    $j(".visibleFooter").after($clonedFooterRow);
    $clonedFooterRow.css("top", startingPointForFooter + topDelta);

    $j(window).trigger("resize");
}


/**
* Attach separator menu to the floating menu
**/
function attachSelectionMenu() {
    $j('#selectionMenuButton_createArtifactMenu_cloned [id=selectionMenu]').remove();
    $j("#menu_createArtifactMenu").clone(true, true).contents().appendTo('#selectionMenuButton_createArtifactMenu_cloned');
    $j("#selectionMenuButton_createArtifactMenu_cloned div").removeClass("selectionMenu");
    var top = $j("#selectionMenuButton_createArtifactMenu_cloned").closest('.floatingFooter').position().top;
    $j("#selectionMenuButton_createArtifactMenu_cloned div div").css("right", "57px").css("top", top - 192);
}

/**
 * Create the floating tr's, append to DOM (parent table) and bind scroll event to the components  
 * */
function doTheHeaderRender() {
    if ($j(".floatingHeader").length == 0) {

      //Container for holding floating header rows.
       $j(".visibleHeader:last").after("<table class=\"floatingHeader\" style=\"border-collapse: collapse;\"></table>")

       /*Header*/
       $j(".visibleArea").each(function() {
           $j.each($j(".visibleHeader"), function(i, value) { 
               var $clonedHeaderRow = $j(this).clone();
               $clonedHeaderRow.css("width", $j(this).width());
            $clonedHeaderRow.css("padding", "0");
            $clonedHeaderRow.addClass("floatingHeaderRow");
            setTrDimensions($j(this), $clonedHeaderRow);
            $j(".floatingHeader").append($clonedHeaderRow);
        });      
    });

        /*Footer*/
        var $clonedFooterRow;
        $clonedFooterRow = $j(".visibleFooter").clone();
        $clonedFooterRow.css("width", $j(".visibleFooter").width());
        $clonedFooterRow.children().first().css("width", $j(".visibleFooter").width());
        $clonedFooterRow.addClass("floatingFooter");
        $clonedFooterRow.find("#selectionMenuButton_createArtifactMenu").attr("id","selectionMenuButton_createArtifactMenu_cloned");
        $clonedFooterRow.find("#selectionMenuButton_createArtifactMenu_cloned").bind("click", attachSelectionMenu);
        $j(".visibleFooter").after($clonedFooterRow);
 
        /*In IE and chrome, user-role matrix page requires extra pixel for top offset of footer */       
        if (!$j.browser.mozilla && ($j(".floatingHeaderRow").length > 1)) {
           topDelta = 1;
        }
        $clonedFooterRow.css("top", startingPointForFooter + topDelta);

        /*Monitoring menu Window*/
        var $floatingMonitoringWindow;
        var $floatingImportWindow;
        $floatingMonitoringWindow = $j("#MonitorMenu_selectArtifactsForm");
        $floatingMonitoringWindow.css("position", "fixed");
        
        $floatingImportWindow = $j("#ImportArtifactsMenu");
        $floatingImportWindow.css("position", "fixed");
        setTimeout(function(){
        $j(window).scroll(updateTableHeaders).trigger("scroll");
        }, 0);

    }
}


/**
 * Add the column sizes to the floating header 
 * */
function setTrDimensions($originalTr, $clonedHeaderRow) {
    
    var browserDelta = 1;
    if($j.browser.mozilla){
        browserDelta = 0;
    }
    /* Hack to verify if its IE10 (even if browser mode is changed to IE9) */
    /*@cc_on
          if (/^10/.test(@_jscript_version)) {
                browserDelta = 0 ;
                              }
   @*/
    
    var $clonedChildrens = $j.makeArray($clonedHeaderRow.children());
    $originalTr.children().each(function(i, value) {
    var child = $j($clonedChildrens).get(i);
    $j(child).css("width" ,$j(this).width() + browserDelta + "px"); 
    });
}

/**
 * When the browser get resized re calculate the necessary 
 * */
function updateOnResize(isPlanningFolder) {

      var $footerContainer;
      var count = $j(".floatingHeaderRow").length;
     if (isPlanningFolder) {
        $footerContainer = $j("#treeFooterLast");
     } else {
        $footerContainer = $j(".ContainerFooter");
     }
     
      var $tableContainer = $j("#tableContainer");
      var newWidth = $tableContainer.outerWidth();

      $j(".floatingHeader").css("width", newWidth);
      $j(".floatingFooter").css("width", newWidth);
      $j(".floatingFooter").children().first().css("width", newWidth);
/** In case of user-role matrix page there are two headers so on cloning, there will be four rows with 
 *  visibleHeader style class. To avoid calling setTrDimensions for all four rows, limit the call to the 
 *  number of original rows or the cloned rows(As both will be same number).
*/
      $j.each($j(".visibleHeader"), function(i, value) {
          if( i == count) {
             return false; 
          } 
          setTrDimensions($j(this),$j(".floatingHeaderRow:eq(" + i + ")"));
      });
      startingOffSetLeft = $tableContainer.offset().left;
      startingPointForFooter = $j(window).height() - $footerContainer.height();
      $j(".floatingFooter").css("top", startingPointForFooter + topDelta);
      $j(window).scroll();
}

var tableWidth = 0;
var tableHeight = 0;
var tableOffSetLeft = 0;

/**
 * This function will be executed every 100ms
 * the purpose is to check if the dimension or the position 
 * of the table changed, if it did, then fire the update
 * */
function checkWidthAndHeight() {
    
    if (tableWidth == 0 || tableHeight == 0 || tableOffSetLeft == 0) {
        setWidthHeightValues();
    }

    var $tableContainer = $j("#tableContainer");
    if (tableWidth != $tableContainer.width() || tableHeight != $tableContainer.height()
            || tableOffSetLeft != $tableContainer.offset().left) {
        setWidthHeightValues();
        $j("input[type=checkbox]").bind("click", refreshFooterButtons);
        $j(window).trigger("resize");
    }
}

/**
 * Set the current width and height of the table to the global var's
 * */
function setWidthHeightValues() {
    var $tableContainer = $j("#tableContainer");
    tableWidth = $tableContainer.width();
    tableHeight = $tableContainer.height();
    tableOffSetLeft = $tableContainer.offset().left;
}
