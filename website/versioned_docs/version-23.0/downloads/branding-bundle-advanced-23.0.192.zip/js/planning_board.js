/*@COPYRIGHT
 *TeamForgeForge(r) Enterprise Edition
 *Copyright 2013 CollabNet, Inc. All rights reserved.
 *http://www.collab.net
 *COPYRIGHT@
 */

/**
 * Module declaration 'Planning'
 */
Planning = new PlanningHandler(WebClient, Artifacts, ArtifactEditor);
var vPlanningHandler = Planning;
var vPlanningFolderPath, vArtifactWidget;

   function redirectLogin() {
       vPlanningHandler.refresh(vPlanningFolderPath, vArtifactWidget);
   }

function PlanningHandler(webClientHandler, artifactsHandler, artifactEditorHandler) {
        this.webClient = webClientHandler;
        this.artifacts = artifactsHandler;
        this.artifactEditor = artifactEditorHandler;
        this.onResize = function() {};
        this.columnOptions = {};
        this.messages = {};
        this.permissions = {};
        this.pfSelections = {};

        var projectPathString;
        var swimLaneLimit;
        var frozenPlanningFolders = [];
        var swimLaneSize;
        var expandedIds = new Array();
        var focusParentId;
        var isExpanded = false;
        this.easyuiModules = ['parser', 'combotree', 'combo'];

        var me = this;
        
        this.widgetHeight = 76;
        
        /**
         * Set project path.
         * @param projectPathString the project path to set.
         */
        this.setProjectPath = function(projectPathString) {
             me.projectPathString = projectPathString;
             me.artifacts.setProjectPath(projectPathString);
             me.artifactEditor.setProjectPath(projectPathString);
        };
		
        /**
         * Sets permissions for the planning board.
         * @param permissions the permission JSON.
         */
         this.setPermissions = function(permissions) {
              me.permissions = permissions;
              me.artifacts.setPermissions(permissions);
         };
         
         /**
          * Sets column options.
          * @param columnOptions
          */
          this.setColumnOptions = function(columnOptions) {
              me.columnOptions = columnOptions;
          };
          
          /**
           * Sets url key for further use by artifact cards
           */
          this.setFromUrlKey = function(fromUrlKey) {
        	  this.fromUrlKey = fromUrlKey;
        	  me.artifacts.setReturnUrlKey(fromUrlKey);
        	  me.artifactEditor.setReturnUrlKey(fromUrlKey);
          }
          
          /**
           * Sets the i18n messages.
           * @param messages the messages key value pair.
           */
          this.setMessages = function(messages) {
              me.messages = messages;
              me.artifacts.setMessages(messages);
              me.artifactEditor.setMessages(messages);
          };

          /**
           * Sets the swimlane limit
           * @param swimLaneLimit the swimlane limit.
           */
          this.setSwimLaneLimit = function(swimLaneLimit) {
              me.swimLaneLimit = swimLaneLimit;
            
          };

          this.setFrozenPlanningFolders = function(frozenPlanningFolders) {
              me.frozenPlanningFolders = frozenPlanningFolders;
          }
          /**
           * Sets the swimlane size
           * @param swimLaneLimit the swimlane size.
           */
          this.setSwimLaneSize = function(swimLaneSize) {
              me.swimLaneSize = swimLaneSize;
            
          };
          
        /**
         * Adds listeners to the columns.
         *
         * @param table the table of items to add listeners.
         */
        this.addPlanningListeners = function(table) {

            var artifactEditorOptions = {
                    artifactUpdated: function(artifactId, artifactData) {
                	    var widget = me.artifacts.getArtifactWidgets(artifactId);
                        if (artifactData.assignedToText === 'nobody') {
                            artifactData.assignedToText = me.messages['common.none'];
                        }
                	    me.updateArtifactWidget(artifactData, widget);
                	    var planningFolderPath = widget.closest('.table-column').find('.content-selector').combo('getValue');
                    	var updatedColumns = [];
                    	var teams = [];
                        $j.each(widget, function(key, value){
                          updatedColumns.push($j(value).closest('.table-column').attr('id'));
                          var teamScope = $j(value).closest('.table-column').find('.widgets-team-tree').scope();
                          var teamId = teamScope.teamComboTreeModel.selected.folderPath;
                          teams.push(teamId);
                          me.updateColumnWidget(artifactData, $j(value));
                        });
                        if (artifactData.selectedTeam) {
                        	teams.push(artifactData.selectedTeam);
                        } else {
                        	teams.push('None');
                        }
                	    var samePFColumns = me.getColumnsFromFolderPath(table, planningFolderPath);
                        $j.each(samePFColumns, function(key, value){
                          var columnId = $j(value).attr('id');
                	      var isColumnMatched = $j.inArray(columnId, updatedColumns) > -1;
                	      if(!isColumnMatched) {
                            var teamScope = $j(value).find('.widgets-team-tree').scope();
                            var teamId = teamScope.teamComboTreeModel.selected.folderPath;
                            var isTeamMatched = $j.inArray(teamId, teams) > -1;
                            if(!teamId || isTeamMatched) {
                              me.updateColumnData($j(value).find('.content-selector'), true);    	
                            }
                	      }
                        });
                    },
                    artifactCreated: function(artifactData, planningFolderPath, teamId) {
                    	var widget = me.artifacts.createHTMLWidget(artifactData);
                    	var selectors= me.getSelectorFromFolderPath(table, planningFolderPath);
                    	var selectorsCount = selectors.length;
                    	for (var i=0; i < selectorsCount; i++) {
                    		var selector = selectors[i];
                            var columnTeamScope = selector.closest('.table-column').find('.widgets-team-tree').scope();
                            var columnTeamId = columnTeamScope.teamComboTreeModel.selected.folderPath;
                            if (!teamId) {
                            	teamId = 'None';
                            }
                            if (!columnTeamId || columnTeamId === teamId) {
                    		  var column =selector.closest('.table-column').find('.item-destination');
                              if (column.find('.item-nodata').length > 0) {
                                column.find('.item-nodata').remove();
                              }

                              if (selector.closest('.table-column').find('#truncatedMsg').length == 0) {
                                column.append(widget);
                                column.find('.item:last').children('.artifact').addClass('artifact-edited');
                              }

                              var cardCount = selector.closest('.table-column').find('.card-count').text();
                              if (cardCount.length > 0 && !isNaN(cardCount)) {
                                cardCount = parseInt(cardCount) + 1;
                                selector.closest('.table-column').find('.card-count').text(cardCount)
                              }
                        	
                            }
                    	}
                    }
            };
              
            me.artifactEditor.setEditorOptions(artifactEditorOptions);
            
            /**
             * Attaches the events for icon edit selector.
             *
             * Displays artifact editor dialog on click of icon edit.
             */
            table.delegate(".artifact-edit", 'click', function() {

            	var folderPath =  me.webClient.getItemId($j(this).parents('.item').first().children('.tracker'));
                var artifactId = me.webClient.getItemId($j(this).parents('.item').first());
                var version = me.webClient.getItemVersion($j(this).parents('.item').first());
                
                me.artifactEditor.setFolderPath(folderPath);
                me.artifactEditor.createEditorForEditArtifact(artifactId, version);
                
            });
            
            /**
             * Attaches the event for artifact expander selector.
             *
             */
            table.delegate('.artifact-expander', 'click', function() {
                var eventGeneratedColumnId = $j(this).closest('.table-column').attr('id');
                var planningFolderPath = $j(this).closest('.table-column').find('.content-selector').combo('getValue');
                var teamScope =  $j(this).closest('.table-column').find('.widgets-team-tree').scope();
                var teamId = teamScope.teamComboTreeModel.selected.folderPath;
                var artifactKey = me.webClient.getItemId($j(this).parents('.item').first());
                var artifactWidgets = me.artifacts.getArtifactWidgets(artifactKey); 
                var artifactWidget;
                $j.each(artifactWidgets, function(key, value){
                    var columnId = $j(value).closest('.table-column').attr('id');
                    if(eventGeneratedColumnId == columnId) {
                    	artifactWidget = $j(value)
                    }
                });
                var childContainer = artifactWidget.find('.item-destination-'+artifactKey);
                
                var expander = artifactWidget.children('.artifact').find('.artifact-expander');
                
                if ($j(this).html() == "+") {
                    
                    expander.text("−");                    
                    if(childContainer.find('.item').length > 0) {                       
                        childContainer.show();
                        me.applyExpandedParentSettings(artifactWidget);
                        me.initializeChildDragAndDrop(artifactKey, '#planningTable', $j('#'+eventGeneratedColumnId));
                    } else {
                        me.loadChildArtifacts(artifactKey, planningFolderPath, childContainer, teamId, eventGeneratedColumnId).done(function() {
                            me.applyExpandedParentSettings(artifactWidget);
                            me.initializeChildDragAndDrop(artifactKey, '#planningTable', $j('#'+eventGeneratedColumnId));
                            if (isExpanded) {
                              
                             if (expandedIds.length > 0) {
                                expandedIds.splice(0, 1);
                                if (expandedIds && expandedIds.length == 0) {
                                   window.location.hash = '#' + focusParentId;
                                   window.location.hash = "";
                                  isExpanded = false;
                                } else {
                                  me.expandNodes();
                                }
                             }
                            }
                        }).fail(function() {expander.text("+")});
                    }
                } else {
                    expander.text("+");
                    me.removeExpandedParentSettings(artifactWidget);
                    childContainer.hide();
                }
            });
            

            /**
             * Attaches the event for include closed artifact preference selector.
             *
             */
            table.delegate('.include-closed', 'click', function() {
                var includeClosedSelector = $j(this);
                var filterStatus = includeClosedSelector.attr('displayClosedArtifacts');
                if(filterStatus === 'disabled') {
                    return;
                }
                if (filterStatus == "true") {
                    me.changeDisplayClosedArtifactStatus(includeClosedSelector, false);
                } else {
                    me.changeDisplayClosedArtifactStatus(includeClosedSelector, true);
                }
                var planningFolderSelector = $j(this).closest('.table-column').find('.content-selector');
                    me.updateColumnData(planningFolderSelector);
            });
            
            /**
             * Attaches the events for  refresh artifacts in the  swimlane.
             *
             */
            table.delegate('.refresh-btn', 'click', function() {
                var selector = $j(this);
                var artifactWidget=me.webClient.getAsJquery(selector);
                var planningFolderPath = artifactWidget.closest('.table-column').find('.content-selector').combo('getValue');
                var filterStatus = selector.attr('enableButton');

                if(filterStatus === "disabled") {
                    return;
                }
                if (filterStatus) {
                    me.refresh(planningFolderPath, artifactWidget);
                }
            });

            this.refresh = function(planningFolderPath, artifactWidget) {
                  // used for session time-out
                  vPlanningFolderPath = planningFolderPath;
                  vArtifactWidget = artifactWidget;

                  if(!isSessionActive()) {
                    showSessionTimeoutDiv('redirectLogin');
                    return;
                  }
                 if (planningFolderPath != "") {
                     var column = artifactWidget.closest('.table-column');
                     me.refreshPlanningFolderHierarchy(column);
                 }
            }
            /**
             * Attaches the events for  create artifacts.
             *
             */
            
            table.delegate('.add-btn', 'click', function() {
                
                if($j(this).attr('enablebutton')=='disabled'){
                    return;
                } else{
                    var widget=me.webClient.getAsJquery($j(this))
                    var planningFolderPath = widget.closest('.table-column').find('.content-selector').combo('getValue');
               	    me.artifactEditor.setPlanningFolderPath(planningFolderPath);
                    var teamScope =  widget.closest('.table-column').find('.widgets-team-tree').scope();
                    var teamId = teamScope.teamComboTreeModel.selected.folderPath;
                    me.artifactEditor.setTeamId(teamId);
                    me.artifactEditor.createEditorForAddArtifact();
                }

            });


            /**
             * Attaches mouse down event to remove highlighted artifact card after move or edit
             * Note: click event will not be triggered on artifact drag action.
             */
            $j(document).mousedown(function(e) {
                table.find('.artifact-edited').removeClass('artifact-edited');
            });

        };

        /**
         * Applies the display settings when the parent artifact is expanded.
         * Each level of parent will have different display settings.
         * The level of the parent artifact is identified first and is incremented
         * by 1 to set the next level settings. Currently we display only 3 levels
         * of artifacts. So settings are present in the css for 3 levels.
         *
         * @param artifactWidget the artifact widget
         */
        this.applyExpandedParentSettings = function(artifactWidget) {
            var parent = artifactWidget.parents('.parent-expanded:first');
            var containerLevel = 1;
            if (parent.length > 0) {
                containerLevel = parent.data('container-level') + 1;
            }

            artifactWidget.data('container-level', containerLevel);
            artifactWidget.addClass('parent-expanded');
            artifactWidget.addClass('parent-expanded-'+containerLevel);
        };

        /**
         * Removes the display settings when the parent artifact is collapsed.
         *
         * @param artifactWidget the artifact widget.
         */
        this.removeExpandedParentSettings = function(artifactWidget) {
            var containerLevel = artifactWidget.data('container-level');
            artifactWidget.removeData('container-level');
            artifactWidget.removeClass('parent-expanded');
            artifactWidget.removeClass('parent-expanded-'+containerLevel);
        };

        /**
         * Sets up planning column options.
         *
         */
        this.setUpPlanningOptions = function() {
            var columnOptions = {
                updateAction: function(artifactArray, moveData) {me.updatePlanningColumns(artifactArray, moveData);},
                updateColumnData: function(planningFolderSelector, hideLoadingIcon) {me.updateColumnData(planningFolderSelector, hideLoadingIcon);}
            };

            me.artifacts.setUpPlanningOptions(columnOptions);
        };

        /**
         * Computes and resizes the panel to that of column selector combo
         * 
         * @param planningFolderSelector Planning folder selector element
         */
        this.resizePanel = function(planningFolderSelector) {
            var selectorPanel = planningFolderSelector.combotree('panel');
            var selectorWidth = planningFolderSelector.closest('.column-header').find('.combo').outerWidth();
            // Deduct 3px to accommadate parent's border
            selectorPanel.width(selectorWidth - 3);
            selectorPanel.parent('.combo-p').width(selectorWidth);
        }
		
        /**
         * Handles selector width. This is required as CSS calc() is not supported in few CTF supported
         * browsers that includes
         * 	- Internet Explorer 8
         * 	- Chrome version 24
         * 	- Chrome version 25  
         * 
         * Implementation basically calculates the size of the container and then sets the
         * width accordingly for .combo and .combo-text elements
         * 
         * Note : this method is also called when the window is resized.
         * 
         * Note, TODO : This method is not required if we drop support for the listed browsers in future
         */
        this.setSelectorWidth = function() {
            var columns = $j('.table-column');
            columns.each(function(index, column){
                var selectorContainer = $j(column).find('.content-selector-container');
                
                // Set combo width to that of container - closed artifacts filter button
                $j(column).find('.combo').width(selectorContainer.width() - 31);
                $j(column).find('.combo-text').width(selectorContainer.width() - 51);
            });
        };

        /**
         * Attaches the events needed to populate the columns with the selection.
         *
         */
        this.setUpColumnSelectors = function(table) {
                $j(".content-selector").combotree(); 

                if(me.columnOptions) {
                    $j(".content-selector").combotree('loadData', me.columnOptions);
                }
                me.setupColumnListners($j(".content-selector"));
                var columns = table.find('.table-column');
                me.setUpPlanningFolderSelectionListeners(columns);
        };
        
        /**
         * Attaches the events needed to populate the columns with the selection.
         *
         */
        this.setupColumnListners =function(contentSelector) {
        	var pfSelectedAlready;
            var pfChanged;
            var prevPfText,prevPfValue;
            contentSelector.combo({
                                   onChange: function(selectedPlanningFolderPath, oldValue) {
                                       var planningFolderSelector = $j(this);                                           
                                       if(selectedPlanningFolderPath){
                                           pfChanged = true;
                                           var column = planningFolderSelector.closest('.table-column');
                                           // If user is selecting a planning folder for the first time, show closed artifacts filter button and enable refresh button
                                           if(!oldValue) {                                            	   
                                        	   me.displayIncludeClosedArtifacts(column);
                                               me.enableButton(column);
                                           }
                                           // Set the value into pfSelections
                                           me.pfSelections[column.attr('id')]= selectedPlanningFolderPath;
                                           // When user selects an already selected planning folder then avoid a server call
                                           if (prevPfValue !== selectedPlanningFolderPath) {
                                        	   var selectedNode = planningFolderSelector.combotree('tree').tree('getSelected');
                                               planningFolderSelector.next(".combo").attr('title', decodeHtmlAttribute(selectedNode.attributes.title));
                                               me.loadDataIntoColumn(column, selectedPlanningFolderPath).done(function() {
                                               me.initializeDragAndDrop('#planningTable');
                                               });
                                           } else {
                                           // Set pfChanged to false to avoid a server call to save planning column preference
                                                   pfChanged = false;
                                           }
                                       }
                                   },
                                   onHidePanel: function() {
                                       var planningFolderSelector = $j(this);
                                       var column = planningFolderSelector.closest('.table-column');
                                       if(pfSelectedAlready) {
                                           pfSelectedAlready = false;
                                           me.webClient.alert(me.messages['errors.planning.duplicate.folders'], 
                                                   me.messages['error.text']);
                                           
                                           if(prevPfValue) {
                                               // Revert back previous selected node
                                               planningFolderSelector.combo('setValue', prevPfValue);
                                               var planningFolderSelectorTree = planningFolderSelector.combotree('tree');
                                               var prevPfNodeSelector = 'div.tree-node[node-id="'+prevPfValue+'"]';
                                               var prevNode = planningFolderSelectorTree.find(prevPfNodeSelector);
                                               planningFolderSelectorTree.tree('select', prevNode[0]);
                                           } else {
                                               planningFolderSelector.combotree('clear');
                                               column.find('.include-closed').attr('displayClosedArtifacts', 'disabled');
                                           }
                                           planningFolderSelector.combo('setText', prevPfText);
                                           // No need to execute further
                                           return false;
                                       } 
                                       //UnEscape the html encoded for XSS threats.
                                       var actualText = decodeHtmlAttribute(planningFolderSelector.combo('getText'));
                                       planningFolderSelector.combotree('setText', actualText);
                                       if(pfChanged) {                                               
                                           me.saveColumnSelection();
                                           pfChanged = false;
                                       }
                                   },
                                   onShowPanel: function() {
                                       var planningFolderSelector = $j(this);
                                       // Preserve the previous selected values just in case
                                       prevPfText = planningFolderSelector.combo('getText'); 
                                       prevPfValue = planningFolderSelector.combo('getValue');  
                                       me.resizePanel($j(this));
                                   }
            });
            me.setSelectorWidth();
        }
        /**
         * Changes the display closed planning folder status
         * 
         */

        this.changeDisplayClosedArtifactStatus = function(includeClosedSelector, status) {
            if (status) {
                includeClosedSelector.attr('displayClosedArtifacts', 'true');
                includeClosedSelector.attr('title',
                        me.messages['planning.hide.closed.artifacts']);
                includeClosedSelector.find('img').attr('alt', me.messages['planning.hide.closed.artifacts']);
                includeClosedSelector.addClass('btn-selected');
            } else {
                includeClosedSelector.attr('displayClosedArtifacts', 'false');
                includeClosedSelector.attr('title',
                        me.messages['planning.show.closed.artifacts']);
                includeClosedSelector.find('img').attr('alt', me.messages['planning.show.closed.artifacts']);
                includeClosedSelector.removeClass('btn-selected');
            }
        };
        
        /**
         * @param selectedPlanningFolderPath the selected planning folder path.
         * Returns true if the planning folder is already selected.
         */
        this.isPfAlreadySelected = function(selectedPlanningFolderPath) {
            var isSelected = false;
            $j.each(me.pfSelections, function(key, value){                                                                                                      
                if(selectedPlanningFolderPath == value){
                    isSelected = true;
                }
            });
            return isSelected;
        }

        /**
         * Disables the selectors till column data is loaded.
         * 
         * @param selector the selector to disable
         */
        this.disableSelector = function(selector) {
            $j(selector).prop("disabled", true);
        }

        /**
         * Enables the selectors after column data is loaded.
         *
         * @param selector the selector to enable
         */
        this.enableSelector = function(selector) {
            $j(selector).removeAttr("disabled");
        }

        /**
        * Sets up event handlers for the entire input element
        *
        * @param Table element containing planning columns
        */
        this.setUpPlanningFolderSelectionListeners = function(columns) {
	         // Setup the event handlers for entire input element, not just the arrow button
		     
		     columns.each(function(index, column){
                  me.webClient.cloneEventHandlers($j(column).find('.combo-arrow'), $j(column).find('.combo'));
		     });
        }

         function isFrozenPlanningFolder(planningFolderPath) {
           if (me.frozenPlanningFolders) {
             var i = 0;
             for( i = 0; i < me.frozenPlanningFolders.length; i++) {
                 if (planningFolderPath == me.frozenPlanningFolders[i] ||
                     planningFolderPath.indexOf(me.frozenPlanningFolders[i] + ".") == 0) {
                     return true;
                 }
             }
             }
             return false;
         }
        /**
         * Updates the column data.
         *
         * @param the planning folder selector.
         */
        this.updateColumnData = function(planningFolderSelector, hideLoadingIcon) { 
            var selectedPlanningFolderPath = planningFolderSelector.combo('getValue'); 
            var column = planningFolderSelector.closest('.table-column');
            me.loadDataIntoColumn(column, selectedPlanningFolderPath, hideLoadingIcon).done(function() {
                me.initializeDragAndDrop('#planningTable');
                if(!hideLoadingIcon) {
                	me.saveColumnSelection();
                }
            });
        }

        /**
         * Enables drag and drop in the columns of a table.
         *
         * @param parent {jQuery} the element where the drop targets are found
         */
        this.initializeDragAndDrop = function(parentSelector) {
          var parent = $j(parentSelector);
            if(me.permissions['Planning.PlanningAppFolder.admin.rank']) {
                var destinations = parent.find('.item-destination');
                var configuration = this.webClient.getDragAndDropConfiguration(this, me.widgetHeight, '.scroll-area');
                configuration.containment = parentSelector;
                if (destinations && destinations.length > 0) {
                    for (var i = destinations.length - 1; i >= 0; i--) {
                        var planningFolderPath = destinations[i].parentElement.getAttribute("data-id");
                        if (isFrozenPlanningFolder(planningFolderPath)) {
                           destinations.splice(i, 1);
                        }
                    }
                }
                if (destinations) {
                    destinations.sortable(configuration);
                    destinations.sortable({ connectWith: parentSelector + " .item-destination" });
                }
                this.onResize();
            }
        };

        
        /**
         * Enables drag and drop in child container.
         *
         * @param parent {jQuery} the element where the drop targets are found
         */
        this.initializeChildDragAndDrop = function(artifactKey, parentSelector, tableColumn) {

          var parent = $j(parentSelector);
           
            if(me.permissions['Planning.PlanningAppFolder.admin.rank']) {           
                
                var destinations = tableColumn.find('.item-destination-' + artifactKey );
                var configuration = me.webClient.getDragAndDropConfiguration(this, me.widgetHeight, '.scroll-area');
                configuration.containment = parentSelector;
                destinations.sortable(configuration);
                var selectedColumn = destinations.parents('.table-column').attr('id');
                var columns = parent.find('.table-column');
                var columnIds = [];
                for(var i=0; i<columns.length; i++) {
                    var id = $j(columns[i]).attr('id');
                    if(id != selectedColumn) {
                        columnIds.push($j(columns[i]).attr('id'));    
                    }
                }
                var connectClasses = me.getColumnsToConnect(columnIds);
                destinations.sortable({ connectWith: connectClasses });                      
            }
        };
        
        /**
         * Frames the connectWith columns for Child Artifacts.
         * @param columnIds the columnIds to connect with.
         * returns the connectWith columns for sortables.
         */
        this.getColumnsToConnect = function(columnIds) {
            var connectWith = [];
            
            $j.each(columnIds, function(i, val) {
                connectWith.push('#' + val +' .item-destination');                
            });
            return connectWith;
        };
        
        
        /**
         * Saves the current location of the artifact widget.
         *
         * @param artifactWidget {jQuery} the widget to save the location for
         */
        this.rememberLocation = function(artifactWidget) {
           me.artifacts.rememberLocation(artifactWidget);
        };

        /**
         * Handles drop request sanity checks.
         *
         * Used to abort drag and drop events
         *
         * @param event drag event
         * @param ui ui.sortable object containing info about the dragged item
         * @return true if the drop target is valid
         */
        this.isValidDropTarget = function(event, ui) {
           return !me.artifacts.isDroppedToOriginalLocation(ui.item);
        };
        
        /**
         * Handles sortable's change event
         * 
         * @param event Sortable event
         * @ui sortable ui object
         */
        this.handleSortListChange = function(event, ui) {
        	me.artifacts.hideNoResultsMessageIfExists($j(event.target));
        }
        
        /**
         * Handles sortable's out event
         * 
         * @param event Sortable event
         * @ui sortable ui object
         */
        this.handleSortListOut = function(event, ui) {
        	me.artifacts.showNoResultsMessageIfExists($j(event.target));
        }

        /**
         * Handles drop requests for artifact widgets.
         *
         * @param event the drop event
         * @param ui the drop UI, see jQueryUI
         */
        this.handleDropRequest = function(event, ui) {
            this.artifacts.handleDropRequest(ui.item, me.getDataInColumns());
        };

        /**
         * Returns the function that handles.
         *
         * @param event the drop event
         * @param ui the drop UI, see jQueryUI
         */
        this.getUpdatePlanningColumnsFunction = function(artifactArray) {
            me.updatePlanningColumns(artifactArray);
        };

        /**
         * Handles updating the planning columns.
         *
         * @param artifactDetailArray the detail artifacts in all the planning columns.
         */
        this.updatePlanningColumns = function(artifactDetailArray, moveData) {
        	//getting the artifact list
        	var artifactArray = artifactDetailArray[0];
        	//getting the information if each list has been truncated
        	var artifactIsTruncatedArray = artifactDetailArray[1];
            var columnInfoArray = artifactDetailArray[2];
            var columnSelections = me.getDataInColumns().columnSettings;
            for (var idx = 0; idx < artifactArray.length && idx < columnSelections.length; idx++) {
                if (columnSelections[idx].id && columnSelections[idx].id != '') {
                    me.populateColumn(artifactArray[idx], artifactIsTruncatedArray[idx],  columnInfoArray[idx], $j('#column'+(idx+1)), columnSelections[idx].id);
                }
            }
            expandedIds = me.artifacts.expanded;
            focusParentId = moveData.sourceColumnId + '-' + moveData.parentArtifactId;
              if(expandedIds != null) {
                expandedIds = expandedIds.reverse();
                this.expandNodes();
               }

            me.initializeDragAndDrop('#planningTable');

        }

        this.expandNodes = function() {
            isExpanded = true
            $j("." + expandedIds[0]).click();
        }

        /**
         * Displays a loading message in the specified column
         *
         * @param column Column where the loading message should appear
         */
        this.displayLoadingMessage = function(column) {
            var image = '/sf-images/masthead/loadingIndicator.gif';
            var data = [
                        '<div class="loading-content">',
                            '<img class="loading-image" alt="Loading" src="', image, '"/>',
                        '</div>'
                       ];
            column.find('.scroll-area').html(data.join(''));
        };

        /**
         * Fill the column
         *
         * @param column the column to load
         * @param selectedPlanningFolderPath Selected planning folder id
         * @returns the deferred ajax object which loads the data. 
         */
        this.loadDataIntoColumn = function(column, selectedPlanningFolderPath, hideLoadingIcon) {
            var scope = column.find('.widgets-team-tree').scope();
            var selectedTeam = scope.teamComboTreeModel.selected.folderPath;
            var teamText = encodeURIComponent(scope.teamComboTreeModel.selected.text);
            var selectTeamMessage = me.messages['projectboard.team.select.title'];
            var includeClosedSelector = column.find('.include-closed');
            var success = function(response) {
                me.enableSelector(includeClosedSelector);
                if ((response.action !== undefined) && (response.action === "render")) {
                    me.populateColumn(response.values, response.truncated, response.columnInfoData, column, selectedPlanningFolderPath);
                } else if ((response.action !== undefined) && (response.action === "refresh")) {
                    me.webClient.handleLogout();
                } else {
                    if (response.errorCode !== undefined && response.errorCode === "TeamDeleted") {
                        scope.teamComboTreeModel.selected.text = selectTeamMessage;
                        scope.teamComboTreeModel.selected.folderTitle = selectTeamMessage;
                        scope.teamComboTreeModel.selected.folderPath = '';
                    }
                    me.showColumnError(column, response.message);
                }
            };

            var failure = function(response) {
                me.enableSelector(includeClosedSelector);
                me.showColumnError(column, response.message);
            };
                var queryString = '?includeClosedArtifacts='+ includeClosedSelector.attr('displayClosedArtifacts') +
                '&teamId=' + selectedTeam + '&teamText='+teamText;
                //For PF none the plan folder path is project path
                var url = '/sf/projectboards/do/fetchArtifacts/';
                if (selectedPlanningFolderPath == me.projectPathString) {
                    url = url + selectedPlanningFolderPath + queryString;
                } else {
                    url = url + me.projectPathString + '/' + selectedPlanningFolderPath + queryString;
                }

                var ajax = me.webClient.getJSON(url, success, failure, hideLoadingIcon);
                if(!hideLoadingIcon) {
                  me.displayLoadingMessage(column);
                }

                return ajax;
        };
        
        /**
        * Refresh the planning folder hierarchy
        *
        * @param column the column to load
        * @returns the deferred ajax object which refresh the hierarchy. 
        */
        this.refreshPlanningFolderHierarchy = function(column) {
        	var success = function(response) {
                if ((response.action !== undefined) && (response.action === "render")){
                   var columnNumber=column.find(".content-selector").attr("id").match(/\d/g).toString();
                   var planningSelector= $j('#content-selector_'+columnNumber);
                   var selectedPlanningFolderId=planningSelector.combo('getValue');
                   var selectedPlanningFolderTitle=planningSelector.combo('getText');
                   var teamScope = column.find('.widgets-team-tree').scope();
                   teamScope.setupTeamTree(true, true);
                    planningSelector.combotree();
                    if(response.values) {
                    	 planningSelector.combotree('loadData', response.values);
                    }
                    me.setupColumnListners(planningSelector);
                    me.webClient.cloneEventHandlers($j(column).find('.combo-arrow'), $j(column).find('.combotree'));
                    me.pfSelections[column.attr('id')]= '';
                    var folderTree =JSON.stringify(response.values);
                    if(!me.webClient.isKeyExist(folderTree,selectedPlanningFolderId)) {
                    	planningSelector.combo('setText', me.messages['projectboard.planning.select.title']);
                    	planningSelector.next(".combo").attr('title', me.messages['projectboard.planning.select.title']);
                    	me.setTeamIdInColumn(columnNumber-1,'');
                    	if(!me.webClient.isKeyExist(folderTree,selectedPlanningFolderTitle)) {
                    		//If planning folder deleted or closed set to default
                    		var formatedMessage = me.webClient.formatMessage(me.messages['errors.planning.folder.not.exists'], ['<b>'+encodeHtmlAttribute(selectedPlanningFolderTitle)+'</b>']); 
                    		me.showColumnError(column, formatedMessage);
                    	} else {
                    		//If planning folder hiearchy changed. Reset the column and count
                    		column.find('.scroll-area').html('');
                    		me.resetColumnInformationData(column);                  		
                    	}
                    column.find('.include-closed').attr('displayClosedArtifacts', 'disabled');
                    column.find('.refresh-btn').attr('enableButton', 'disabled');
                    column.find('.widgets-team-tree').attr('enableButton', 'disabled');
                    column.find('.add-btn').attr('enableButton', 'disabled');
                    
                } else {  
                    me.setSelectedItemInColumn(columnNumber-1, selectedPlanningFolderId);
                    planningSelector.combo('setValue', selectedPlanningFolderId);
                    var treeNode = $j('div[node-id|="'+selectedPlanningFolderId+'"]')[columnNumber-1];
                    planningSelector.combo('setText', treeNode.textContent);
                   
                }
                     
                } else if ((response.action !== undefined) && (response.action === "refresh")) {
                    me.webClient.handleLogout();
                } else {
                	me.showColumnError(column, response.message);
                }
            };
            var failure = function(response) {
                me.showColumnError(column, response.message);
            };
            var url = '/sf/projectboards/do/fetchPlanningFolderHierarchy/' + me.projectPathString;
            var ajax = me.webClient.getJSON(url, success, failure);

            return ajax;
    };


       /**
        * Saves the user's column selection to the server.
        */
       this.saveColumnSelection = function() {
          me.webClient.
              postJSON('/sf/projectboards/do/saveColumnSettings/' + me.projectPathString, me.getDataInColumns());
       };
       
       /**
        * Loads the Child Artifacts for the given artifact Key.
        *
        * @param artifactKey the artifact to fetch the child for.
        * @param planningFolderPath Selected planning folder path
        * @param container the container that holds artifacts.
        * @returns the deferred ajax object which loads the data. 
        */
       this.loadChildArtifacts = function(artifactKey, planningFolderPath, container, teamId, columnName) {
               var success = function(response) {
                   if (response && response.action === "render") {                                             
                       me.populateArtifacts(response.values, container, columnName);
                   } else if ((response.action !== undefined) && (response.action === "refresh")) {
                       me.webClient.handleLogout();
                   } else {
                       me.webClient.alert(me.messages['errors.planning.fetch.chilren.artifacts'],
                               me.messages['error.text']);
                   }               
               };
                
               var failure = function(response) {
                   me.webClient.alert(me.messages['errors.planning.fetch.chilren.artifacts'],
                           me.messages['error.text']);
               };
                
               var queryString = '?parentArtifactId=' + artifactKey + '&includeClosedArtifacts=' + me.isClosedArtifactsFilterSelected(container.closest('.table-column')) + '&teamId=' + teamId;
               //For PF none the plan folder path is projectpath
               var url = '/sf/projectboards/do/fetchChildrenArtifacts/' ;
               if (planningFolderPath == me.projectPathString) {
                   url = url + planningFolderPath + queryString;
               } else {
                   url = url + me.projectPathString + '/' + planningFolderPath + queryString;
               }
               var ajax = me.webClient.getJSON(url, success, failure);                            
               return ajax;
       };

       /**
        * Fetches the input data from the table columns in JSON.
        * 
        * @returns the data JSON object
        */
       this.getDataInColumns = function() {

           var columns = me.webClient.getAsJquery('#planningBoardColumns').find('.column-header');
           var data = {
               columnSettings : []
           };
           var col;
           var columnData;

             for ( var idx = 0; idx < columns.length; idx++) {
                 col = me.webClient.getAsJquery(columns[idx]);
                 columnData = me.getColumnSetting(col, idx);
                 data.columnSettings.push(columnData);
             }

             return data;
         };

        /**
         * Returns the column setting for the given column as a JSON object.
         *
         * @param column {jQuery} the column
         * @param columnId columnId
         * @returns {JSON} the column settings.
         */
        this.getColumnSetting = function(column, columnId) {
              var planningSelector = column.find(".content-selector");
              var pathString = planningSelector.combo('getValue');
              var titleString = planningSelector.combo('getText');
              var includeClosed = column.find(".include-closed").attr('displayClosedArtifacts');
              var teamId = me.getSelectedTeamInColumn(columnId);
              var columnData = {
                id : pathString,
                text : titleString,
                includeClosedArtifacts : includeClosed,
                teamId : teamId
              };
             return columnData;
        };

        /**
         * Populates a column with the given artifacts.
         *
         * @param artifactList the artifacts of the release
         * @param truncated if the artifacts list has been truncated
         * @param columnInfoData the column information data
         * @param column the column to populate
         * @param selectedPlanningFolderPath Selected planning folder id
         */
        this.populateColumn = function(artifactList, truncated, columnInfoData, column, selectedPlanningFolderPath) {
            
           me.setColumnInformationData(column, columnInfoData);           
           me.populateColumns(artifactList, truncated, column, selectedPlanningFolderPath);
        };

        /**
         * Populates the truncated message if the artifact list has been truncated.
         *
         * @param truncated if the artifacts list has been truncated 
         * @param container the html content
         * @param containerHTML where we have to push the notification
         */
        this.checkTruncatedMessage = function(truncated, container, containerHTML) {
           var truncatedMessage = container.find("#truncatedMsg");
           if (truncatedMessage != undefined) {
                 truncatedMessage.remove();
           }
           if ((truncated != null) && (truncated)) {
        	   containerHTML.push("<div id='truncatedMsg' class='truncateText'>" + me.messages['list.truncated']+" " +me.swimLaneLimit+" "+ me.messages['list.truncated.message']+"</div>")
           }
        }

        /**
         * Clear and refill the given DOM element with JSON data
         *
         * @param artifactList artifacts list as JSON object 
         * @param truncated if the artifacts list has been truncated 
         * @param container Where to put the resultant DOM elements
         * @param selectedPlanningFolderPath Selected planning folder id
         */
        this.populateColumns = function(artifactList, truncated, column, selectedPlanningFolderPath) {
            var columnHTML = [];
            var container = column.find('.scroll-area');
            var columnName = $j(column).attr('id');
            var containerHTML = ['<div class="planningColumn" data-id="', selectedPlanningFolderPath, '">'];
            containerHTML.push('<div class="item-destination">');
            if (artifactList.length == 0){
                //no results found
                containerHTML.push('<span class="item-nodata"> ',me.messages['error.no-results-found'],'</span>');
            }else{
                for ( var i = 0; i < artifactList.length; i++) {
                  var artifact = artifactList[i];
                  columnHTML.push(me.artifacts.createHTMLWidget(artifact, false, columnName));
                }
                containerHTML.push(columnHTML.join(''));
            }
            containerHTML.push('</div>');
            me.checkTruncatedMessage(truncated, container, containerHTML);
            containerHTML.push('</div>');
            container.html(containerHTML.join(''));
        };
        
        
        /**
         * Clear and refill the given DOM element with JSON data
         *
         * @param artifactList artifacts list as JSON object
         * @param container Where to put the resultant DOM elements         
         */
        this.populateArtifacts = function(artifactList, container, columnName) {
            var hideExpander = false;
            if(container.parents('.childContainer').length >= 2){
                hideExpander = true;
            }

            var columnHTML = [];                      
            for ( var i = 0; i < artifactList.length; i++) {
                var artifact = artifactList[i];
                columnHTML.push(me.artifacts.createHTMLWidget(artifact, hideExpander, columnName));                  
            }
            container.html(columnHTML.join(''));
        };

        /**
         * Sets the selected item in the dropdown of a column
         *
         * @param columnNumber the column where the selected item needs to be set
         * @param value {String} the selected item.
         */
        this.setSelectedItemInColumn = function(columnNumber, selectedPlanningFolder) {
                var treeNode = $j('div[node-id|="'+selectedPlanningFolder+'"]')[columnNumber];
                if(treeNode) {
                    $j(treeNode).addClass('tree-node-selected');
                }

        };

        /**
         * Gets the ID of the thing selected in the selector dropdowns.
         *
         * @param column the column to find the selector in
         * @returns the ID of the selected item
         */
        this.getIdFromContentSelector = function(column) {
                var selectedItem = column.find(".content-selector");
                return selectedItem.val();

        };

        /**
         * Creates the HTML string for a swim lane's structure.
         *
         * @param columnNumber the 1-based index of the column
         * @returns {String} the HTML for a column.
         */
        this.getColumnHTML = function(columnNumber) {
                return [ '<div class="column-header ui-corner-top">',
                         '<div class="content-selector-container">',
                         '<div name="content-selector" class="content-selector"',
                         ' id="content-selector_', columnNumber, '" >',
                         '</div>',
                         '<div class="ctf-btn-group planningboard-button-group">',
                         '<div class="refresh-btn btn-group btn" title="',me.messages['planning.refresh'],'" enableButton="disabled"><i class="ctf-refresh"><img src="/sf-images/pngs/refresh.png" alt="',me.messages['planning.refresh'],'" /></i>',
                         '</div>',
                         me.createIncludeClosedHTML(),
                         '<div class="add-btn  btn-group btn" title="',me.messages['planning.add.artifact'], '" enableButton="disabled"><i class="ctf-add add-artifact"><img src="/sf-images/pngs/create.png" alt="',me.messages['planning.add.artifact'],'" /></i>',
                         '</div>',
                         '<div ng-bindable="" data-ng-controller="TeamTreeCtrl"><div class="planningboard-team-combo pull-left"><div enableButton="disabled" class="widgets-combo-tree widgets-team-tree" data-selected="teamComboTreeModel.selected" data-type="\'team\'"',
                             'data-tree-family="teamComboTreeModel.treeFamily" data-on-select="onSelect()">',
                        '</div></div></div></div>',
                         me.createColumnHeaderInformationHtml(),
                         '</div>',
                         '<div class="scroll-area"></div></div>' ].join('');
        };

        /**
         * Create the column header information html.
         * @returns {String} the HTML for a column header information data.
         */
        this.createColumnHeaderInformationHtml = function() {
            
            return [
                    '<div class="column-information-label" title="', me.messages['planning.artifacts.count'], '">',
                    '<span class="card-count">0</span>', 
                    '<span>', ' ', me.messages['planning.column.card'],'</span> ',
                    '</div>',
                    '<div class="column-information-label label-capacity">',
                    '<span class="current-points" title="', me.messages['planning.column.points.current'], '">0</span>',
                    '<span> / </span>',
                    '<span class="points-capacity" title="', me.messages['planning.column.points.capacity'], '">0</span>',
                    '<span>',' ', me.messages['planning.column.points'],'</span> ',
                    '</div>'].join('');
        };

        /**
         * Builds the columns' structure.
         *
         * @param table the {jQuery} table where the columns belong
         * @param columnCount How many columns
         */
        this.buildColumns = function(table, columnCount) {
                for ( var i = 0; i < columnCount; i++) {
                       var selector = '#column' + (i + 1);
                       var container = me.webClient.getAsJquery(selector, table);
                       container.empty();
                       container.append(me.getColumnHTML(i + 1));
                }                
        };
        
        /**
         * Creates the HTML string for a swim lane's table structure.
         *
         * @param columnNumber the 1-based index of the column
         * @returns {String} the HTML for a column.
         */
        
        this.getColumnTableHTML = function(columnNumber) {
        	return [ '<td id="column', columnNumber,'" class="table-column">',
                     '</td>' ].join('');
        };
        
        /**
         * Builds the columns' table structure.
         *
         * @param table the {jQuery} table where the columns belong
         */
        this.buildSwimLanes = function(table) {
     	   var columnHTML = [];
    	   columnHTML.push('<tr id="planningBoardColumns">');
    	   for ( var i = 0; i < me.swimLaneSize; i++) {
        		columnHTML.push(me.getColumnTableHTML(i + 1));
               }
        	columnHTML.push('</tr>');
        	table.append(columnHTML.join(''));
        };

        

        /**
         * Populates the planning table and columns with the given contents
         *
         * @param table  ${jQuery} the table to populate with the selections
         * @param columnSelections the option element values for populating the select boxes.
         * @param onResize function to lay out the table
         */
        this.populateTable = function(tableSelector, columnSelections, onResize) {
              var table = $j(tableSelector)
              me.onResize = onResize;
              me.buildSwimLanes(table);
              me.buildColumns(table, me.swimLaneSize);
              me.addPlanningListeners(table);
              me.setUpPlanningOptions();              
              var requests = [];
              me.setUpModuleLoadCallback(requests, table, columnSelections);
              me.webClient.after(requests).done(function() {
                  me.initializeDragAndDrop(tableSelector);
              });
              
        	  // Resize all panel widths when window is resized
        	  $j(window).resize(function() {
        		  me.setSelectorWidth();
        		  var columns = $j('.table-column');
        		  columns.each(function(index, column){
        			  var columnElement = $j(this);
        			  var planningFolderSelector = columnElement.find('.content-selector');
                      //Check if combo elements are loaded completely before accessing them.
                      if (planningFolderSelector.data("combo")) {
                            me.resizePanel(planningFolderSelector);
                      }
        		  });
        	  });
        };

        /**
         * Sets up callback functions and listeners to be invoked when easy ui modules are loaded
         *
         * @param requests an array of deferred values
         * @param table  ${jQuery} the table to populate with the selections
         * @param columnSelections the option element values for populating the select boxes.
         */
       this.setUpModuleLoadCallback = function(requests, table, columnSelections) {
           //using is a window object property set in easyloader.js
           using(me.easyuiModules, function() {
               var columns = table.find('.table-column');
               me.setUpColumnSelectors(table);
               //Wait for elements to be loaded, so that TeamTreeCtrl is available.
               $j(document).ready(function() {
                   for (var i = 0; i < me.swimLaneSize; i++) {
                       var column = me.webClient.getAsJquery(columns[i]);
                       requests.push(me.restoreSetting(column, columnSelections[i], i));
                   }
               });
           });
       };

       /**
        * Restores the saved settings for a column.
        *
        * @param column {jQuery} the column
        * @param columnSetting {Object{entityId, columnType}} the column setting
        * @param columnNumber the column where the selected item needs to be set
        */
      this.restoreSetting = function(column, selectedPlanningFolder, columnNumber) {
          var planningSelector = column.find(".content-selector");          
          planningSelector.next(".combo-text").attr('aria-label', me.messages['projectboard.planning.select.title']);
          if(selectedPlanningFolder && selectedPlanningFolder.id) {
        	  column.find('.include-closed').attr('displayClosedArtifacts', selectedPlanningFolder.includeClosedArtifacts);
        	  me.changeDisplayClosedArtifactStatus(column.find('.include-closed'), selectedPlanningFolder.includeClosedArtifacts);
              me.setSelectedItemInColumn(columnNumber, selectedPlanningFolder.id);
              me.setTeamIdInColumn(columnNumber, selectedPlanningFolder.teamId);
              planningSelector.combo('setValue', selectedPlanningFolder.id);
              planningSelector.combo('setText', selectedPlanningFolder.text);
           } else {             
              planningSelector.combo('setText', me.messages['projectboard.planning.select.title']);
              planningSelector.next(".combo").attr('title', me.messages['projectboard.planning.select.title']);
          }
          me.loadTeamsIncolumns(columnNumber);
       };

       /**
        * Constructs the html for the include closed artifact element.
        *
        * @return the html for the the include closed artifact element.
        */
       this.createIncludeClosedHTML = function() {
           return [
                    '<div class="include-closed include-closed-btn" title="" displayClosedArtifacts="disabled"  name="includeClosed">',
                    '<img src="/sf-images/icons/show_closed_artifacts.png" alt= "',me.messages['planning.show.closed.artifacts'] ,'"/>',
                    '</div>'
                  ].join('');
       }
       
       /**
        * Displays the include closed artifact input element in the given column.
        *
        * @param column the column in which the element will be created.
        */
       this.displayIncludeClosedArtifacts = function(column) {
    	   if (column.find('.include-closed').attr('displayClosedArtifacts') == "disabled"){
    		   me.changeDisplayClosedArtifactStatus(column.find('.include-closed'), false);
    	   }
       }
       
       /**
        * Enables the refresh button for the given column.
        *
        * @param column the column in which the element will be created.
        */
       
       this.enableButton = function(column) {
    	   var selector = column.find('.btn-group');
    	   if (selector.attr('enableButton')=="disabled"){
    		   selector.attr('enableButton',true);
    		   } 
    	   //Permission check for add button
    	   if(!me.permissions['Tracker.Tracker.create.createArtifact']){
       		    column.find('.add-btn').attr('enableButton',"disabled");
          		}
           var teamSelector = column.find('.widgets-team-tree');
           if (teamSelector.attr('enableButton')=="disabled"){
        	   teamSelector.attr('enableButton',true);
           }
       }
       
       
        /**
         * Shows a message inline in the column when the saved column setting is not
         * available.
         *
         * @param {jQuery} column the column to show the message in.
         * @param {String} message the message to display
         */
        this.showColumnError = function(column, message) {
        if(message){   
		var contentArea = column.find('.scroll-area');

                var errorHTML = ['<div class="errorMessage">'];
                errorHTML.push(message);
                errorHTML.push('</div>');
                contentArea.html(errorHTML.join(''));
		}
        };
        
        /**
         * Updates an existing artifact card with new data.
         *
         * @param artifact the updated artifact data
         * @param widget the existing widget to update.
         * @returns the modified widget card
         */
        this.updateArtifactWidget = function(artifact, widget) {           
           var artifactCard = widget.children('.artifact');

           //highlight edited card
           artifactCard.addClass('artifact-edited');

           //title
           me.webClient.setElementText(artifactCard, '.item-title', artifact.title, artifact.title);
           //priority
           var priority = artifactCard.find('.artifact-priority'); 
           
           priority.attr('class', 'artifact-priority priority' + artifact.priority);           
           priority.attr('title', me.messages['Artifact.priority'] + ' ' + me.messages['artifact.priority.value.' + artifact.priority]);
           
           var priorityDisplayText = artifactCard.find('.item-priority');
           priorityDisplayText.text('('+((artifact.priority && artifact.priority != '0') ? 
                   'P' + artifact.priority : me.messages['artifact.priority.value.' + artifact.priority]) + ')');
           //status
           var status = artifactCard.find('.item-status');
           status.text(artifact.status);
           //version 
           me.webClient.setItemVersion(widget, artifact.version);
           //assignedTo
           me.webClient.setElementText(artifactCard, '.assigned-to', artifact.assignedToText, artifact.assignedToText);
           //constructing avatar url
           var assignedTo = artifactCard.find('.assigned-to');
           var avatarUrl = '<img class="avatar avatar24" src="'+ artifact.avatarUrl +'" alt="AssignedTo"/>';

     	   assignedTo.prepend(avatarUrl);
           //effort
           var effort = artifactCard.find('.item-efforts');
           // When rendering planning board if both points and effort field are disabled then
           // effort html will not exist in artifact card. Append display html
           // if they are enabled subsequently and planning board is not refreshed.
           if (effort.length == 0) {
               artifactCard.find('.item-header').append(me.artifacts.createEffortDisplayHTML(artifact));
           } else {
               effort.attr('title', me.artifacts.createEffortHoverText(artifact));
           }

           if (artifact.estimatedEffort !== undefined &&
               (artifact.points === undefined || (artifact.points == 0 && artifact.estimatedEffort > 0))) {
               artifactCard.find('.effort-unit').text(artifact.trackerUnit);
               artifactCard.find('.effort-value').text(artifact.estimatedEffort);
           } else if (artifact.points !== undefined) {
               artifactCard.find('.effort-unit').text(me.messages['artifact.card.points']);
               artifactCard.find('.effort-value').text(artifact.points);
           }  else if (artifact.points === undefined && artifact.estimatedEffort === undefined) {
               // both points and effort fields are disabled after editor is opened,
               // so remove the field and title
               artifactCard.find('.item-efforts').remove();
           }
           return artifactCard;
        };
        
        /**
         * Update the column widget data.
         * @param artifact the updated artifact data
         * @param widget the existing widget to update.         
         */
        this.updateColumnWidget = function(artifact, widget) {
            var data = widget.closest('.table-column');
            var planningFolderSelector = widget.closest('.table-column').find('.content-selector');            
            var column = planningFolderSelector.closest('.table-column');            
            var includeClosed = column.find(".include-closed").attr('displayClosedArtifacts');
            var teamScope =  widget.closest('.table-column').find('.widgets-team-tree').scope();
            var teamId = teamScope.teamComboTreeModel.selected.folderPath;
            var artifactCard = widget.children('.artifact'); 
            
            if(artifact.statusClass == 'Close') {               
                if(includeClosed == "true") {
                    !artifactCard.hasClass('artifact-closed') ? artifactCard.addClass('artifact-closed') : '';
                } else {
                    if (widget.parents('.item:first').length == 0) {
                        var countHolder = column.find('.card-count');
                        countHolder.text(countHolder.text() - 1);
                    }
                    widget.remove();
                    return;
                }    
            } else if(artifactCard.hasClass('artifact-closed')) {
                artifactCard.removeClass('artifact-closed');
            }
            
            //team check
            var updatedTeam = artifact.selectedTeam;
            if (!updatedTeam) {
                    updatedTeam = 'None';
            }
            if(teamId && teamId !== updatedTeam) {
              if(widget.parents('.item:first').length == 0) {
                var countHolder = column.find('.card-count');
                countHolder.text(countHolder.text() - 1);
              }
              widget.remove();
            }
            //update capacity          
            var queryString = '?teamId='+teamId;
            var url = '/sf/projectboards/do/getColumnInfoData/';
             if (planningFolderSelector.combo('getValue') == me.projectPathString) {
                 url = url + planningFolderSelector.combo('getValue') + queryString;
             } else {
                 url = url + me.projectPathString + '/' + planningFolderSelector.combo('getValue') + queryString;
             }
            
            var success = function(response) {
                if ((response.action !== undefined) && (response.action === "render")) {
                    me.updatePointsCapacity(column, response.columnInfoData);
                }
            };
            
            var failure = function(response) {                  
                me.showColumnError(column, response.message);
            };
            
            var request = me.webClient.getJSON(url, success, failure);
            
        };
        
        /**
         * Method to check if the include closed artifacts filter is seleced
         */
        this.isClosedArtifactsFilterSelected = function(column) {
        	return column.find('.include-closed').attr('displayClosedArtifacts');
        }

        /**
         * Method to get the selector for the giver folder path
         * 
         * @param table the table element
         * @param planningFolderPath the plannning folder path
         * @returns selector element for the path
         */
        
        
        this.getSelectorFromFolderPath =function(table, planningFolderPath){
        	var contentSelectors = table.find('.content-selector');
        	var selector = [];
        	$j.each(contentSelectors, function(key, value){ 
              if(planningFolderPath === $j(value).combo('getValue')){
                selector.push($j(value));
              }
            });
        	return selector;
        }
        
        /**
         * updates the points capacity of a pf column.
         * @param column the column container
         * @param columnInfoData the column information data
         */
        this.updatePointsCapacity = function(column, columnInfoData) {

            column.find('.current-points').text(columnInfoData.currentPoints);
            if(columnInfoData.pointsCapacity == -1) {
                column.find('.points-capacity').text('0');                
            } else {
                column.find('.points-capacity').text(columnInfoData.pointsCapacity);
            }
        };
        
        /**
         * Populates the column information data.
         * @param column the column container. 
         * @param columnInfoData the column information data
         */
        this.setColumnInformationData = function(column, columnInfoData) {            
            column.find('.card-count').text(columnInfoData.cardCount);
            me.updatePointsCapacity(column, columnInfoData);          
        };
        
        /**
         * Resets the column information data.
         * @param column the column container. 
         */
        this.resetColumnInformationData = function(column) {
            
            column.find('.card-count').text('0');
            column.find('.current-points').text('0');
            column.find('.points-capacity').text('0');            
        };
        

	 /**
	 * loading the artifatcs when we changed the team
	 * @param columnId the column Id. 
	 */
	this.loadData = function(columnId) {
		var planningFolderSelector = $j($j('.widgets-team-tree')[columnId])
				.closest('.table-column').find('.content-selector');
		me.updateColumnData(planningFolderSelector);
	};

	/**
	 * @param columnId columnId.
	 * Returns selected teamId in column.
	 */
	this.getSelectedTeamInColumn = function(columnId) {
		var teamId = "";
		var scope = angular.element($j('.widgets-team-tree')[columnId]).scope();
		teamId = scope.teamComboTreeModel.selected.folderPath;
		return teamId;
	}

	/**
	 * sets the teamId to the column
	 * @param columnId the column Id. 
	 * @param teamId the teamId
	 */
	this.setTeamIdInColumn = function(columnId, teamId) {
		var scope = angular.element($j('.widgets-team-tree')[columnId]).scope();
		scope.$apply(function() {
			scope.teamComboTreeModel.selected.folderPath = teamId;
		});
	};

	/**
	 * loads teams into the columns
	 */
	this.loadTeamsIncolumns = function(columnNumber) {
        var scope = angular.element($j('.widgets-team-tree')[columnNumber]).scope();
        scope.$apply(function() {
            scope.setupTeamTree(true, true);
            scope.id = columnNumber;
            scope.loadData = me.loadData;
        });
	};
	
    /**
     * Method to get the columns for the giver folder path
     * 
     * @param table the table element
     * @param planningFolderPath the plannning folder path
     * @returns column element for the path
     */
    this.getColumnsFromFolderPath =function(table, planningFolderPath){
      var coulmns = table.find('.table-column');
      var selector = [];
      $j.each(coulmns, function(key, value){ 
        if(planningFolderPath === $j(value).find('.content-selector').combo('getValue')){
          selector.push($j(value));
        }
      });
      return selector;
    }
}
