// Insert a TOC in the body of the wiki page summarising all H1,H2,H3,H4. 
// Insert TOP of page hyperlinks at each H1,H2,H3,H4
// (idea based on SearchHighlight javascript)
// If multiple headers have same text, anchor will always point to the first one.
var tocHeaderTag = new Array();
var tocEntries   = new Array();
var tocHREF      = new Array();
var tocSize      = 0;

// validateTOC is called after loading the page
function validateTOC() 
{
  //if (!document.createElement) return;

  // find a <div class="insert-toc"> element
  var divArr = document.getElementsByTagName("div");
  if (!divArr) return;
  
  for (i=0; i<divArr.length; i++) 
  {
    if ( divArr[i].className == "insert-toc" )
    {
        showTOC(divArr[i]);
        return; //support one TOC per page
    }
  }  
}


function showTOC(tocCaption)
{
  tocEntries   = new Array();
  tocHeaderTag = new Array();
  tocSize      = 0;

  // put all H1,H2,H3,H4 elements in the tocEntries array
  var pn = tocCaption.parentNode;
  showTocEntries(pn,tocCaption,false);
    
  if (tocSize == 0 ) return;
  
  var nodeBefore    = tocCaption.childNodes[0]; 
  var nodeTOC       = document.createElement("div");   
  nodeTOC.className = "toc";   

  for (var i=0; i<tocSize; i++) 
  {
    var nodeHX      = document.createElement(tocHeaderTag[i]);

    // enclose the toc entries in <a href="#xyz">text</a>
    var nodeAnchor  = document.createElement("a");
    nodeAnchor.setAttribute ("href", "#"+tocHREF[i] );

    var nodeTocText = document.createTextNode(tocEntries[i]);
    nodeAnchor.appendChild(nodeTocText);
    nodeHX.appendChild(nodeAnchor);
    nodeTOC.appendChild(nodeHX);
  }

  var nxt = tocCaption.nextSibling;
  pn.insertBefore(nodeTOC, nxt);

}


function showTocEntries(node,skipCaption,headerFound)
{
  var makeToc = false;
  
  if ( node == skipCaption)  return;
  
  if (  (node.nodeName == "H1") 
     || (node.nodeName == "H2")
     || (node.nodeName == "H3") 
     || (node.nodeName == "H4"))
  {
    headerFound           = true;
    makeToc               = true;
    tocHeaderTag[tocSize] = node.nodeName; 
    tocEntries[tocSize]   = "";  
    tocHREF[tocSize]      = node.getAttribute("id");  
  }

  /* get anchor name of first <A> inside the header */
  //if ( (headerFound) && (node.nodeName == "A") && (tocHREF[tocSize] == "") )
  //{
  //  tocHREF[tocSize] = node.getAttribute("name");
  //}
  
  /* concat all text child text nodes of the header element */
  if ( (headerFound) && (node.nodeType == 3) )
  { 
    tocEntries[tocSize] += node.nodeValue ; 
  }

  if (node.hasChildNodes) /* walk the tree */
  {
    for (var i=0; i<node.childNodes.length; i++) 
    { 
      showTocEntries(node.childNodes[i],skipCaption,headerFound);
    }
  }
  
  if (makeToc)  /* add a TOP OF PAGE link */
  {
    var nodeTOP       = document.createElement("a");
    nodeTOP.innerHTML = "   Back to Top" ;
    nodeTOP.className = "top"; 
    nodeTOP.setAttribute ("href", "#Top");    
    //node.appendChild(nodeTOP);    
    tocSize++;
  }
  	
}

validateTOC();
