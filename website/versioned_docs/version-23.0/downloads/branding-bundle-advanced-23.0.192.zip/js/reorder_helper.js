/**
 * Once the user is done reordering folders, this method should be called to close the pop-up window (if the opener is
 * still available).
 */
function finalizeReordering() {
    if (self.opener != null) {
        if (self.opener.from_screen_type == undefined) {
            self.opener.focus();
            self.opener.location = self.opener.location;
        }
    }
    self.close();
}

/**
 * Get the element that contains the display order value for the given folder id.
 * @param folderId The id of the folder being manipulated.
 * @return The form element that is responsible for keeping track of the given folder's display position.
 */
function getHiddenEl(folderId) {
    var formEl = document.getElementById("reorderObjects");
    for (var i = 0; i < formEl.elements.length; i++) {
        if (formEl.elements[i] == null) {
            continue;
        }

        var elementName = formEl.elements[i].name;
        if (elementName == null) {
            continue;
        }

        if (elementName == "objectPosition(" + folderId + ")") {
            return formEl.elements[i];
        }
    }

    return null;
}

/**
 * Swap the position of the selected folder by some amount.
 * @param  The amount to move the selected folder.
 */
function swapPosition(moveAmount) {
    var folderSelector = document.getElementById("folderSelectList");

    var oldPosition = document.getElementById("folderSelectList").selectedIndex;
    var newPosition = oldPosition + moveAmount;

    var moveGroup = folderSelector.options[oldPosition];
    var displacedGroup = folderSelector.options[newPosition];

    swapOptions(folderSelector, moveGroup, displacedGroup);
}

/**
 * Swap the value and text of two options in the folder select element.
 * @param folderSelector The folder select html element.
 * @param moveGroup The group that is being moved.
 * @param displacedGroup The group that is being displaced.
 */
function swapOptions(folderSelector, moveGroup, displacedGroup) {
    var moveValue = moveGroup.value;
    var moveText = moveGroup.innerHTML;

    var oldPosition = moveGroup.index;
    var newPosition = displacedGroup.index;

    if (oldPosition == newPosition) {
	return;
    }

    //alert(moveText + " - (" + oldPosition + " -> " + newPosition + "). Displaced Text: " + displacedGroup.innerHTML);

    folderSelector.options[oldPosition].value = displacedGroup.value;
    folderSelector.options[oldPosition].innerHTML = displacedGroup.innerHTML;

    folderSelector.options[newPosition].value = moveValue;
    folderSelector.options[newPosition].innerHTML = moveText;

    folderSelector.selectedIndex = newPosition;

    // Now change the display position hidden element to match
    var moveGroupHidden = getHiddenEl(moveGroup.value);
    var displacedGroupHidden = getHiddenEl(displacedGroup.value);

    var oldPos = moveGroupHidden.value;
    moveGroupHidden.value = displacedGroupHidden.value;
    displacedGroupHidden.value = oldPos;
}

/**
 * Move the currently selected folder up a position if it is not already at the top.
 */
function moveUp() {
    if (document.getElementById("folderSelectList").selectedIndex > 0) {
        swapPosition(-1);
    }
}

/**
 * Move the currently selected folder down a position if it is not already at the bottom.
 */
function moveDown() {
    if (document.getElementById("folderSelectList").selectedIndex > -1 && 
    		(document.getElementById("folderSelectList").selectedIndex < document.getElementById("folderSelectList").options.length - 1)) {
        swapPosition(1);
    }
}

/**
 * Alphabetize the rows in the select box.
 */
function alphabetizeRows() {
    var folderSelector = document.getElementById("folderSelectList");

    // First make an array of the folder names
    var nameArray = new Array();
    var allFolders = new Array();
    var optionIdMap = new Array();

    for (var i = 0; i < folderSelector.options.length; i++) {
	var thisName = folderSelector.options[i].text.toLowerCase();
	nameArray[i] = thisName;

	var idArray = allFolders[thisName];
	if (idArray == null) {
	    idArray = new Array();
	}

	var thisId = folderSelector.options[i].value;
	idArray.push(thisId);
	allFolders[thisName] = idArray;

	optionIdMap[thisId] = folderSelector.options[i];
    }

    nameArray.sort();

    for (var i = 0; i < nameArray.length; i++) {
	var thisName = nameArray[i];
	var thisId = allFolders[thisName].pop();

	// Get the element that is moving
	var movingOption = getFolderSelectOption(folderSelector, thisId, i);
	var displacedOption = folderSelector.options[i];

	swapOptions(folderSelector, movingOption, displacedOption);
    }

    folderSelector.selectedIndex = -1;
}

/**
 * Get the option in the folder select that corresponds to the given folder id.
 * @param folderSelector The select element that contains the folder options
 * @param folderId The id of the folder we want the option for.
 * @startingIndex The index to start searching for a match at.
 * @return The select option that represents the given folder id.
 */
function getFolderSelectOption(folderSelector, folderId, startingIndex) {
    for (var i = startingIndex; i < folderSelector.options.length; i++) {
        if (folderSelector.options[i].value == folderId) {
   	    return folderSelector.options[i];
        }
    }
}

/**
 * Swap two adjacent elements into the list. Usually moveAmount can be 1 (down) or -1 (down)
 * It also readjust the scroll bar to keep track of the moved element
 *
 */
function swapListPosition(listControl, moveAmount) {
    var originalSTop = listControl.scrollTop;
    var allSelected = new Array();
    if (moveAmount < 0) {
        for(var i=0;i<listControl.options.length;i++) {
            if(listControl.options[i].selected) {
                allSelected[allSelected.length] = i;
            }
        }
    } else {
        for(var i=listControl.options.length-1;i>=0;i--) {
            if(listControl.options[i].selected) {
                allSelected[allSelected.length] = i;
            }
        }
    }

    for (var j = 0; j < allSelected.length;j++) {
        //Checks if the range of movement is valid
        if ((allSelected[j] > 0 && moveAmount < 0 ) ||
            (allSelected[j] < (listControl.options.length -1) && moveAmount > 0 )) {
            var oldPosition = allSelected[j];
            var newPosition = oldPosition + moveAmount;
	
            var moveGroup = listControl.options[oldPosition];
            var displacedGroup = listControl.options[newPosition];
            displacedGroup.selected = true;
	
            swapListOptions(listControl, moveGroup, displacedGroup);
	    
            //Updates client position
            updateScrollControlPosition(listControl, moveAmount, originalSTop);
        }
    }
	    
}

/**
 * Change id and value of 2 options into a list control
 *
 */

function swapListOptions(listControl, moveGroup, displacedGroup) {
    var moveValue = moveGroup.value;
    var moveText = moveGroup.innerHTML;

    var oldPosition = moveGroup.index;
    var newPosition = displacedGroup.index;

    if (oldPosition == newPosition) {
	return;
    }

    listControl.options[oldPosition].value = displacedGroup.value;
    listControl.options[oldPosition].innerHTML = displacedGroup.innerHTML;
    listControl.options[oldPosition].selected = false;

    listControl.options[newPosition].value = moveValue;
    listControl.options[newPosition].innerHTML = moveText;
    listControl.options[newPosition].selected = true;
}

/**
 * Update the scroll position of a control depending on the selected item of the control.
 *
 */
function updateScrollControlPosition(control, upDown, sTop) {

     var height = control.clientHeight / control.size;
     var selectedPos = control.selectedIndex;
     
     var displacedElements = sTop / height;
     
     var relativePosition = selectedPos - displacedElements;
     if (upDown == 1) {
     	if (relativePosition < control.size) {
	     	control.scrollTop = sTop;
	     	return;
     	} else
     		control.scrollTop = (selectedPos - control.size + 1) * height;
     } else {
     	if (relativePosition > 0) {
	     	control.scrollTop = sTop;
	     	return;
     	} else     
		control.scrollTop = (displacedElements - 1) * height;
     }
     
}