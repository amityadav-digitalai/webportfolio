var imageSrc = '/sf-images/tracker/';
function showHideChart(usePanel) {
    //usePanel value is true for tracker page and false for discussion page.
    var imageState = $j('#showHideChartButton').attr('alt');

	if(imageState =="Hide") {
		$j('#showHideChartButton').attr('alt', 'Show');
		if(usePanel){
            $j('#chartPanel').show();
            $j('#showHideChartButton').html(hideTxt);									
            $j('#showHideChartButton').removeClass('show');
            $j('#showHideChartButton').addClass('hide');
            $j('.hideFooter').addClass("elemVisibility");

           //handle artifact table, the usePanel variable its used to know if it is increase or decrease
           $j(window).trigger("resize");
           }else{
			//Reverse logic for discussion page
            $j('#smallChart').hide();
            $j('#showHideChartButton').html(showTxt);
            $j('#showHideChartButton').removeClass('hide');
            $j('#showHideChartButton').addClass('show');
            $j('.chart-cell-height');
            $j('.hideFooter').removeClass("elemVisibility");
        }
     }
	else {
            $j('#showHideChartButton').attr('alt', 'Hide');
        if(usePanel){
            $j('#chartPanel').hide();
            $j('#showHideChartButton').html(showTxt);
            $j('#showHideChartButton').removeClass('hide');
            $j('#showHideChartButton').addClass('show');
            $j('.chart-cell-height');
            $j('.hideFooter').removeClass("elemVisibility");

            //handle artifact table, the usePanel variable its used to know if it is increase or decrease
            $j(window).trigger("resize");
          }else{
            //Reverse logic for  discussion page
            $j('#smallChart').show();
            $j('#showHideChartButton').html(hideTxt);
            $j('#showHideChartButton').removeClass('show');
            $j('#showHideChartButton').addClass('hide');
            $j('.hideFooter').addClass("elemVisibility");
       }
    }
  }
/**
 * Similar to above but for the places where we use link instead of button for show/hide.
 * @param showText Show Text
 * @param hideText Hide Text
 */
function toggleSummarySection(showText, hideText) {
    $j.getJSON("/ctfrest/tracker/v1/trackers/summary/status", function(data) {
        if (data !== undefined) {
            if(data["trackerSummaryStatus"]) {
                saveTrackerSummaryStatus("false");
                $j('#chartPanel').hide();
                $j('#showHideChartButton').html(showText);
                $j('.hideFooter').removeClass("elemVisibility");

                //handle artifact table, the usePanel variable its used to know if it is increase or decrease
                $j(window).trigger("resize");
            } else {
                saveTrackerSummaryStatus("true");
                $j('#chartPanel').show();
                $j('#showHideChartButton').html(hideText);
                $j('.hideFooter').addClass("elemVisibility");

                //handle artifact table, the usePanel variable its used to know if it is increase or decrease
                $j(window).trigger("resize");
            }
        }
    });
}

/**
 * Save the tracker summary status
 * @param status true/false
 */
function saveTrackerSummaryStatus(status) {
  jQuery.ajax({
      type: 'POST',
      url: '/ctfrest/tracker/v1/trackers/summary/status?trackerSummaryStatus=' + status
     });
}

/**
 * Get the tracker summary status
 * @param status true/false
 */
function onloadTrackerSummaryStatus() {
    $j.getJSON("/ctfrest/tracker/v1/trackers/summary/status", function(data) {
        if (data !== undefined) {
            if(data["trackerSummaryStatus"]) {
                $j('#chartPanel').show();
                $j('#showHideChartButton').html(hideText);
                $j('.hideFooter').addClass("elemVisibility");

                //handle artifact table, the usePanel variable its used to know if it is increase or decrease
                $j(window).trigger("resize");
            }
        }
    });
}
