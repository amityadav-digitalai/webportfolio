
 /* CollabNet TeamForge(r) Enterprise Edition

 * Copyright 2007-2015 CollabNet, Inc.  All rights reserved.
 * http://www.collab.net
 */

var vform, vsubmitValue, modals;
function buildSessionTimeoutDiv(callback) {
  var onselect = '';
  if(!callback)
    callback='';
  if (autoCompleteAction == 'off') {
    onselect = ' onselect="javascript:this.value = \'\'"';
  }
  var session_timeout_div_str = '<div aria-hidden="false" role="dialog" datatabindex="-1" class="modal hide fade in" ' +
  'data-backdrop="static" id="sessionTimeoutDiv" style="display: block;"> <table class="Container">  '+
  '<tbody><tr class="ContainerHeader">  <td><div class="Modal-header"> '+
  '<button aria-hidden="true" onclick="javascript:closeSessionTimeout()" class="close">&#xa0;</button>' +
  '<h3>' + sessionTimeoutHeader + '</h3> <div class="subTitle"><i>' + sessionTimeoutNote + '</i></div></div> </td></tr>'+
  '<tr><td class="ContainerBodyWithPaddedBorder"> <table class="PaddedTable"> <tbody>'+
  '<tr> <td class="ItemDetailName"><div id="loginErrorDiv">&#xa0;</div> '+
  '<div id="loginDiv"><table class="Container"><tbody><tr><td class="ItemDetailName"><label for="username">'+
  sessionTimeoutUsername + '</label></td><td class="ItemDetailValue"> ' +
  '<input type="text" class="inputfield" value="" size="35" id="username" name="username" '+
  'autocomplete="' + autoCompleteAction + '"'+ onselect + '></td> </tr> '+
  '<tr> <td class="ItemDetailName"><label for="passwd">' + sessionTimeoutPassword + '</label></td><td class="ItemDetailValue"> ' +
  '<input type="password" class="inputfield" onkeypress="javascript:loginOnEnter(event,\'' + callback + '\')" value="" size="35" '+
  'autocomplete="' + autoCompleteAction + '" name="password" id="passwd"'+ onselect + '> '+
  '</td> </tr> <tr><td class="ItemDetailValue" colspan="2"><div class="AlignRight">' +
  '<div class="ButtonSpace"></div><div class="Button"><div class="Middle">' +
  '<a href="javascript:iniateLogin(\'' + callback + '\');" id="login_submit">' +sessionTimeoutLoginButton +
  '</a></div></div></div> </td></tr></tbody></table>   </div> </td> </tr> </tbody></table> </td></tr> </tbody></table> </div>';

  return session_timeout_div_str;
}

/**
 * Check if session is alive
 * */
function isSessionActive() {
  var retvalue = true;
  checkValidSession(function(response) {
    var messages = response.substring(response.indexOf('{'));
    var result = jQuery.parseJSON(messages);
    if (result.status === false) {
      retvalue = false;
    }
  });
  return retvalue;
}


function iniateLogin(callback) {
  doLogin(function(response) {
    handleLoginResponse(response.responseText, callback);
  });
}

function doLogin(callback) {
  var username = $j('#username').val();
  var password = $j('#passwd').val();
  var data = { username: username, password: password };
   jQuery.ajax({
    type: 'POST',
    url: '/sf/ctf-api/main/login',
    data: JSON.stringify(data),
    dataType: 'json',
    contentType: 'application/json',
    success: callback,
    error: callback
   });
}

function closeSessionTimeout() {
    $j("#sessionTimeoutDiv").modal('toggle');
    $j("#sessionTimeoutContainer").html('');
    modals.removeClass("modal-backdrop");

}

function handleLoginResponse(responseText, callback) {
  var messages = responseText.substring(responseText.indexOf('{'));
  var result = jQuery.parseJSON(messages);
  switch(result.type) {
  case 'LoginOk':
    $j("#sessionTimeoutDiv").modal('toggle');
    $j("#sessionTimeoutContainer").html('');
    modals.removeClass("modal-backdrop");
    if(!callback || callback == '')
      submitFormHandler(vform, vsubmitValue, result.xsrfToken);
    else
      window[callback]();
    break;
  default:
    $j('#loginErrorDiv').html("<div class='errorMessage'>" + result.extraInformation.message + "</div>");
    $j('#username').focus();
    break;
  }
}

function loginOnEnter(evt, callback) {
  var keyCode = ('which' in evt) ? evt.which : evt.keyCode;
  if (keyCode === 13) {
    iniateLogin(callback);
  }
}

function loginOnEnter(evt, callback) {
  var keyCode = ('which' in evt) ? evt.which : evt.keyCode;
  if (keyCode === 13) {
    iniateLogin(callback);
  }
}

function getCookie(cookieName) {
    return (cookieName = (document.cookie + ';').match(new RegExp(cookieName + '=.*;'))) && cookieName[0].split(/=|;/)[1];
}

function checkValidSession(callback) {
    jQuery.ajax({
        type: 'GET',
        url: '/sf/ctf-api/main/isValidSession',
        async: false,
        dataType: 'html',
        success: callback
    });
}

function checkValidSessionAndSubmit(form, submitValue) {
  vform = form;
  vsubmitValue = submitValue;
  checkValidSession(function(response) {
  var messages = response.substring(response.indexOf('{'));
  var result = jQuery.parseJSON(messages);
  if (result.status === true) {
    submitFormHandler(form, submitValue, result.xsrfToken);
  } else {
    showSessionTimeoutDiv();
  }
 });
}


function openIDPLoginWindow() {
    NewWindow("/sf/sfmain/do/login?RelayState=" + "/oauth/saml/postlogin","SAML Re-Authentication", 800, 400, 'yes');
}

function showSessionTimeoutDiv(callback) {
  if (isSamlIDPEnabled || isSamlLdapIDPEnabled) {
      var retVal = confirm("You have been logged out. Would you like to re-login. ? \n Note: A new pop-up would be opened for re-login");
      if( retVal == true ){
          openIDPLoginWindow();
          return true;
       }
       else{
          return false;
       }
  } else {
    modals = $j(".modal.hide");
    modals.addClass("modal-backdrop");
    $j("#sessionTimeoutContainer").html(buildSessionTimeoutDiv(callback));
    $j("#sessionTimeoutDiv").modal('toggle');
    $j('#username').focus();
  }
}
