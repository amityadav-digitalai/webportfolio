
var imageSrc = '/sf-images/pngs/';
  var foldersOnPage = new Object();
  
  /**
   * show children : go to server and bring back folders data if there are
   * hide children : hide the div, next time won't go to server.
   * **/
  function expandCollapseTreeNode(id, clickeableElement, isLastChild){
	  
	  if($j('#' + id ).is(':visible')) {
		  $j('#' + id ).hide();
		  $j('#' + clickeableElement).attr('src',imageSrc + 'plus.png');  
	  } else {
		  if (foldersOnPage[id] == null) {
		  
			  var checkboxId = clickeableElement.substring(clickeableElement.indexOf("_") + 1, clickeableElement.length);
			  var folderOperation = clickeableElement.substring("expandCollapse_".length, clickeableElement.lastIndexOf("_"));
			  var folderId = clickeableElement.substring(clickeableElement.lastIndexOf("_") + 1, clickeableElement.length);
			  
			  var folderPath = $j("#" + checkboxId).val();
			  getFolders(folderPath, checkboxId, folderOperation, folderId, isLastChild, clickeableElement);
			  foldersOnPage[id] = id;
			  return;
		  }
		  
		  $j('#' + id ).show();
		  $j('#' + clickeableElement).attr('src',imageSrc + 'minus.png');
		  
		  
	  }
	  return false;
  }
  var result;
  var prefix = new Object();
  
  /***
  * get folders from server and add it under its parent
  * @param folderPath the path of the clicked folder
  * @param checkboxId the id of the checkbox that belong to that folder
  * @param folderOperation create, delete, view, edit
  * @param folderId the id of the folder
  * @param parentIsLastChild boolean to know which branch image render
  * @param clickeableElement the id of the cliked img
  **/
  function getFolders(folderPath, checkboxId, folderOperation, folderId, parentIsLastChild, clickeableElement) {
	   
	  var folderUrl = "/sf/rbac/do/editRoleDocumentFolderJSON/" + getProject() + "?folderPath="  + folderPath + "&roleid=" + $j('input[name=roleid]').val();
		
		$j.getJSON(folderUrl, function(data) {
			if (data === undefined) {
		    	  alert(undefinedJSONError);
		        // We had an issue.
		        alert(serverJSONError);
		      } else {
		    	  result = data;
		    	  
		    	  if (result["serverError"] != null) {
		    		  alert(result["serverError"]);
		    		  return;
		    	  }
		    	  
		    	  renderChildrens(result, folderPath, checkboxId, folderOperation, folderId, parentIsLastChild);
		    	  if (result["noChildrens"] == null) {
							$j('#' + clickeableElement).attr('src',imageSrc + 'minus.png');  
				  }	
		      } 
		  });
		
  }
  
  /***
  * render and populate each folder inside the parent
  * @param resultFromServer the json object with the data
  * @param folderPath the path of the clicked folder
  * @param parentCheckboxId the id of the checkbox that belong to the parent folder
  * @param folderOperation create, delete, view, edit
  * @param folderId the id of the folder
  * @param parentIsLastChild boolean to know which branch image render
  **/
  function renderChildrens(resultFromServer, folderPath, parentCheckboxId, folderOperation, folderId, parentIsLastChild) {

	  if (resultFromServer["noChildrens"] != null) {
		  var imgId = "expandCollapse_" + parentCheckboxId;
		  $j('#' + imgId).attr('src',imageSrc + 'white.png');  
		  
		  
		  //if no child remove onclick
		  $j('#' + imgId).removeAttr("onclick");
		  $j('#' + imgId).click(function(){return false;});
		  return;
	  }
	  
	  var titleMap = resultFromServer["foldersTitle"];
	  var checkBoxValueMap = resultFromServer["foldersCheckboxValue"];
	  var idsMap = resultFromServer["foldersId"];
	  var folderOrderArray = resultFromServer["folderOrder"];
	  
	  var size = getObjectSize(resultFromServer["foldersTitle"]);
	  var counter = 0; 
	  $j.each(folderOrderArray, function(i, key) {
		  counter ++;
		  var checkboxId = folderOperation + "_" + resultFromServer["foldersId"][key];
		  var isLastChild = counter == size;
		  var folderTitle = resultFromServer["foldersTitle"][key];
		  var folderPath = key;
		  var checkBoxValue = resultFromServer["foldersCheckboxValue"][key];
		  
		  if (checkBoxValue) {
			  checkBoxValue = "checked=\"checked\"";
		  }else {
			  checkBoxValue = "";
		  }
		  
		  var prefixForFolder = prefix[parentCheckboxId];
		  
		  if (prefixForFolder == null) {
			  
			  if (parentIsLastChild) {
				  prefixForFolder = "<img class=\"BranchDF\" src=\"/sf-images/nanotree/images/white.gif\" alt=\"\">";
			  } else {
				  prefixForFolder = "<img class=\"BranchDF\"  alt=\"\">";
			  }
		  }
		  
		  var child = $j(addFolder(checkboxId, isLastChild, folderTitle, folderPath, checkBoxValue, folderOperation, folderId ,prefixForFolder));
		  
		  if (counter == 1 ) {
			  $j("#" + "childrens_of_" + parentCheckboxId).html("");  
		  }
		  
		  $j("#" + "childrens_of_" + parentCheckboxId).append(child);
		  $j("#" + checkboxId).bind("click", setDeltaValue);
		  $j("#" + "childrens_of_" + parentCheckboxId).show();
		  
		  
	  });
	  
  }

  /**
  * return the size of a json object
  */
  function getObjectSize(object){
	  var count = 0;

	  for (i in object) {
	      if (object.hasOwnProperty(i)) {
	          count++;
	      }
	  }
	  
	  return count;
  }
  
  /**
  * Create the html to render a folder
  **/
  function addFolder(checkboxId, isLastChild, folderTitle, folderPath, checkBoxValue, folderOperation, folderId, parentPrefixForFolder) {
	  var treePrefix;
	  if (!isLastChild) {
		 treePrefix="<img class=\"BranchDF\" src=\"\" alt=\"\">";
	  } else {
		  treePrefix="<img class=\"BranchDF\"  src=\"/sf-images/nanotree/images/white.gif\" alt=\"\">";
	  }
	  
	  treePrefix = parentPrefixForFolder + treePrefix;
	  prefix[checkboxId] = treePrefix;
	  
	  var firstDivId = "div_" + checkboxId;
	  var expandImageId = "expandCollapse_" + checkboxId;
	  var nameOfTheExpandImage = "plus.png";
	  
	  
	  var expandImageElement = "<input type=\"image\" style=\"float:left\" id=\"" +expandImageId + "\" "
 	  + " onclick=\"javascript:expandCollapseTreeNode(\'childrens_of_" + checkboxId + "',"
	  + "\'" + expandImageId + "'," +  isLastChild +");return false;\"" 
	  + "src=\"/sf-images/pngs/" + nameOfTheExpandImage + "\" alt=\"Hide/Show\" />";
	  
	  var folderElement = "<div id=\"" + checkboxId + "_container\">"
	  + "<table id=\"treeBranch\" "
	  + "<tr><td>" 
	  + parentPrefixForFolder 
	  + "</td>"
	  + "<td>" 
	  + "<div id=" + firstDivId + " class=\"editRoleDocumentFolderChildren\">"
	  +	"<div class=\"editRoleDocumentFolderChildRow\">"
	  + expandImageElement
	  + "<div class=\"editRoleDocumentFolderChildrenCheckbox\">"
	  + "<input type=\"checkbox\" id=\"" + checkboxId + "\" onclick=\"toggleButtons(this);\"" 
	  + "value=\"" + getFolderOp(folderOperation) + "__folder__" + folderPath+ "\" name=\"_listItem\" " +  checkBoxValue + "\" class=\"primary-checkbox\">"
      + "<label for=\"" +checkboxId +"\" class=\"custom-label\" >&#xa0;</label>"
	  + "</div>"
	  + "<div class=\"editRoleDocumentFolderLabelRow\">"
      + "<label for=\"" +checkboxId +"\" > " + folderTitle+ "</label>"
      + "</div>"
      + "</div>"
      + "</div>"
   	  +	"</td>"
	  +	"</tr>"
	  +	"</table>"
	  +	"<div id=\"childrens_of_" + checkboxId + "\" style=\"display:none\">"
      + "</div>"
	  + "</div>";
	  
	  return folderElement;
  }
  
  function getFolderOp(folderOperation) {
      if (folderOperation.indexOf("docmanDelete") == 0) {
          return "docman_delete";
      } else if (folderOperation.indexOf("docmanCreate") == 0) {
          return "docman_create";
      } else if (folderOperation.indexOf("docmanView") == 0) {
          return "docman_view";
      } else if (folderOperation.indexOf("docmanEdit") == 0) {
          return "docman_edit";
      } else if (folderOperation.indexOf("docmanFolderDelete") == 0) {
          return "docman_folder_delete";
      } else if (folderOperation.indexOf("docmanFolderCreate") == 0) {
          return "docman_folder_create";
      } else {
          return "docman_folder_edit";
      }
  }
  
  function getProject() {
  	var pathLength = $j('input[name=projectPath]').val().length;
  	return $j('input[name=projectPath]').val().substring(1,pathLength -1);
  }
  
  $j(window).on("load", function(){
		setBindForDocumentDelta();
		appendRoleIdQueryString();
	  });

	  function setBindForDocumentDelta(){
		  $j.each($j("input[name=_listItem]"), function(i, value) {
				$j(value).bind("click", setDeltaValue);
		  });
	  }

	  /*
	   * Appends roleid query string to the editRole form action url
	   */
	  function appendRoleIdQueryString() {
	  	  var roleid = $j('[name=editRole]').find('input[name=roleid]').val();
	  	  if(roleid) {
		  	var editRoleForm = $j('[name=editRole]');
		  	editRoleForm.attr('action', editRoleForm.attr('action') + '?roleid=' + roleid);
	  	  }
	  }

	  /**
	  * for each clicked checkbox add a hidden input to send the value later
	  */
	  function setDeltaValue() {
		  var currentValue = $j(this).is(":checked");
		  var hiddenInputNewValue = $j(this).val() + "__" + currentValue;
	      var previousHiddenInput = $j(this).parent().find("[name=_deltalistItem]");
		  
	      if (previousHiddenInput != null && previousHiddenInput.length > 0) {
			  previousHiddenInput.val(hiddenInputNewValue);
		  }else {
			  var hiddenElement = $j("<input type=\"hidden\" id=\"" + $j(this).val() +"\" value=\"" + hiddenInputNewValue +"\" name=\"_deltalistItem\" />");
			  $j(this).parent().append(hiddenElement);
		  }
	  }
	  
 
