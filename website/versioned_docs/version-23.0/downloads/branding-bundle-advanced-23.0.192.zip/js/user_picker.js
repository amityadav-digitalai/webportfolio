/*
 * CollabNet TeamForge(r) Enterprise Edition

 * Copyright 2015 CollabNet, Inc.  All rights reserved.
 * http://www.collab.net
 */

// Helper function for AngularJs core-user-picker widget which facilitates
// setting data in the parent page and submitting the page.
// Note: This is only used in hybrid pages where the user-picker widget is used.
var UserPicker = (function() {
  "use strict";
  return {
    service: (function() {
      return {
        submit: function(data) {
          //console.log('Data ' + data);
          var formId = data.formId;
          var form = document.getElementById(formId);
          //console.log('Form ' + form);
          if (form == null) {
            form = document.forms[formId];
          }
          if ((form == null) || (form.elements == null) || (form.elements.length == null)) {
            alert("There was an error selecting the user");
            return;
          }
          var element = form.elements[data.elementName];
          //console.log('element ' + element);
          if (data.isMultiple) {
            if (element.type == 'select-multiple') {
              var selectedUsernames = new Array();
              if (data.nobodyIsSelected) {
                //TODO: Add nobody user id to selectedUsernames
              }
              for (var i = 0; i < data.selectedOptions.length; i++) {
                selectedUsernames[selectedOptions[i].key] = true;
              }

              for (var i = 0; i < element.length; i++) {
                var option = element.options[i];
                if (selectedUsernames[option.value] != null) {
                  option.selected = true;
                } else {
                  option.selected = false;
                }
              }
            } else if (element.type == 'text' || element.type == 'hidden') {
              // Set the value to a comma delimited list of userids
              var userNameList = '',
                fullNameList = '';

              if (data.nobodyIsSelected) {
                userNameList = data.nobodyUserData.id;
                fullNameList = data.nobodyUserData.name;//TODO: From bundle
                if (data.selectedOptions && data.selectedOptions.length > 0) {
                  userNameList =  userNameList + data.userNameDelimiter;
                  fullNameList = fullNameList + data.fullNameDelimiter;
                }
              }
              for (var j = 0; j < data.selectedOptions.length; j++) {
                if (j < data.selectedOptions.length - 1) {
                  userNameList = userNameList + data.selectedOptions[j].key + data.userNameDelimiter;
                  fullNameList = fullNameList + data.selectedOptions[j].value + data.fullNameDelimiter;
                } else {
                  userNameList = userNameList + data.selectedOptions[j].key;
                  fullNameList = fullNameList + data.selectedOptions[j].value;
                }
              }
              //console.log('userNameList ' + userNameList);
              //console.log('fullNameList ' + fullNameList);
              var fullNameElement = form.elements[data.fullNamePrefix + element.name];
              element.value = userNameList;
              if (fullNameElement != null && fullNameElement.type == 'text') {
                fullNameElement.value = fullNameList;
                var checkboxElem = form.elements['updateF' + element.name.substring(1)];
                if (typeof checkboxElem != "undefined") {
                  checkboxElem.checked = true;
                }
              }
            }
          } else {
            var selectedUsername;
            var selectedFullName
            var nobodyIsSelected;
            if (data.nobodyIsSelected) {
              selectedUsername = data.nobodyUserData.id;
              selectedFullName = data.nobodyUserData.name; //TODO: From bundle
              nobodyIsSelected = true;
            } else {
              for (var m = 0; i < data.selectedOptions.length; m++) {
                if (m == 0) {
                  selectedUsername = data.selectedOptions[m].key;
                  selectedFullName = data.selectedOptions[m].value;
                  nobodyIsSelected = false;
                }
              }
            }
            if (element.type == 'select-one' && selectedUsername) {
              var addNew = true;
              for (var i = 0; i < element.length; i++) {
                var option = element.options[i];
                if (option.value == selectedUsername) {
                  option.selected = true;
                  addNew = false;
                } else if (nobodyIsSelected && option.value == '') {
                  //the nobody user was selected from the user picker, but there is no matching option value
                  //probably because the option was ''
                  option.selected = true;
                  addNew = false;
                }
              }
              if (addNew) {
                //add a new option node when the value selected from the picker is
                //not found in the existing list of options
                var optionNode = document.createElement("option");
                optionNode.value = selectedUsername;
                optionNode.selected = true;
                optionNode.innerHTML = selectedFullName;
                element.appendChild(optionNode);
              }
            } else if (element.type == 'hidden' || element.type == 'text') {
              var fullNameElement = form.elements[data.fullNamePrefix + element.name];
              if (selectedUsername != null)
                element.value = selectedUsername;
              else
                element.value = "";
              if (fullNameElement != null && selectedFullName != null)
                fullNameElement.value = selectedFullName;
              else
                fullNameElement.value = "";
            }
          }
          if (data.autoSubmit) {
            form.submit();
          }
          return;
        }
      };
    }())
  }
}());
