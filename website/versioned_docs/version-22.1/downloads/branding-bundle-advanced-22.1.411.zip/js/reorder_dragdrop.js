function reorderDragDrop(tableId, formId, fieldId) {
    reorderDragDrop(tableId, formId, fieldId, false, 0);
}

function reorderDragDrop(tableId, formId, fieldId, hasSubstring, substringSize) {
    var jquery = jQuery.noConflict();

    jquery(document).ready(function() {

        var fixHelperModified = function(event, ui) {
            var $children = ui.children();
            var $childrenClone = ui.clone();

            $childrenClone.children().each(function(index) {
                jquery(this).width($children.eq(index).width())
            });

            return $childrenClone;
        };

        var startHelper = function(event, ui) {
            ui.item.data('start_pos', ui.item.index());
        };

        var stopHelper = function(event, ui) {
            var start_pos = ui.item.data('start_pos');

            if (start_pos != ui.item.index()) {
                setButtonState("_SfButton_applychanges", "enabled");
                setButtonState("_SfButton_discardchanges", "enabled");

                var out = ""
                jquery("#" + tableId + " tbody tr").each(function() {
                    var $tr = jquery(this);
                    $tr.removeClass('Dropped');
                    var idVal = $tr.attr("id");

                    if (idVal != undefined) {
                      if (hasSubstring) {
                        out += idVal.substring(substringSize) + ",";
                      } else {
                        out += idVal + ",";
                      }
                    }
                });

                ui.item.addClass("Dropped");
                document.getElementById(formId).elements[fieldId].value = out.substring(0, out.length-1);
            }
        };

        jquery("#" + tableId + " tbody").sortable({
            helper: fixHelperModified,
            start: startHelper,
            stop: stopHelper
        }).disableSelection();

        jquery("#" + tableId + " tbody tr").not('.sortHandle').mousedown(function(event){
            event.stopImmediatePropagation();
        });

    });
}