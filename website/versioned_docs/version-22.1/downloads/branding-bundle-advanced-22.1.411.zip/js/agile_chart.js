(function(window, document, undefined) {

    var agileCharting = {};
    
    var chartContentElementSelector = "#chartContent";

    /**
     * help function for opening the given help topic in a new window
     */
    agileCharting.help = function(chartHelpTopic) {
        var url = "/help" + chartHelpTopic;
        window.open(url, '_blank');
    };
    
    /**
     * Gets the response for  small Release Burndown chart and renders
     */
    agileCharting.smallReleaseBurndownChart = function(contentElement, dataURL, onClickAction) {
        
      jQuery.getJSON(dataURL, function(responseJSON) {
        if (responseJSON == null) {
          return;
        };
        agileCharting.renderSmallReleaseBurndown(contentElement, responseJSON, onClickAction);
      });
    };
    
    /**
     * Renders the small open by priority chart with a given response
     */
    agileCharting.renderSmallReleaseBurndown = function(contentElement, responseJSON, onClickAction) {
      jQuery(contentElement).highcharts({
        chart: {
          type: 'column',
          plotBackgroundColor : null,
          plotShadow : false,
          margin : [ 0, 0, 0, 0 ],
          spacingTop : 0,
          spacingBottom : 0,
          spacingLeft : 0,
          spacingRight : 0,
          plotBorderWidth : 0,
          events : {
            click : onClickAction
          }
        },
        colors: [ {
            linearGradient : { x1 : 0, y1 : 0, x2 : 1, y2 : 0 },
            stops : [ [ 0, '#72aa00' ], [ 1, '#bfd255' ] ]
        }],
        credits: {
          enabled: false
        },
        legend : {
          enabled: false
        },
        title: {
          text: ''
        },
        exporting : {
          enabled: false
        },
        tooltip: {
          enabled: false
        },
        plotOptions : {
          column : {
            size : '100%',
            events : {
                click : onClickAction
            }
          },
          series : {
            point : {
              events : {
                legendItemClick : function() {
                  return false;
                }
              }
            }
          }
        },
        series: [{
          data: responseJSON.counts
        }],
        xAxis: {
          categories: responseJSON.categories,
          title : {
            text : ''
          },
          labels : {
            enabled : false
          }
        },
        yAxis: {
          maxPadding : 0,
          title : {
            text : ''
          },
          labels : {
            enabled : false
          },
          gridLineColor : 'transparent',
          gridLineWidth : 0,
          minorGridLineWidth : 0
        }
      });
    };
    
    /**
     * Renders Release Burndown chart in the given element for the respective planning folder data
     */
    agileCharting.releaseBurndownChart = function(dataURL) {
    
      var contentElement = jQuery(chartContentElementSelector);
    
      jQuery.getJSON(dataURL, function(responseJSON) {
        if (responseJSON == null) {
          return;
        }
        jQuery('#chartTitle').text(responseJSON.labels.title0);
        jQuery('#projectTitle').text(responseJSON.labels.title1);
        jQuery('#pfPath').text(responseJSON.labels.title2);
        jQuery('#title3').text(responseJSON.labels.title3);
        jQuery('#print').text(responseJSON.labels.print);
        jQuery('#close').text(responseJSON.labels.close);
        jQuery('#help').text(responseJSON.labels.help).attr(
          'href',
          "javascript:agileCharting.help('"
              + responseJSON.labels.helpTopic + "');");

        jQuery(contentElement).highcharts({
          chart: {
            type: 'column'
          },
          colors:  [ {
            linearGradient : { x1 : 0, y1 : 0, x2 : 1, y2 : 0 },
            stops : [ [ 0, '#72aa00' ], [ 1, '#bfd255' ] ]
          }],
          credits: {
            enabled: false
          },
          title: {
            text: '<b> <span style="color : #444">' + responseJSON.labels.title0 + '</span></b>',
            useHTML: true
          },
          legend: {
            enabled: false
          },
          exporting : {
            enabled: false
          },
          tooltip: {
            formatter: function() {
              return '<span>'+ responseJSON.labels.startDate + '</span>: <b>' + 
                     this.point.name +
                     '</b><br /><span>'+ responseJSON.labels.points + '</span>: <b>' +
                     this.y + '</b>';
            }
          },
          xAxis: {
            categories: responseJSON.categories,
            title: {
              text: responseJSON.labels.iteration,
              style : chartAxisTitleStyle
            }
          },
          yAxis: {
            title: {
              text: responseJSON.labels.effortUnits,
              style : chartAxisTitleStyle
            }
          },
          plotOptions: {
            column : {
              colorByPoint : true,
              dataLabels : {
                  enabled : true,
                  color : '#444',
                  connectorColor : '#000',
                  formatter : function() {
                      return this.y == 0 ? null : this.y;
                  },
                  y : 3,
                  style : {
                      fontFamily : 'Arial',
                      fontSize : '12px',
                      fontWeight : 'bold'
                  }
              }
            }
          },
          series: [{
            name: responseJSON.labels.iteration,
            data: responseJSON.counts
          }]
        });
      });
    };

    /**
     * Gets the response for  small capacity chart and renders
     */
    agileCharting.smallCapacityChart = function(contentElement, dataURL, onClickAction, reflow) {
        jQuery.getJSON(dataURL, function(responseJSON) {
            if (responseJSON == null) {
                return;
            };
            agileCharting.renderSmallCapacity(contentElement, responseJSON, onClickAction, reflow);
        });
    };

    /**
     * Renders the small capacity chart with a given response
     */
    agileCharting.renderSmallCapacity = function(contentElement, responseJSON, onClickAction, reflow) {
      reflow = reflow == undefined ? true : false;
      jQuery(contentElement).highcharts({
        chart : {
                reflow: reflow,
                type: 'line',
                plotBackgroundColor : null,
                plotShadow : false,
                margin : [ -5, 0, 0, 0 ],
                spacingTop : 0,
                spacingBottom : 0,
                spacingLeft : 0,
                spacingRight : 0,
            events : {
                click : onClickAction
            }
        },
        exporting : {
            enabled : false
        },
        credits : {
            enabled : false
        },
        title : {
            text : ''
        },
        tooltip : {
            enabled : false
        },
        legend : {
            enabled : false
        },
        xAxis : {
            visible: false
        },
        yAxis : {
            showEmpty: false,
            plotLines: [{
                value: 0,
                width: 0,
                height: 0,
                color: '#808080'
            }]
        },
        plotOptions : {
            line : {
                colorByPoint : false,
                events : {
                    click : onClickAction
                }
            },
            series : {
                point : {
                    events : {
                        legendItemClick : onClickAction
                    }
                }
            }
        },
        series : [ {
            lineWidth:40,
              color: '#7194da',
                data: agileCharting.convertNumberToZeros(responseJSON.capacity)
            }, {
            lineWidth:20,
             color: '#ff3333',
                data: agileCharting.convertNumberToZeros(responseJSON.remainingEffort)
            }, {
            lineWidth:10,
             color: '#00cc00',
                data: agileCharting.convertNumberToZeros(responseJSON.estimatedEffort)
        } ]
      });
    }

    /**
     * Renders Capacity chart in the given element for the respective planning folder data
     */
    agileCharting.capacityChart = function(dataURL) {

        var contentElement = jQuery(chartContentElementSelector);

        jQuery.getJSON(dataURL, function(responseJSON) {
            if (responseJSON == null) {
                return;
            }
            jQuery('#chartTitle').text(responseJSON.labels.title0);
            jQuery('#projectTitle').text(responseJSON.labels.title1);
            jQuery('#pfPath').text(responseJSON.labels.title2);
            jQuery('#axis').text(responseJSON.labels.axis);
            jQuery('#axis').css("text-align", "center");
            jQuery('#title3').text(responseJSON.labels.title3);
            jQuery('#print').text(responseJSON.labels.print);
            jQuery('#close').text(responseJSON.labels.close);
            jQuery('#help').text(responseJSON.labels.help).attr(
                'href',
                "javascript:agileCharting.help('" +
                responseJSON.labels.helpTopic + "');");
            jQuery(contentElement).highcharts({
                chart: {
                    type: 'line',
                    plotBackgroundColor: null,
                    plotShadow: false,
                    margin: [100, 0, 0, 0],
                    spacingTop: 0,
                    spacingBottom: 0,
                    spacingLeft: 0,
                    spacingRight: 0,
                },
                exporting: {
                    enabled: false
                },
                credits: {
                    enabled: false
                },
                title: {
                    text: ''
                },
                tooltip: {
                    enabled: false
                },
                legend: {
                    enabled: false
                },
                xAxis: {
                    visible: false
                },
                yAxis: {
                    showEmpty: false,
                    plotLines: [{
                        value: 0,
                        width: 0,
                        height: 0,
                        color: '#808080'
                    }]
                },
                legend: {
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'top',
                    x: -10,
                    y: 50,
                    borderWidth: 0
                },
                tooltip: {
                    formatter: function() {
                            return '<b>' + this.series.name + '</b><br/>' + this.series.options.id;
                    }
                },
                series: [{
                    lineWidth: 40,
                    color: '#7194da',
                    name: responseJSON.labels.labelCapacity,
                    data: agileCharting.convertNumberToZeros(responseJSON.capacity),
                    id: Highcharts.numberFormat(responseJSON.capacity, 0)
                }, {
                    lineWidth: 20,
                    color: '#ff3333',
                    name: responseJSON.labels.labelRemainingEffort,
                    data: agileCharting.convertNumberToZeros(responseJSON.remainingEffort),
                    id: Highcharts.numberFormat(responseJSON.remainingEffort, 0)
                }, {
                    lineWidth: 10,
                    color: '#00cc00',
                    name: responseJSON.labels.labelEstimatedEffort,
                    data: agileCharting.convertNumberToZeros(responseJSON.estimatedEffort),
                    id: Highcharts.numberFormat(responseJSON.estimatedEffort, 0)
                }]
            });
        });
    };

    /**
     * Convert numbers to zeros
     */
    agileCharting.convertNumberToZeros = function(total) {
        var zeros = [];
        for (var i = 0; i < total; i++)  {
            zeros[i] = 0;
        }
        return zeros;
    };

    /**
     * Gets the response for  small Open By Priority chart and renders
     */
    agileCharting.smallOpenByPrioChart = function(contentElement, dataURL,
            onClickAction, reflow) {
        jQuery.getJSON(dataURL, function(responseJSON) {
            if (responseJSON == null) {
                return;
            };
            agileCharting.renderSmallOpenByPriority(contentElement, responseJSON, onClickAction, reflow);
        });
    };
    
    /**
     * Renders the small open by priority chart with a given response
     */
    agileCharting.renderSmallOpenByPriority = function(contentElement, responseJSON, onClickAction, reflow) {
      reflow = reflow == undefined ? true : false;
      jQuery(contentElement).highcharts({
        chart : {
            reflow: reflow,
            type : 'column',
            plotBackgroundColor : null,
            plotShadow : false,
            margin : [ 0, 0, 0, 0 ],
            spacingTop : 0,
            spacingBottom : 0,
            spacingLeft : 0,
            spacingRight : 0,
            plotBorderWidth : 2,
            events : {
                click : onClickAction
            }
        },
        colors : [ priorityGradientColorP1,
                priorityGradientColorP2,
                priorityGradientColorP3,
                priorityGradientColorP4,
                priorityGradientColorP5,
                priorityGradientColorP0 ],
        exporting : {
            enabled : false
        },
        credits : {
            enabled : false
        },
        title : {
            text : ''
        },
        tooltip : {
            enabled : false
        },
        legend : {
            enabled : false
        },
        plotOptions : {
            column : {
                size : '100%',
                colorByPoint : true,
                events : {
                    click : onClickAction
                }
            },
            series : {
                point : {
                    events : {
                        legendItemClick : function() {
                            return false;
                        }
                    }
                }
            }
        },
        series : [ {
            data : responseJSON.counts
        } ],
        xAxis : {
            categories : responseJSON.categories,
            title : {
                text : ''
            },
            labels : {
                enabled : true
            }
        },
        yAxis : {
            maxPadding : 0,
            title : {
                text : ''
            },
            labels : {
                enabled : true
            },
            gridLineColor : 'transparent',
            gridLineWidth : 0,
            minorGridLineWidth : 0
        }
      });
    }

    /**
     * Renders Open By Priority chart in the given element for the respective planning folder data
     */
    agileCharting.openByPrioChart = function(dataURL) {
        
        var contentElement = jQuery(chartContentElementSelector);
        
        jQuery.getJSON(dataURL, function(responseJSON) {
            if (responseJSON == null) {
                return;
            }
            jQuery('#chartTitle').text(responseJSON.labels.title0);
            jQuery('#projectTitle').text(responseJSON.labels.title1);
            jQuery('#pfPath').text(responseJSON.labels.title2);
            jQuery('#title3').text(responseJSON.labels.title3);
            jQuery('#print').text(responseJSON.labels.print);
            jQuery('#close').text(responseJSON.labels.close);
            jQuery('#help').text(responseJSON.labels.help).attr(
                    'href',
                    "javascript:agileCharting.help('"
                            + responseJSON.labels.helpTopic + "');");

            jQuery(contentElement).highcharts({
                chart : {
                    type : 'column',
                    plotBackgroundColor : null,
                    plotBorderWidth : null,
                    plotShadow : false
                },
                colors : [    priorityGradientColorP1,
                                priorityGradientColorP2,
                                priorityGradientColorP3,
                                priorityGradientColorP4,
                                priorityGradientColorP5,
                                priorityGradientColorP0 ],
                exporting : {
                    enabled: false
                },
                credits : {
                    enabled : false
                },
                title : {
                    text : ''
                },
                tooltip : {
                    enabled : false
                },
                legend : {
                    enabled : false
                },
                plotOptions : {
                    column : {
                        colorByPoint : true,
                        dataLabels : {
                            enabled : true,
                            color : '#444',
                            connectorColor : '#000',
                            formatter : function() {
                                return this.y == 0 ? null : this.y;
                            },
                            y : 3,
                            style : {
                                fontFamily : 'Arial',
                                fontSize : '12px',
                                fontWeight : 'bold'
                            }
                        }
                    },
                    series : {
                        point : {
                            events : {
                                legendItemClick : function() {
                                    return false;
                                }
                            }
                        }
                    }
                },
                series : [ {
                    data : responseJSON.counts
                } ],
                xAxis : {
                    categories : responseJSON.categories,
                    title : {
                        text : responseJSON.labels.state,
                        style : chartAxisTitleStyle
                    }
                },
                yAxis : {
                    maxPadding : 0,
                    title : {
                        text : responseJSON.labels.count,
                        style : chartAxisTitleStyle
                    },
                    allowDecimals : false
                }
            });
        });
    };

    /**
     * Renders open by priority chart in pop up for a team
     */
    agileCharting.renderOpenByPriority = function(responseJSON) {
        var contentElement = jQuery(chartContentElementSelector);
        jQuery(contentElement).highcharts({
            chart : {
                type : 'column',
                plotBackgroundColor : null,
                plotBorderWidth : null,
                plotShadow : false
            },
            colors : [
                    priorityGradientColorP1,
                    priorityGradientColorP2,
                    priorityGradientColorP3,
                    priorityGradientColorP4,
                    priorityGradientColorP5,
                    priorityGradientColorP0 
            ],
            exporting : {
                enabled: false
            },
            credits : {
                enabled : false
            },
            title : {
                text : ''
            },
            tooltip : {
                enabled : false
            },
            legend : {
                enabled : false
            },
            plotOptions : {
                column : {
                    colorByPoint : true,
                    dataLabels : {
                        enabled : true,
                        color : '#444',
                        connectorColor : '#000',
                        formatter : function() {
                            return this.y == 0 ? null : this.y;
                        },
                        y : 3,
                        style : {
                            fontFamily : 'Arial',
                            fontSize : '12px',
                            fontWeight : 'bold'
                        }
                    }
                },
                series : {
                    point : {
                        events : {
                            legendItemClick : function() {
                                return false;
                            }
                        }
                    }
                }
            },
            series : [ {
                data : responseJSON.result.openByPrio.counts
            } ],
            xAxis : {
                categories : responseJSON.labels.categories,
                title : {
                    text : responseJSON.labels.state,
                    style : chartAxisTitleStyle
                }
            },
            yAxis : {
                maxPadding : 0,
                title : {
                    text : responseJSON.labels.count,
                    style : chartAxisTitleStyle
                },
                allowDecimals : false
            }
        });
    }
    
    /**
     * Requests data for small Open Vs Closed chart and renders the chart
     */
    agileCharting.smallOpenVsClosedChart = function(contentElement, dataURL, onClickAction, chartWidth, chartHeight) {
        jQuery.getJSON(dataURL, function(responseJSON) {
            if (responseJSON == null) {
                return;
            };
            agileCharting.renderSmallOpenVsClosedChart(contentElement, responseJSON.result, onClickAction, chartWidth, chartHeight);
        });
    };

    /**
     * Renders small Open Vs Closed chart in the given element
     */
    agileCharting.renderSmallOpenVsClosedChart = function(contentElement, result, onClickAction, chartWidth, chartHeight) {
        jQuery(contentElement).highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                width: chartWidth,
                height: chartHeight,
                margin: [0, 0, 0, 0],
                spacingTop: 0,
                spacingBottom: 0,
                spacingLeft: 0,
                spacingRight: 0,
                events: {
                    click: onClickAction
                }
            },
            colors: getPieGradient(["#f84c49", "#669966"]),
            credits: {
                enabled: false
            },
            exporting: {
                enabled: false
            },
            title: {
                text: ''
            },
            tooltip: {
                enabled: false
            },
            plotOptions: {
                pie: {
                    size: '100%',
                    dataLabels: {
                        enabled: false
                    },
                    events: {
                        click: onClickAction
                    }
                }
            },
            series: [{
                type: 'pie',
                data: result
            }]
        });
    }

    /**
     * Renders Open Vs Closed chart in the given element
     */
    agileCharting.renderOpenVsClosedChart = function(contentElement, data) {
        $j(contentElement).highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            colors: getPieGradient(["#f84c49", "#669966"]),
            credits: {
                enabled: false
            },
            legend: {
                itemStyle: {
                    color: '#000000',
                    fontWeight: 'bold',
                    cursor: 'default',
                    fontFamily: 'Arial',
                    fontSize: '11px'
                },
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'top',
                borderWidth: 0,
                itemMarginTop: 5
            },
            title: {
                text: ''
            },
            exporting : {
                enabled: false
            },
            tooltip: {
                enabled: false
            },
            plotOptions: {
                pie: {
                    dataLabels: {
                        enabled: true,
                        color: '#444',
                        connectorColor: '#000',
                        format: '{point.y}',
                        style: {
                            fontFamily: 'Arial',
                            fontSize: '12px',
                            fontWeight: 'bold'
                        }
                    },
                    showInLegend: true
                },
                series: {
                    point: {
                        events: {
                            legendItemClick: function () {
                                return false;
                            }
                        }
                    }
                }
            },
            series: [{
                type: 'pie',
                data: data
            }]
        });
    }

    /**
     * Function to render small burndown chart given a content element and the dataURL for the specific planning folder
     */
    agileCharting.smallBurndownChart = function(contentElement, dataURL,
            onClickAction, reflow) {
        reflow = reflow == undefined ? true : false;
        jQuery.getJSON(dataURL,function(responseJSON) {
            burndownChart.setResponseData(responseJSON);
            if(responseJSON) {
                if (!responseJSON.burndownChartData.errorMessage) {
                    jQuery(contentElement).highcharts({
                        chart : {
                            reflow: reflow,
                            plotBackgroundColor : null,
                            plotShadow : false,
                            margin : [ 0, 0, 0, 0 ],
                            spacingTop : 0,
                            spacingBottom : 0,
                            spacingLeft : 0,
                            spacingRight : 0,
                            events : {
                                click : onClickAction
                            }
                        },
                        title : {
                            text : ''
                        },
                        colors : [
                                priorityGradientColorP0,
                                priorityGradientColorP5,
                                priorityGradientColorP4,
                                priorityGradientColorP3,
                                priorityGradientColorP2,
                                priorityGradientColorP1 ],
                        exporting : {
                            enabled : false
                        },
                        xAxis : {
                            title : {
                                text : ''
                            },
                            labels : {
                                enabled : false
                            },
                            gridLineWidth : 0,
                            minorGridLineWidth : 0,
                            categories : responseJSON.burndownChartData.data.xAxis
                        },
                        yAxis : {
                            labels : {
                                enabled : false
                            },
                            title : {
                                text : ''
                            },
                            lineWidth : 1,
                            gridLineWidth : 0,
                            max: burndownChart.getChartMaxY(responseJSON, true)
                        },
                        credits : {
                            enabled : false
                        },
                        legend : {
                            enabled : false
                        },
                        plotOptions : {
                            column : {
                                stacking : 'normal',
                                dataLabels : {
                                    enabled : false
                                },
                                pointPadding : 0.01,
                                groupPadding : 0.01,
                                borderWidth : 0,
                                events : {
                                    click : onClickAction
                                }
                            },
                            line : {
                                events : {
                                    click : onClickAction
                                },
                                marker : {
                                    enabled : false,
                                    states : {
                                        hover : {
                                            enabled : false
                                        }
                                    }
                                }
                            }
                        },
                        tooltip : {
                            enabled : false
                        },
                        series : burndownChart.getSeriesData()
                    });
                } else {
                    return;
                }
            } else {
                return;
            }
        });
    };
    
    /**
     * chart axis title style
     */
    var chartAxisTitleStyle = {
        fontFamily : 'Arial',
        fontSize : '11px',
        fontWeight : 'bold',
        color : '#444'
    };
    
    /**
     * priority column gradient
     */
    var priorityPerShapeGradient = {
        x1 : 0,
        y1 : 0,
        x2 : 1,
        y2 : 0
    };

    var priorityGradientColorP1 = {
        linearGradient : priorityPerShapeGradient,
        stops : [ [ 0, '#cd3e3c' ], [ 1, '#f84e4b' ] ]
    };

    var priorityGradientColorP2 = {
        linearGradient : priorityPerShapeGradient,
        stops : [ [ 0, '#d2612e' ], [ 1, '#fe9c70' ] ]
    };

    var priorityGradientColorP3 = {
        linearGradient : priorityPerShapeGradient,
        stops : [ [ 0, '#d18322' ], [ 1, '#ffbb67' ] ]
    };

    var priorityGradientColorP4 = {
        linearGradient : priorityPerShapeGradient,
        stops : [ [ 0, '#c99a51' ], [ 1, '#f8ce8f' ] ]
    };

    var priorityGradientColorP5 = {
        linearGradient : priorityPerShapeGradient,
        stops : [ [ 0, '#cec040' ], [ 1, '#f2eba3' ] ]
    };

    var priorityGradientColorP0 = {
        linearGradient : priorityPerShapeGradient,
        stops : [ [ 0, '#bbbbbb' ], [ 1, '#f2efef' ] ]
    };
    
    /**
     * Burndown chart specific code
     */
    var burndownChart = {
        
        // set server response for future use based on options selected 
        setResponseData : function(responseData){
            burndownChart.responseData = responseData;
        },
        
        getSelectedViewMode : function() {
            var selectedValue = jQuery("input:radio[name=viewMode]:checked").val();
                        if (!selectedValue) {
                            selectedValue = burndownChart.responseData.burndownChartData.preference.viewMode;
                            jQuery("input[name=viewMode]:radio[value=" + selectedValue + "]").prop('checked', true);
                        }
                        return selectedValue;
        },
        
        getSelectedEffortUnitsMultiplier : function() {
            var selectedMultiplier = jQuery("#viewMode_effortUnits").val();
            // If value is not available then use 1 as default value
            return ((selectedMultiplier) ? selectedMultiplier : 1);
        },
            
        /**
         * Populate available effort units
         */
        populateEffortUnits : function() {
            
            var effortUnitsSelectElement = jQuery('#viewMode_effortUnits');
            
            effortUnitsSelectElement.find('option').remove();
            jQuery.each(burndownChart.responseData.burndownChartData.data.effortUnit, function(key, effortUnit) {
                
                var optionElement = jQuery("<option></option>")
                 .attr("value",effortUnit.multiplier)
                 .text(effortUnit.name);
                
                if(effortUnit.name ==     burndownChart.responseData.burndownChartData.preference.effortUnit) {
                    optionElement.attr('selected', 'selected');
                }
                
                effortUnitsSelectElement.append(optionElement); 
            });
        },
        
        /**
         * Function to register burndown chart options change listeners
         */
        registerBurndownChartEventLIstners : function() {
            
            // Effort units change listener
            jQuery('#viewMode_effortUnits').change(burndownChart.changeEffortUnit);
            
            // View mode change listener
            jQuery("input[name=viewMode]:radio").change(burndownChart.changeViewMode);
        },
        
        /**
         * View mode change listener to modify the burndown chart based on the selected mode.
         * Implementation simply invokes redrawChart
         */
        changeViewMode : function() {
            var chartYaxis = jQuery(chartContentElementSelector).highcharts().yAxis[0];
            
            // Change y-max value
            chartYaxis.setExtremes(chartYaxis.min,
                    burndownChart.getChartMaxY(burndownChart.responseData, false), false);
            
            burndownChart.redrawChart();
        },
        
        /**
         * Function gets the data to populate base don the selected user preferences and then
         * redraws the chart
         */
        redrawChart : function() {
            
            var seriesToUpdate = burndownChart.getSeriesData();
            
            var chart = jQuery(chartContentElementSelector).highcharts();
            
            while (chart.series.length) {
                chart.series[0].remove(false);
            }
            
            jQuery.each(seriesToUpdate, function(index, data){
                chart.addSeries(data, false);
            });
            
            // apply y-axis label
            chart.yAxis[0].setTitle({
                text: burndownChart.getYAxisTitle()
            }, false);

            
            chart.redraw();
        },
        
        
        /**
         * Function to get the title based on the view mode
         */
        getYAxisTitle : function() {
            var yAxisLabels = burndownChart.responseData.burndownChartData.label.yAxis;
            if("effort" === burndownChart.getSelectedViewMode()) {
                return yAxisLabels.effort;
            } else {
                return yAxisLabels.points;
            }
        },

        
        /**
         * Effort units change listener for burndown chart. Implementation
         * changes viewMode to effort and then invokes redrawChart
         */
        changeEffortUnit : function() {
            // Change selection to to effort option
            jQuery("input[name=viewMode]:radio[value=effort]").prop('checked', true);
            
            // Change y axis max value
            var chartYaxis = jQuery(chartContentElementSelector).highcharts().yAxis[0];
            
            chartYaxis.setExtremes(chartYaxis.min,
                    burndownChart.getChartMaxY(burndownChart.responseData, false));
            
            // redraw the chart
            burndownChart.redrawChart();
        },
        
        /**
         * Given an array of effort units, implemntation returns an array reflecting the user
         * selected effort units. 
         */
        getSeriesDataInSelectedEffortUnits : function(dataArray) {
            var selectedEffortUnitsMultiplier = burndownChart.getSelectedEffortUnitsMultiplier();

            var modifiedDataArray = [];
            jQuery.each(dataArray, function(index, value){
                modifiedDataArray[index] = ((value) && (value > 0)) ? (value/selectedEffortUnitsMultiplier) : value;
            });
            return modifiedDataArray;
        },
        
        /**
         * Utility method that returns a column object for highcharts series
         */
        getColumnObject : function(label, dataArray, legendIndex, pfStartDateMills, chunkSize) {
            return {
                name : label,
                type : 'column',
                data : dataArray,
                legendIndex: legendIndex
            }
        },
        
        /**
         * Function returns data based on the view mode and the effort units
         */
        getSeriesData : function() {
            
            var selectedViewMode = burndownChart.getSelectedViewMode();
            var yAxisData = burndownChart.responseData.burndownChartData.data.yAxis;
            var xAxisData = burndownChart.responseData.burndownChartData.data.xAxis;
            
            if ("effort" === selectedViewMode) {
                var effortLabels = burndownChart.responseData.burndownChartData.label.effort;
                return [
                        burndownChart.getColumnObject(effortLabels.p0, burndownChart.getSeriesDataInSelectedEffortUnits(yAxisData.effort.p0), 6),
                        burndownChart.getColumnObject(effortLabels.p5, burndownChart.getSeriesDataInSelectedEffortUnits(yAxisData.effort.p5), 5),
                        burndownChart.getColumnObject(effortLabels.p4, burndownChart.getSeriesDataInSelectedEffortUnits(yAxisData.effort.p4), 4),
                        burndownChart.getColumnObject(effortLabels.p3, burndownChart.getSeriesDataInSelectedEffortUnits(yAxisData.effort.p3), 3),
                        burndownChart.getColumnObject(effortLabels.p2, burndownChart.getSeriesDataInSelectedEffortUnits(yAxisData.effort.p2), 2),
                        burndownChart.getColumnObject(effortLabels.p1, burndownChart.getSeriesDataInSelectedEffortUnits(yAxisData.effort.p1), 1),
                        {
                            name : burndownChart.responseData.burndownChartData.label.estEffort,
                            color : '#33CC33',
                            type : 'line',
                            data : burndownChart.getSeriesDataInSelectedEffortUnits(yAxisData.estEffort),
                            legendIndex: 8
                        },
                        {
                            name : burndownChart.responseData.burndownChartData.label.velocityTrend,
                            color : '#0055DD',
                            type : 'line',
                            data : burndownChart.getSeriesDataInSelectedEffortUnits(yAxisData.velocity.effort),
                            legendIndex: 7
                        } ];
            } else { 
                // points data
                var pointsLabels = burndownChart.responseData.burndownChartData.label.points;
                return [
                        burndownChart.getColumnObject(pointsLabels.p0, yAxisData.points.p0, 6),
                        burndownChart.getColumnObject(pointsLabels.p5, yAxisData.points.p5, 5),
                        burndownChart.getColumnObject(pointsLabels.p4, yAxisData.points.p4, 4),
                        burndownChart.getColumnObject(pointsLabels.p3, yAxisData.points.p3, 3),
                        burndownChart.getColumnObject(pointsLabels.p2, yAxisData.points.p2, 2),
                        burndownChart.getColumnObject(pointsLabels.p1, yAxisData.points.p1, 1),
                        {
                            name : burndownChart.responseData.burndownChartData.label.velocityTrend,
                            color : '#0055DD',
                            type : 'line',
                            data : yAxisData.velocity.points,
                            legendIndex: 7
                        } ];
            }
        },
        
        /**
         * Function to format the tooltip for burndown chart
         */
        tooltipFormatter : function() {
            var seriesName = this.series.name;
            switch (seriesName) {
            case burndownChart.responseData.burndownChartData.label.estEffort:
            case burndownChart.responseData.burndownChartData.label.velocityTrend:
                return this.series.name + '<br>' + this.x
                        + '<br>' + this.y;
                break;
            default:
                return this.series.name
                        + '<br>' + this.x
                        + '<br>' + this.y
                        + ' (' + ((this.y/this.point.stackTotal)*100).toFixed(1)
                        + '%)<br><i>total: </i>' + this.point.stackTotal;
            }
        },
        
        /**
         * Function to render basic labels whether the pf data is valid or pf data is not available i.e. no start date etc. 
         */
        renderBasicLabels : function() {
            jQuery('#chartTitle').text(    burndownChart.responseData.burndownChartData.label.chart);
            jQuery('#projectTitle').text(burndownChart.responseData.burndownChartData.data.projectTitle);
            jQuery('#pfPath').text(burndownChart.responseData.burndownChartData.data.pfPath);
            jQuery('#title3').text(burndownChart.responseData.burndownChartData.data.timestamp);
            jQuery('#print').text(burndownChart.responseData.burndownChartData.label.print);
            jQuery('#close').text(burndownChart.responseData.burndownChartData.label.close);
            jQuery('#help').text(burndownChart.responseData.burndownChartData.label.help)
                    .attr('href', "javascript:agileCharting.help('"
                                    + burndownChart.responseData.burndownChartData.data.helpTopic    + "');");
        },
        
        /**
         * Function to get the max limit of y-axis.
         */
        getChartMaxY : function(responseJson, isSmallBurnDown) {
            var max = 0;
            var yAxisDataArrays;
            var viewMode = burndownChart.getSelectedViewMode();
            if ("effort" === viewMode) {
                yAxisDataArrays = responseJson.burndownChartData.data.yAxis.effort;
            } else {
                yAxisDataArrays = responseJson.burndownChartData.data.yAxis.points;
            }
            jQuery.each(responseJson.burndownChartData.data.xAxis, function(i){
                if ("effort" === viewMode && responseJson.burndownChartData.data.yAxis.estEffort[i] != null) {
                    max = Math.max(max, parseInt(responseJson.burndownChartData.data.yAxis.estEffort[i]));
                } else if ("points" === viewMode && responseJson.burndownChartData.data.yAxis.velocity.points[i] != null) {
                    max = Math.max(max, parseInt(responseJson.burndownChartData.data.yAxis.velocity.points[i]));
                    }
                max = Math.max(max,
                          (parseInt(yAxisDataArrays.p0[i]) + parseInt(yAxisDataArrays.p1[i]) +
                                  parseInt(yAxisDataArrays.p2[i]) + parseInt(yAxisDataArrays.p3[i]) +
                                  parseInt(yAxisDataArrays.p4[i]) + parseInt(yAxisDataArrays.p5[i])));
            });
            // Apply multiplier value if the view mode is effort
            if((!isSmallBurnDown) && ("effort" === viewMode)) {
                return Math.ceil(max/burndownChart.getSelectedEffortUnitsMultiplier());
            }
            return max;
        }
    }
    
    /**
     * Function to render burndown chart given a content element and the dataURL for the specific planning folder
     */
    agileCharting.burndownChart = function(dataURL) {
        
        var contentElement = jQuery(chartContentElementSelector);
        
        jQuery.getJSON(dataURL,function(responseJSON) {
            
            burndownChart.setResponseData(responseJSON);
            
            if(responseJSON) {
                
                burndownChart.renderBasicLabels();
                
                if (responseJSON.burndownChartData.errorMessage) {
                    jQuery("#chartViewModeRow").hide();
                    jQuery("#chartHeader").show();
                    jQuery("#chartContent").addClass("chartContentError");
                    jQuery(contentElement).html(responseJSON.burndownChartData.errorMessage);
                    
                } else {
                    jQuery('#viewModeLabel').text(responseJSON.burndownChartData.label.viewMode.label);
                    jQuery('#viewMode_effortLabel').text(responseJSON.burndownChartData.label.viewMode.effort);
                    jQuery('#viewMode_pointsLabel').text(responseJSON.burndownChartData.label.viewMode.points);
                    
                    //populate effort units available
                    var effortUnitsSelectEle = jQuery('#viewMode_effortUnits');
                    burndownChart.populateEffortUnits(effortUnitsSelectEle, responseJSON);
                    
                    // register event listeners
                    burndownChart.registerBurndownChartEventLIstners();
                    
                    jQuery(contentElement).highcharts({
                        colors : [
                                priorityGradientColorP0,
                                priorityGradientColorP5,
                                priorityGradientColorP4,
                                priorityGradientColorP3,
                                priorityGradientColorP2,
                                priorityGradientColorP1 ],
                        exporting : {
                            enabled : false
                        },
                        title : {
                            text : ''
                        },
                        xAxis : {
                            title : {
                                text : responseJSON.burndownChartData.label.xAxis
                            },
                            labels : {
                                rotation : 45,
                                align : 'left'
                            },
                            categories: responseJSON.burndownChartData.data.xAxis
                        },
                        yAxis : {
                            title : {
                                text : burndownChart.getYAxisTitle()
                            },
                            max: burndownChart.getChartMaxY(responseJSON, false)
                        },
                        credits : {
                            enabled : false
                        },
                        legend : {
                            align : 'right',
                            verticalAlign : 'top',
                            layout : 'vertical',
                            floating : false,
                            borderWidth : 0,
                            shadow : false,
                            itemMarginTop : 5,
                            itemMarginBottom : 5
                        },
                        plotOptions : {
                            column : {
                                stacking : 'normal',
                                dataLabels : {
                                    enabled : false
                                },
                                pointPadding : 0.01,
                                groupPadding : 0.01
                            },
                            line : {
                                marker : {
                                    enabled : false
                                }
                            }
                        },
                        tooltip : {
                            formatter : burndownChart.tooltipFormatter
                        },
                        series : burndownChart.getSeriesData()
                    });
                    
                    jQuery("#chartHeader").show();
                }
            } else {
                return;
            }
        });
    };

    // export agileCharting
    window.agileCharting = agileCharting;

})(window, document);
