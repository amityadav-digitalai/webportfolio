var file_index = -1;
var duplicateAlert = false;
var prohibitedFileTypesAlert = false;
var exceededFileSizeAlert = false;
var removedFileIndices = new Array();
var prohibitedFileTypes = new Array();
var prohibitedAlertText;
var artifactMaxFileUploadSize;
var fileNames = new Array();

function getFileSize(fileSize) {
	var fileNotation = " MB";
        var fileSizeStr = +(fileSize/1024/1024).toFixed(2);
        if (fileSizeStr < 1) {
            fileSizeStr = +(fileSize/1024).toFixed(2);
	    fileNotation = " KB";
            if (fileSizeStr < 1) {
                fileSizeStr = fileSize;
		fileNotation = " Bytes"
            }
        }
        return "(" + fileSizeStr + fileNotation + ")";
}

function inArrayCaseInsensitive(givenValue, givenArray){
    //Iterates over an array of items to return the index of the first item that matches the provided val ('needle') in a case-insensitive way.  Returns -1 if no match found.
    var defaultResult = -1;
    var result = defaultResult;
    $j.each(givenArray, function(index, value) {
        if (result == defaultResult && value.toLowerCase() == givenValue.toLowerCase()) {
            result = index;
        }
    });
    return result;
}

var $j = jQuery.noConflict();
  $j(document).ready(function() {
  'use strict'
   prohibitedAlertText = document.getElementById('prohibitedFileTypes');
   prohibitedFileTypes = prohibitedAlertText.value.split(",");
   artifactMaxFileUploadSize = document.getElementById('artifactMaxFileUploadSize').value;
    function triggerCallback(e, callback) {
      if(!callback || typeof callback !== 'function') {
        return;
      }
      var files;
      if(e.originalEvent.dataTransfer) {
        files = e.originalEvent.dataTransfer.files;
      } else if(e.target) {
        files = e.target.files;
      }
      callback.call(null, files);
    }

    function makeDroppable(callback) {
      var label = document.createElement('label');
      label.setAttribute('for', 'fileElement');
      label.setAttribute('class', 'sr-only');
      label.innerHTML="FileElement";
      var input = document.createElement('input');
      var ele = document.getElementById('fileDragDropSection');
      var browseSection = document.getElementById('browseSection');
      var browseFiles = document.getElementById('browseFiles');
      var dropText = document.createTextNode('Drop Files here to Attach');
      input.setAttribute('type', 'file');
      input.setAttribute('multiple', true);
      input.setAttribute('id', 'fileElement');
      input.style.display = 'none';
      ele.appendChild(label);
      ele.appendChild(input);

       $j(document).on('change','#fileElement',{}, function(e) {
            triggerCallback(e, callback);
        });

        $j(document).on('dragover','.contentArea, #popupContent', {}, function(e){
            e.preventDefault();
            e.stopPropagation();
            document.getElementById("drag-drop-overlay").style.display = "block";
        });

        $j(document).on('dragleave','.contentArea, #popupContent', {}, function(e){
            e.preventDefault();
            e.stopPropagation();
            setTimeout(leaveAction,1000);
        });

        $j(document).on('drop','.contentArea, #popupContent', {}, function(e){
          e.preventDefault();
          e.stopPropagation();
          document.getElementById("drag-drop-overlay").style.display = "";
          triggerCallback(e, callback);

        });

        $j(document).on('click','.browseButton', {},function(e){
          input.click();
          input.value= null;
        });
    }

    function removeFile(file_index,fileName) {
    	var fileInfoElement = document.getElementById('fileListSection');
        var fileListElement = document.getElementById('fileInfo-'+file_index);
        fileInfoElement.removeChild(fileListElement);
        removedFileIndices.push(file_index);
        fileName = unescape(fileName);
        var fileNames_index = $j.inArray(fileName,fileNames);
        if (fileNames_index > -1) {
            fileNames.splice(fileNames_index, 1);
        }
    }

    function removeRetainedFile(file_id,fileName) {
        	var fileInfoElement = document.getElementById('fileListSection');
            var fileListElement = document.getElementById(file_id);
            fileInfoElement.removeChild(fileListElement);
            var fileNames_index = $j.inArray(fileName,fileNames);
            if (fileNames_index > -1) {
                fileNames.splice(fileNames_index, 1);
            }
            deletedFiles.push(file_id);
        }
    
    function leaveAction() {
       document.getElementById("drag-drop-overlay").style.display="";
    }

    window.makeDroppable = makeDroppable;
    window.removeFile = removeFile;
    window.leaveAction = leaveAction;
    window.removeRetainedFile = removeRetainedFile;
  });


$j(document).ready(function() {
  'use strict'
    makeDroppable(function(files) {
      var fileInfo = document.querySelector('.fileInfoList');
      for(var i = 0; i < files.length; i++) {

        file_index++;
        attachedFilesFormData.push(files[i]);

        // set filesize notattion for smaller files in KB

	var fileSizeStr = getFileSize(files[i].size);

        // prevent duplicate file attachments and build the file list element

        var fileIndex = $j.inArray(files[i].name, fileNames);
        if (fileIndex > -1) {
            removedFileIndices.push(file_index);
            duplicateAlert = true;
            continue;
        }

        //prevent prohibited file types
          var fileExt = files[i].name.slice((files[i].name.lastIndexOf(".") - 1 >>> 0) + 2);
          var fileExtIndex = inArrayCaseInsensitive(fileExt, prohibitedFileTypes);
          if (fileExtIndex > -1) {
              removedFileIndices.push(file_index);
              prohibitedFileTypesAlert = true;
              continue;
          }


        //filesize > max exclude files from uploading
         if((files[i].size/1024/1024) > artifactMaxFileUploadSize) {
            removedFileIndices.push(file_index);
            exceededFileSizeAlert = true;
            continue;
        }

        var file_name=files[i].name;
        fileNames.push(file_name);
        var listElement= '<li class="attachmentData" id="fileInfo-'+file_index+'">'+files[i].name+'&nbsp;<span style="font-size: 12px;">'+fileSizeStr+'</span><a style="padding: 0px 5px;" onclick="removeFile('+file_index+','+'\''+escape(file_name)+'\''+')"><i class="fa fa-trash-o" style="color: #3dade0;font-size: 12px;"></i><span class="sr-only">Delete</span></a></li>'
        fileInfo.innerHTML += listElement;
      }

      if(duplicateAlert && prohibitedFileTypesAlert && exceededFileSizeAlert) {
        alert(DUPLICATE_FILE + ";" + PROHIBITED_FILE_TYPES + ";"+EXCEEDED_FILE_LIMIT);
      } else if (duplicateAlert && prohibitedFileTypesAlert){
        alert(DUPLICATE_FILE + ";" + PROHIBITED_FILE_TYPES);
      } else if (prohibitedFileTypesAlert && exceededFileSizeAlert) {
        alert(PROHIBITED_FILE_TYPES + ";" + EXCEEDED_FILE_LIMIT);
      } else if (duplicateAlert && exceededFileSizeAlert) {
        alert(DUPLICATE_FILE + ";" + EXCEEDED_FILE_LIMIT);
      } else if (duplicateAlert){
        alert(DUPLICATE_FILE);
      } else if (prohibitedFileTypesAlert) {
        alert(PROHIBITED_FILE_TYPES);
      } else if (exceededFileSizeAlert) {
        alert(EXCEEDED_FILE_LIMIT);
      }
      duplicateAlert = false;
      prohibitedFileTypesAlert = false;
      exceededFileSizeAlert = false;
    });
  });


