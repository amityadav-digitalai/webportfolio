/*
 * The Reform library provides a solid set of functions for encoding output for
 * the most common context targets in web applications (e.g. HTML, XML, JavaScript, etc).
 * The library also takes a conservative view of what are allowable characters
 * based on historical vulnerabilities, and current injection techniques.
 * 
 * The Library is an extension of http://code.google.com/p/reform/ 
 */


 /**
 * [in, optional] A default value to use (will be encoded) if string is
 *  null. If default is not specified then an empty string will be used
 *  instead.
 *  
 *  @param str [in] String to encode. If string is null then default is used.
 *  @param def [in, optional] A default value to use (will be encoded) if
 *   string is null. If default is not specified then an empty
 *   string will be used instead.
 *  @return Returns an HTML encoded string.
 */
function encodeHtml($str, $default)
{
	if($str == null || $str.length == 0)
	{
		$str = ($default == null ? '' : $default);
	}
	
	$out = '';
	$len = $str.length;
	
	// Allow: a-z A-Z 0-9 SPACE , .
	// Allow (dec): 97-122 65-90 48-57 32 44 46
	
	for($cnt = 0; $cnt < $len; $cnt++)
	{
		$c = $str.charCodeAt($cnt);
		if( ($c >= 97 && $c <= 122) ||
			($c >= 65 && $c <= 90 ) ||
			($c >= 48 && $c <= 57 ) ||
			$c == 32 || $c == 44 || $c == 46 )
		{
			$out += $str.charAt($cnt);
		}
		else
		{
			$out += '&#' + $c + ';';
		}
	}
	
	return $out;
}

 /**
 * The HtmlAttributeEncode function takes in a string and performs HTML
 *  encoding using the &#NN; style encoding where NN is the decimal number of
 *  the character. The encoding style is the same for both Unicode and non
 *  Unicode characters. The HtmlAttributeEncode function differs from
 *  HtmlEncode function due to a more restrictive encoding policy which
 *  includes the SPACE character. This is to prevent vulnerabilities caused
 *  by failure to wrap the HTML attribute in quotation marks.
 *  
 * @param str [in] String to encode. If string is null then default is used.
 * @param def [in, optional] A default value to use (will be encoded) if
 *  string is null. If default is not specified then an empty
 *  string will be used instead.
 * @return Returns an HTML encoded string.
 */
function encodeHtmlAttribute($str, $default)
{
	if($str == null || $str.length == 0)
	{
		$str = ($default == null ? '' : $default);
	}
	
	$out = '';
	$len = $str.length;
	
	// Allow: a-z A-Z 0-9
	// Allow (dec): 97-122 65-90 48-57
	
	for($cnt = 0; $cnt < $len; $cnt++)
	{
		$c = $str.charCodeAt($cnt);
		if( ($c >= 97 && $c <= 122) ||
			($c >= 65 && $c <= 90 ) ||
			($c >= 48 && $c <= 57 ) )
		{
			$out += $str.charAt($cnt);
		}
		else
		{
			$out += '&#' + $c + ';';
		}
	}
	
	return $out;
}

/**
 * The HtmlAttributeDecode function takes in a string and performs HTML
 *  decoding using the &#NN; style decoding where NN is the decimal number of
 *  the character. 
 *  
 * @param str [in] String to decode.
 *  string is null. then an empty string will be used instead.
 * @return Returns an HTML decoded string.
 */

function decodeHtmlAttribute($str)
{
    if($str == null || $str.length == 0)
    {
        $str = '';
    }
    
    // look for numerical entities &#34;
    $arr=$str.match(/&#[0-9]{1,5};/g);
    
    // if no matches found in string then skip
    if($arr!=null){
        for(var x=0;x<$arr.length;x++){
            $m = $arr[x];
            $c = +$m.substring(2,$m.length-1); //get numeric part which is reference to unicode character
            // if its a valid number we can decode
            if($c >= -32768 && $c <= 65535){
                // decode every single match within string
                $str = $str.replace($m, String.fromCharCode($c));
            }else{
                $str = $str.replace($m, ""); //invalid so replace with nada
            }
        }           
    }
    
    return $str;
}

var hD="0123456789ABCDEF";
function d2h(d)
{
	var h = hD.substr(d&15,1);
	while(d>15)
	{
		d>>=4;
		h=hD.substr(d&15,1)+h;
	}
	
	return h;
}

 /**
 * The JsString function creates a literal JavaScript string. This means the
 *  output from this function is actually wrapped in quotation marks. Encoded
 *  characters are encoded using the \xNN and \\uNNNN syntax where the ‘u’
 *  indicates a UCS-2 encoded Unicode character and NN/NNNN is the hex number
 *  of the encoded character.
 *  
 * @param str [in] String to encode.
 * @param def [in, optional] A default value to use (will be encoded) if
 *  string is null. If default is not specified then an empty
 *  string will be used instead.
 * @return Returns a JavaScript string literal with encoded characters.
 */
function encodeJsString($str, $default)
{
	if($str == null || $str.length == 0)
	{
		$str = ($default == null ? '' : $default);
		
		if($str == null || $str.length == 0)
		{
			return '\'\'';
		}
	}
	
	$out = '';
	$len = $str.length;
	
	// Allow: a-z A-Z 0-9 SPACE , .
	// Allow (dec): 97-122 65-90 48-57 32 44 46
	
	for($cnt = 0; $cnt < $len; $cnt++)
	{
		$c = $str.charCodeAt($cnt);
		if( ($c >= 97 && $c <= 122) ||
			($c >= 65 && $c <= 90 ) ||
			($c >= 48 && $c <= 57 ) ||
			$c == 32 || $c == 44 || $c == 46 )
		{
			$out += $str.charAt($cnt);
		}
		else if( $c <= 127 )
		{
			$hex = d2h($c);
			if( $hex.length < 2 )
			{
				'0' + $hex;
			}
			
			$out += '\\x' + $hex;
		}
		else
		{
			$hex = d2h($c);
			while( $hex.length < 4 )
			{
				$hex = '0' + $hex;
			}
			
			$out += '\\u' + $hex;
		}
	}
	
	return $out;
}
// end
