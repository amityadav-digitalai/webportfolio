if (typeof CTF == "undefined" || !CTF) {
  var CTF = {};
}

function initCTF() {
  // some older browsers are slower when it comes to dom manipulation, so avoid certain display features for them
  var jqBrowser = jQuery.browser;
  CTF.domLiteOnly = jqBrowser.msie && (jqBrowser.version == "7.0" || jqBrowser.version == "6.0");
}

function cleanupRows() {
  if (!CTF.domLiteOnly) {
    $j("#RepositoryList tr.treeview:visible").each(function(index) {
      if (index % 2 == 0) {
        $j(this).removeClass("EvenRow").addClass("OddRow");
      } else {
        $j(this).removeClass("OddRow").addClass("EvenRow");
      }
    }); 
  }
}

function expandNodeTreeView(folderPath, rowId) {
  var imgId = "img_" + rowId.substring(4);
  var image = document.getElementById(imgId);
  image.onclick = function() {
    collapseNodeTreeView(folderPath, rowId);
  };
  image.src = image.src.replace("plus", "minus");
  $j('tr[id^="' + rowId + '_' + '"]').show();
  addNodeToCookie(rowId, folderPath);
  cleanupRows();
}

function collapseNodeTreeView(folderPath, rowId) {
  var imgId = "img_" + rowId.substring(4);
  var image = document.getElementById(imgId);
  image.onclick = function() {
    expandNodeTreeView(folderPath, rowId);
  };
  image.src = image.src.replace("minus", "plus");
  // Remove the children
  $j('tr[id^="' + rowId + '_' + '"]').hide();
  removeNodeFromCookie(rowId, folderPath);
  cleanupRows();
}

var expandedNodes = new Array();
var nodesInited = false;

function initTreeNodes(folderPath) {
  nodesInited = true;
  initCTF();
  var allNodes = $j("#RepositoryList tr.treeview");
  var cookieValues = readCookie(folderPath);
  if (cookieValues === null) {
      var i = 0;
      allNodes.each(function(index) {
        var id = $j(this).attr("id");
	if ($j("#img_" + id.substring(4)).length > 0) {
          expandedNodes[id] = true;
        }
      });
    return;
  }
  var nodeIds = cookieValues.split("&");
  for (var i = 0; i < nodeIds.length; i++) {
    expandedNodes[nodeIds[i]] = true;
  }
	  
  allNodes.each(function(index) {
    var id = $j(this).attr("id");
    if (!expandedNodes[id] && $j("#img_" + id.substring(4)).length > 0) {
    	collapseNodeTreeView(folderPath, id);
    }
  });
}

function addNodeToCookie(id, folderPath) {
  if (!nodesInited) {
    initTreeNodes(folderPath);
  }
  expandedNodes[id] = true;
  storeReplicaCookie(expandedNodes, folderPath);
}

function removeNodeFromCookie(id, folderPath) {
  if (!nodesInited) {
    initTreeNodes(folderPath);
  }
  var node;
  for (node in expandedNodes) {
    if (node.indexOf(id) == 0) {
      delete expandedNodes[node];
    }
  }
  storeReplicaCookie(expandedNodes, folderPath);
}

function isNodeExpanded(id, folderPath) {
  if (!nodesInited) {
    initTreeNodes(folderPath);
  }
  return expandedNodes[id];
}

function storeReplicaCookie(nodes, folderPath) {
  var expirationDate = new Date();
  expirationDate.setDate(expirationDate.getDate() + 1);
  var cookieValue = [];
  var node;
  for (node in nodes) {
    cookieValue.push(node);
  }
  document.cookie = folderPath + "=" + cookieValue.join("&") + ";expires="
      + expirationDate.toGMTString() + ";path=/sf";
}

function readCookie(name) {
  var nameEQ = name + "=";
  var ca = document.cookie.split(';');
  for ( var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) === ' ') {
      c = c.substring(1, c.length);
    }
    if (c.indexOf(nameEQ) == 0) {
      return c.substring(nameEQ.length, c.length);
    }
  }
  return null;
}
