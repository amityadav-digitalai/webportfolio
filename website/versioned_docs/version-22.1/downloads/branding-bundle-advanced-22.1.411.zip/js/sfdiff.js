  if (typeof artfCmntPartNo == "undefined" || !artfCmntPartNo) {
    var artfCmntPartNo = {};
  }

  var _SF_TEXT_DIFF;
  var _SF_TEXT_SIDE_BY_SIDE;
  var _SF_TEXT_HIDE;

  function setAuditTrailDiffMessage(message) {
      _SF_TEXT_DIFF = message;
  }
  function setAuditTrailSideBySideMessage(message) {
      _SF_TEXT_SIDE_BY_SIDE = message;
  }
  function setAuditTrailHideMessage(message) {
      _SF_TEXT_HIDE = message;
  }

  function shrinkComment(elem, id, maxTextSize) {
      var descriptionPart = $j("#" + elem).text().substring(0, maxTextSize);
      $j("#" + elem).text(descriptionPart);
      $j("#" + elem + "_viewLess").hide();
      $j("#" + elem + "_viewMore").show();
      // reset part number to restart "View More"
      artfCmntPartNo[id] = 1;
  }
  
  function getCommentData(elem, id, path, objId) {
      if (artfCmntPartNo[id] == undefined) {
          artfCmntPartNo[id] = 1;
      }
      artfCmntPartNo[id] += 1;
      $j.getJSON("/sf/tracker/do/viewArtifactCommentJSON/" + path + "/" + objId + "?cmntId=" + id + "&partNo=" + artfCmntPartNo[id], function(data) {
          $j("#" + elem).append(data.descriptionPart);
          if (data.endOfString) {
              $j("#" + elem + "_viewMore").hide();
              $j("#" + elem + "_viewLess").show();
          }
      });
  }
  
  function quoteReply(commentId) {
    var commentEl = document.getElementsByClassName("commentQuote")[0];
    if (commentEl) {
      commentEl.focus();
      insertStr = "> " + jQuery("#" + commentId).text().replace(/\n/g, "\n> ");
      startPos = commentEl.selectionStart;
      endPos = commentEl.selectionEnd;
      if ((startPos >= 0) && (endPos >= 0)) {
          // Firefox and Netscape
          commentEl.value = commentEl.value.substring(0, startPos) + insertStr +
                        commentEl.value.substring(endPos, commentEl.value.length);
      } else if (document.selection) {
          // IE
          selection = document.selection.createRange();
          selection.text = insertStr;
      } else {
          // no cursor in the textarea
          commentEl.value += "\n" + insertStr;
      }
      window.location.hash="commentLabel";
      var scope = angular.element(commentEl).scope();      
          scope.content = commentEl.value;
    }
  }

  // code to show/hide field changes as diffs or side-by-side
  var textValues = {};
  var diffActions = [];

  /**
   * Replaces newline chars with <br/> instead
   * @param text text to replace
   * @return processed text
   */
  function nl2br(text){
    if (text == null) {
      return text;
    }

    // %0A => Line Feed, %0D => Carriage return
    var nlchar = null;
    text = escape(text);
    if(text.indexOf('%0D%0A') > -1){
      nlchar = /%0D%0A/g ;
    }else if(text.indexOf('%0A') > -1){
      nlchar = /%0A/g ;
    }else if(text.indexOf('%0D') > -1){
      nlchar = /%0D/g ;
    }

    if (nlchar == null) {
      return unescape(text);
    } else {
      return unescape(text.replace(nlchar,'<br />'));
    }
  }

  function initializeDiffActions() {
      //alert("initializeDiffActions() diffACtions: {" + diffActions + "}");
      for( var i=0; i < diffActions.length; i++) {
          var diffAction = diffActions[i];
          //alert("diffAction[0]:[" + diffAction[0] + "], diffAction[1]:[" + diffAction[1] + "]");
          showDelta(diffAction[0], diffAction[1]);
      }
  }

  function showDelta(commentId, state) {
            //alert("show delta.. commentId: " + commentId + " state: " + state);
            var diffEltId = commentId + "_diff";
            var sideEltId = commentId + "_side";
            if (state == 'hide') {
                hideElt(diffEltId);
                hideElt(sideEltId);
            } else if (state == 'diff') {
                doDiff(diffEltId, commentId);
                showElt(diffEltId, "block");
                hideElt(sideEltId);
            } else if (state == 'side') {
                doSideBySide(sideEltId, commentId);
                hideElt(diffEltId);
                showElt(sideEltId, "block");
            } 
            displayDeltaToggle(commentId, state);
            return false;
        }

        function showElt(eltId, displayType) {
            var elt = document.getElementById(eltId);
            if (elt != null) {
                elt.style.display=displayType;
            }
        }

        function hideElt(eltId) {
            var elt = document.getElementById(eltId);
            if (elt != null) {
                elt.style.display="none";
            }
        }

        function doDiff(eltId, commentId) {
            var contentsElt = document.getElementById(eltId + "_contents");
            if (contentsElt != null) {
                var from = textValues[commentId+"_from"];
                var to = textValues[commentId+"_to"];

                if (from != null && to != null) {
                    // diffs library in wiki.js
                	// text values should be decoded before finding diff between 2 texts.
                    var diffs = diff_main(decodeURIComponent(from), decodeURIComponent(to));
                    diff_cleanup_semantic(diffs);
                    var result = diff_prettyhtml(diffs);
                    contentsElt.innerHTML = result;
                } else {
                    contentsElt.innerHTML = "";
                }
            }
        }

        function doSideBySide(eltId, commentId) {
           var from = textValues[commentId+"_from_linkified"];
           if (from == null || from == '') {
               from = textValues[commentId+"_from"];
           }
           var to = textValues[commentId+"_to_linkified"];
           if (to == null || to == '') {
               to = textValues[commentId+"_to"];
           }

           if (jQuery.browser.msie) {
             // ie's innerHTML doesn't handle \n chars correctly
             from = nl2br(from);
             to = nl2br(to);
           }

           if (from == null || from == "") {
               from = " &nbsp; ";
           }
           if (to == null || to == "") {
               to = " &nbsp; ";
           }
           var fromElt = document.getElementById(eltId + "_from");
           var toElt = document.getElementById(eltId + "_to");
           if (fromElt != null && toElt != null) {
              fromElt.innerHTML = decodeURIComponent(from);
              toElt.innerHTML = decodeURIComponent(to);
           } else {
              fromElt.innerHTML = "oops from";
              toElt.innerHTML = "oops too";
           }
        }

        function displayDeltaToggle(commentId, state) {
           var toggleElt = document.getElementById(commentId + "_delta_toggle");
           var  showDiffLink =
               "<a href='' onclick=\"showDelta('" + commentId + "', 'diff'); return false;\">";
           var  showSideLink =
               "<a href='' onclick=\"showDelta('" + commentId + "', 'side'); return false;\">";
           var  hideLink =
               "<a href='' onclick=\"showDelta('" + commentId + "', 'hide'); return false;\">";
           var deltaHTML;
           if (state == 'hide') {
               deltaHTML = "<span class='difftoggle'>" + showDiffLink + _SF_TEXT_DIFF + "</a></span>" +
                " | <span class='sidetoggle'>" + showSideLink + _SF_TEXT_SIDE_BY_SIDE + "</a></span>";
           } else if (state == 'diff') {
               deltaHTML = "<span class='difftoggle'><strong>" + _SF_TEXT_DIFF + "</strong></span> | <span class='sidetoggle'>" + showSideLink + _SF_TEXT_SIDE_BY_SIDE +
                "</a></span> |<span class='hidetoggle'> " + hideLink + _SF_TEXT_HIDE + "</a></span>";
           } else if (state == 'side') {
               deltaHTML = "<span class='difftoggle'>" + showDiffLink + _SF_TEXT_DIFF + "</a></span> | " +
                           "<span class='sidetoggle'><strong>" + _SF_TEXT_SIDE_BY_SIDE + "</strong></span> | <span class='hidetoggle'>" +
                           hideLink + _SF_TEXT_HIDE +"</a></span>";
            }
            toggleElt.innerHTML = deltaHTML;
        }
