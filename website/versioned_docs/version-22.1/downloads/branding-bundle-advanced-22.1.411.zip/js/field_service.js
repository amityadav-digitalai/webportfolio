/*
 * CollabNet TeamForge(r)
 * Copyright 2007-2010 CollabNet, Inc.  All rights reserved.
 * http://www.collab.net
 */

var _MOVE_UP = "Move Up";
var _MOVE_DOWN = "Move Down";
var _VALUE_CLASSES = new Array();
var _USE_VALUE_CLASSES = false;
var _USE_HIERARCHICAL_VALUES = false;
var _HIERARCHICAL_PARENT_FIELD_VALUES = [];
var _MASS_UPDATE_MAGIC_VALUE = '85ae5b04dd0a666efad8633d142a4635';
var _IS_STATUS_FIELD = false;

function setMoveUpText(moveUpText) {
    _MOVE_UP = moveUpText;
}

function setMoveDownText(moveDownText) {
    _MOVE_DOWN = moveDownText;
}

function addAvailableValueClass(valueClass, valueClassDisplayValue) {
    _VALUE_CLASSES[valueClass] = valueClassDisplayValue;
}

function enableValueClasses() {
    _USE_VALUE_CLASSES = true;
}

function disableValueClasses() {
    _USE_VALUE_CLASSES = false;
}

function enableHierarchicalValues() {
	_USE_HIERARCHICAL_VALUES = true;
}

function disableHierarchicalValues() {
	_USE_HIERARCHICAL_VALUES= false;
}

function enableStatusField() {
    _IS_STATUS_FIELD = true;
}

function setParentFieldValues(values, reset) {
	_HIERARCHICAL_PARENT_FIELD_VALUES = values;
  if (reset) {
    $j(".fvr_select").each( function(i) {
      this.innerHTML = "";
      for (var i = 0; i < _HIERARCHICAL_PARENT_FIELD_VALUES.length; ++i) {
    	var value = _HIERARCHICAL_PARENT_FIELD_VALUES[i];
        if (value["visible"] === undefined || value["visible"] === true) {
          var hierarchicalSelectOptionEl = document.createElement("option");
          hierarchicalSelectOptionEl.setAttribute("value",value["id"]);
          var hierarchicalSelectOptionValueEl = document.createTextNode(value["name"]);
          hierarchicalSelectOptionEl.appendChild(hierarchicalSelectOptionValueEl);
          this.appendChild(hierarchicalSelectOptionEl);
        }
      }
    });
  }
}

var _NONE_ROW_ENABLED = true;
function disableNoneRow() {
    _NONE_ROW_ENABLED = false;
}

function isNoneRowEnabled() {
    return _NONE_ROW_ENABLED;
}

var _SF_FORM_ID = "";
function setFormId(formId) {
    _SF_FORM_ID = formId;
}

function getFormId() {
    return _SF_FORM_ID;
}


var _NONE_MESSAGE = "None";

var _INCONSISTENCY_MESSAGE = "Error loading the field information.";

var _UNCHANGED_FIELD_VALUE = "Unchanged";

if (_FIELD_HIERARCHY_INCONSISTENT_MESSAGE == undefined) {
  var _FIELD_HIERARCHY_INCONSISTENT_MESSAGE = "This value is not allowed because it conflicts with the value selected in its parent field"
}

/**
 * Generate the warning message span that will be used to indicate that a field is currently in invalid state.
 * @param elemId the id for the message
 * @param parentFieldName the name of the parent field
 *
 */
function generateInvalidStateWarning(elemId, parentFieldName) {
  $j("#" + elemId).remove();
  return '<span class="artifactFieldError" id="'+elemId+'"><div class="error-label">'+_FIELD_HIERARCHY_INCONSISTENT_MESSAGE + ', ' + parentFieldName + '.</div></span>';
}

if (typeof CTF == "undefined" || !CTF) {
  var CTF = {};
}

function checkCTFinitialization() {
  if (typeof CTF.fromParentToChild == "undefined" || !CTF.fromParentToChild) {
    CTF.fromParentToChild = {};
  }
  if (typeof CTF.fromChildToParent == "undefined" || !CTF.fromChildToParent) {
      CTF.fromChildToParent = {};
    }
  if (typeof CTF.allFields == "undefined" || !CTF.allFields) {
        // this is a lookup map where [fieldId][fieldValueValue] = fieldValueId
        CTF.allFields = {};
      }
}


function setInconsistencyMessage(message) {
	  _INCONSISTENCY_MESSAGE = message;
}

function setNoneMessage(message) {
    _NONE_MESSAGE = message;
}

function setUnchangedValue(unchangedValue) {
    _UNCHANGED_FIELD_VALUE = unchangedValue;
}

/**
 * Register a field value id in a lookup map. This way given a field id and field value, you can look up field value id.
 * @param fieldId field id
 * @param fieldValueValue field value
 * @param fieldValueId field value id
 */
function registerFieldValue(fieldId, fieldValueValue, fieldValueId) {
    checkCTFinitialization();
    if (typeof CTF.allFields[fieldId] == "undefined" || !CTF.allFields[fieldId]) {
      CTF.allFields[fieldId] = {};
    }
    CTF.allFields[fieldId][fieldValueValue] = fieldValueId;
}

/**
 * When a value is not consistent with the current field hierarchal mapping, an inconsistency warning message appears.
 * If that value has been removed due to new loading of values after change to the parent, this warning/binding
 * should no longer apply.
 * @param fieldId the field id
 */
function unbindAndRemoveWarning(fieldId) {
  var warningId = "invalid_" + fieldId; // the id of the field "inconsistent" notification div
  // no inconsistent value - unbind if there were any
  jQuery("#fv_id_" + fieldId).unbind('change.warn_' + fieldId);
  // remove any notifications if exist since there is no inconsistent value
  jQuery("#" + warningId).hide();
}

/**
 * Load the valid values for the drop down for a given field.
 * @param childId the field id to load
 * @param folderPath current tracker folder path
 * @param currentSelectedValue the current selected value
 * @param suppressWarning true to suppress warning for conflicts
 */
function loadValidValues(childId, folderPath, currentSelectedValue, suppressWarning) {
  if (childId == undefined) {
      return;
  }
  var parentId = CTF.fromChildToParent[childId];
  if (parentId == undefined) {
      return;
  }
  // register an error to be invoked when there is an error
  jQuery(document).ajaxError(function(event, request, settings) {
    alert(inconsistencyMessage);
  });

  var parentValueName = $j("select[name='flexFields(" + parentId + ")']").val();
  if (parentValueName == '' || parentValueName == _MASS_UPDATE_MAGIC_VALUE) {
      // Disable the child field as the parent is undefined
      $j("select[name='flexFields(" + childId + ")']").prop("disabled", true).html('<option value="' + parentValueName + '">' +
              (parentValueName == '' ? _NONE_MESSAGE : _UNCHANGED_FIELD_VALUE) + '</option>').val(parentValueName);
    unbindAndRemoveWarning(childId); // remove any warning messages
      // now load the grandchild assuming child value is undefined
      loadValidValues(CTF.fromParentToChild[childId], folderPath, parentValueName, suppressWarning);
  } else {
    var parentValueId = CTF.allFields[parentId][parentValueName];
    var currentChildValue = $j("select[name='flexFields(" + childId + ")']").val();
    // alert("parentId " + parentId + "\nparentValueName:" + parentValueName + "\nparentValueId:" + parentValueId);
    var handlerURL = "/sf/tracker/do/getChildFieldValuesJSON/" + folderPath + "?childid=" + childId;

    // the parent value can be undefined if it's no longer a valid selection
    if (parentValueId != undefined) {
      handlerURL = handlerURL + "&parentfv=" + parentValueId;
    }

    $j.ajax( {
      url : handlerURL,
      dataType : 'json',
      success : function(data) {
        if (data.action === undefined) {
          // We had an issue.
          alert(_INCONSISTENCY_MESSAGE);
        } else if (data.action == "render") {
          // We are good
          $j("select[name='flexFields(" + childId + ")']").removeAttr("disabled").each( function(xx) {
            // Clean-up the current value
            this.innerHTML = "";

            // need to handle inconsistent state where currently selected value isn't a "valid" option
            var foundCurSelectedVal = false;

            // Insert the new values. Note we're using document.createElement to guard against JS injection
            var hasValidOption = false;
            var selectedOption = null;
            var selectedOptionEl = null;
            var firstOptionEl = null;
            for (var i = 0; i < data.values.length; ++i) {
              var value = data.values[i];
              var isSelected = false;
              var optionVal = value["name"];
              if (optionVal == currentSelectedValue) {
                foundCurSelectedVal = true;
              }

              if (foundCurSelectedVal || value["visible"] === true) {
                if (optionVal == currentChildValue) {
                  selectedOption = optionVal;
                  isSelected = true;
                }

                var fieldOptionEl = document.createElement("option");
                fieldOptionEl.setAttribute("value", optionVal);
                if (isSelected) {
                  fieldOptionEl.setAttribute("selected", "selected");
                  selectedOptionEl = fieldOptionEl;
                }
                var fieldOptionValueEl = document.createTextNode(optionVal);
                fieldOptionEl.appendChild(fieldOptionValueEl);
                this.appendChild(fieldOptionEl);
                if (firstOptionEl == null) {
                  firstOptionEl = fieldOptionEl;
                }

                registerFieldValue(childId, optionVal, value["id"]);
                hasValidOption = true;
              }
            }

            var hasRenderedNoneValue = false;

            // if the field is not required, then none is considered a valid selection
            if (!data.fieldIsRequired && currentSelectedValue == "") {
              foundCurSelectedVal = true;
            }

            // if current state is inconsistent according to field hierarchy configuration, we display a notification
            if (!foundCurSelectedVal && !suppressWarning && currentSelectedValue != undefined) {
              // being here means we have a value that is not in the "legal" list of options
              var currentSelectedDisplay = (currentSelectedValue == '') ? _NONE_MESSAGE : currentSelectedValue;
              var curFieldOptionEl = document.createElement("option");
              curFieldOptionEl.setAttribute("value", currentSelectedValue);
              curFieldOptionEl.setAttribute("selected", "selected");
              var curFieldOptionValueEl = document.createTextNode(currentSelectedDisplay);
              curFieldOptionEl.appendChild(curFieldOptionValueEl);
              if (firstOptionEl != null) {
                this.insertBefore(curFieldOptionEl, firstOptionEl);
              } else {
                this.appendChild(curFieldOptionEl);
              }
              hasValidOption = true;
              //ie related
              selectedOption = currentSelectedValue;
              selectedOptionEl = curFieldOptionEl;

              var warningId = "invalid_" + childId; // the id of the field "inconsistent" notification div
              var selectEl = jQuery("#fv_id_" + childId).after(generateInvalidStateWarning(warningId, data.fieldParentName));
              // make the warning appear/disappear whenever we select/deselect the invalid value
              selectEl.bind('change.warn_' + childId, function(){
                var thisEl = jQuery(this);
                if (thisEl.val() == currentSelectedValue) {
                  jQuery("#" + warningId).show();
                } else {
                  jQuery("#" + warningId).hide();
                }
              });

              hasRenderedNoneValue = (currentSelectedValue == '');
            } else {
              unbindAndRemoveWarning(childId);
            }

            // insert "none" if "none" isn't already rendered and is either not required or has no other possible values
            if (!hasRenderedNoneValue && (data.fieldIsRequired == false || !hasValidOption)) {
              var noneFieldOptionEl = document.createElement("option");
              noneFieldOptionEl.setAttribute("value", "");
              var noneFieldOptionValueEl = document.createTextNode(_NONE_MESSAGE);
              noneFieldOptionEl.appendChild(noneFieldOptionValueEl);
              if (currentChildValue == "") {
                selectedOption = "";
                selectedOptionEl = noneFieldOptionEl;
              }
              if (firstOptionEl != null) {
                this.insertBefore(noneFieldOptionEl, firstOptionEl);
              } else {
                this.appendChild(noneFieldOptionEl);
              }
            }

            // only set the value if a selection is made (since if the value is not a valid option, browsers like IE7 will create the extra dom)
            // XXX: This is a very odd IE6 hack! Do not touch it unless you really know what you are doing!
            if (selectedOption != null) {
              this.setAttribute("value", selectedOption);
              this.value = selectedOption;
            }
            if (selectedOptionEl != null) {
                selectedOptionEl.setAttribute("selected", "selected");
            }

            // Trigger the update for the child values
            var grandChildId = CTF.fromParentToChild[childId];
            loadValidValues(grandChildId, folderPath, $j("select[name='flexFields(" + grandChildId + ")']").attr('selectedValue'), suppressWarning);
          });
        } else {
          // again, we had an issue.
          alert(_INCONSISTENCY_MESSAGE);
        }
      },
      cache : false,
      async : false
    });
  }

}

/**
 * Initialize parent child field for field hierarchy.
 * @param childId the child field id
 * @param parentId parent field id
 * @param folderPath current folder path
 * @param suppressWarning true to suppress hierarchy inconsistency warning
 */
function initializeParentChild(childId, parentId, folderPath, suppressWarning) {
  checkCTFinitialization();
  CTF.fromParentToChild[parentId] = childId;
  CTF.fromChildToParent[childId] = parentId;
  var childEl = $j("select[name='flexFields(" + childId + ")']");
  loadValidValues(childId, folderPath, childEl.attr('selectedValue'), suppressWarning);
  // bind 'loadValidValues' to change events but under special namespaces so they can be more easily removed
  $j("select[name='flexFields(" + parentId + ")']").bind('change.load_' + childId, function(event) {
      loadValidValues(childId, folderPath, childEl.attr('selectedValue'), true); // warning always suppress for user action
  });
}

// added to remove errors for checkRequireEmpty call.
function resetError(inputName, errorId){
  document.getElementById(errorId).style.display = "none";
  var inputEl = document.getElementsByName(inputName)[0];
  inputEl.onchange=null;
}

// displays warning when a value is not set for a required field at editing
function checkRequiredEmpty(inputName, errorId) {
  $j(document).ready(function () {
  var inputEl = document.getElementsByName(inputName)[0];
  document.getElementById(errorId).innerHTML='<span class="artifactFieldError"><div class="error-label">' + VALUE_NOW_REQUIRED_MESSAGE + '</div></span>';
  inputEl.onchange=function(){
    resetError(inputName, errorId)
  };
  });
}

function toggleNoValuesRow() {
    if ((!isNoneRowEnabled() || $j("#isRequiredCheckbox").checked ) && !hasValues()) {
        if (_NO_VALUES_ROW_EL != null) {
	    var footerEl = document.getElementById("FieldValueListTableFooter");
	    var tableEl = footerEl.parentNode;

	    tableEl.insertBefore(_NO_VALUES_ROW_EL, footerEl);
	}
    } else if (isNoneRowEnabled() || !document.getElementById("isRequiredCheckbox").checked || hasValues()) {
	removeNoValuesRow();
    }
}

function toggleFieldRequiredness(displayType) {
    var noneRowEl = document.getElementById("noneRow");
    var defaultValue = document.getElementById("hideDefaultValues");
    
    if (document.getElementById("isRequiredCheckbox").checked) {
        if (defaultValue !=null && (displayType == "TEXT" || displayType == "USER" )) {
            defaultValue.style.display = "";
        }
        if (noneRowEl != null && displayType == "MULTISELECT") {
            noneRowEl.style.display = "none";
        }
    } else {
        if (defaultValue !=null &&  (displayType == "TEXT" || displayType == "USER" )) {
            defaultValue.style.display = "none";
        }
    }

    toggleNoValuesRow();
}

var _NO_VALUES_ROW_EL = null;
function setNoValuesRowData(colSpan, noResultText) {
    _NO_VALUES_ROW_EL = document.createElement("tr");
    _NO_VALUES_ROW_EL.id = "NoValuesRow";
    _NO_VALUES_ROW_EL.className = "ItemListNoData";

    var mainCell = document.createElement("td");
    mainCell.colSpan = colSpan;
    mainCell.appendChild(document.createTextNode(noResultText));
    _NO_VALUES_ROW_EL.appendChild(mainCell);
}

function hasValues() {
    if (_FIRST_ROW_INDEX <= 0) {
        return false;
    } else if (_LAST_ROW_INDEX < _FIRST_ROW_INDEX) {
        return false;
    }

    return true;
}

function removeNoValuesRow() {
    var noValuesRow = document.getElementById("NoValuesRow");

    if (noValuesRow != null) {
	var tableEl = document.getElementById("FieldValueListTableFooter").parentNode;
	tableEl.removeChild(noValuesRow);
    }
}

function getRowSelectElement(rowId) {
    var checkboxEl = document.createElement("input");
    checkboxEl.type = "checkbox";
    checkboxEl.value = rowId;
    checkboxEl.name = "selectedValueIds";
    checkboxEl.id = "rowSelect_" + rowId;
    checkboxEl.className = "primary-checkbox";

    return checkboxEl;
}

function getRowSelectElementLabel(rowId) {
    var labelEl = document.createElement("label");
    labelEl.htmlFor = "rowSelect_" + rowId;
    labelEl.className = "custom-label";
    labelEl.id = "empty-label";
    var spanEl = document.createElement("span");
    spanEl.className = "sr-only";
    spanEl.appendChild(document.createTextNode("emptyLabel"));
    labelEl.appendChild(spanEl);
    return labelEl;
}

var currentDisplayPos = 1;
function getDisplayOrderElement(rowId) {
    var displayOrderEl = document.createElement("input");
    displayOrderEl.type = "hidden";
    displayOrderEl.name = "displayOrder(" + rowId + ")";
    displayOrderEl.id = "displayOrder_" + rowId;
    displayOrderEl.value = currentDisplayPos++;

    return displayOrderEl;
}

function getValueElement(rowId, value) {
    var valueEl = document.createElement("input");
    valueEl.name = "value(" + rowId + ")";
    valueEl.type = "text";
    valueEl.value = value;
    valueEl.className = "inputfield";
    valueEl.size = "26";
    valueEl.maxLength = "60";
    valueEl.id = "value_" + rowId;

    return valueEl;
}

function getLabelElement(rowId) {
    var labelEl = document.createElement("label");
    labelEl.htmlFor = "value_" + rowId;
    var spanEl = document.createElement("span");
    spanEl.className = "sr-only";
    spanEl.appendChild(document.createTextNode("emptyLabel"));
    labelEl.appendChild(spanEl);
    return labelEl;
}

function getValueErrorsElement(rowId) {
    var errorsEl = document.createElement("font");
    errorsEl.className = "error-label";

    var messages = getErrorMessages(rowId);
    for (var i in messages) {
        errorsEl.appendChild(document.createTextNode(messages[i]));
        errorsEl.appendChild(document.createElement("br"));
    }

    return errorsEl;
}

function getValueClassSelectElement(rowId, valueClass) {
    var labelEl = document.createElement("label");
    var valueClassEl = document.createElement("select");
    var selectedIndex = 0;
    var index = 0;

    labelEl.htmlFor = "valueClass(" + rowId + ")";
    valueClassEl.name = "valueClass(" + rowId + ")";
    valueClassEl.className = "inputfield";
    valueClassEl.id = "valueClass(" + rowId + ")";

    for (var i in _VALUE_CLASSES) {
        var optionEl = document.createElement("option");
        optionEl.value = i;
        if (valueClass == optionEl.value) {
            selectedIndex = index;
        }
        index = index + 1;

        optionEl.appendChild(document.createTextNode(_VALUE_CLASSES[i]));
        valueClassEl.appendChild(optionEl);
        labelEl.appendChild(valueClassEl);
    }

    labelEl.selectedIndex = selectedIndex;
    return labelEl;
}

function getStatusSubmittableTD(rowId, value) {
    var id = "sourceCodeChangesAllowed_" + rowId;
    var name = "sourceCodeChangesAllowed(" + rowId + ")";
    var checkboxHidden = document.createElement("input");
    checkboxHidden.id = id + "_hidden";
    checkboxHidden.name = name;
    checkboxHidden.value = "false";
    checkboxHidden.checked = true;
    checkboxHidden.type = "hidden";

    var checkbox = document.createElement("input");
    checkbox.id = id;
    checkbox.name = name;
    checkbox.value = "true";
    checkbox.checked = false;
    checkbox.className = "primary-checkbox";
    checkbox.type = "checkbox";

    var label = document.createElement("label");
    label.setAttribute("for", id);
    label.className = "custom-label";

    var td = document.createElement("td");
    td.headers = "sourceCodeChangesAllowed";
    td.appendChild(checkboxHidden);
    td.appendChild(checkbox);
    td.appendChild(label);
    return td;
}

function getDefaultValueElement(rowId, isDefault) {
    var defaultValueEl = document.createElement("input");

    defaultValueEl.id = "defaultValue_" + rowId;
    defaultValueEl.type = "checkbox";
    defaultValueEl.name = "defaultValueId";
    defaultValueEl.value = rowId;
    defaultValueEl.checked = isDefault;

    return defaultValueEl;
}

function getVisibleCellEl(rowId, visible) {
    var visibleCellEl = document.createElement("td");
    visibleCellEl.setAttribute("headers", "visible_head");
    visibleCellEl.setAttribute("class", "vis");
    visibleCellEl.setAttribute("className", "vis");

    visibleInputEl = "<fieldset><legend class='legend-overwrite'></legend><input type='checkbox' class='primary-checkbox' name='visibleValueIds' value='" + rowId + "'";
    if (visible) {
        visibleInputEl += " checked";
    }
    visibleInputEl += " id='visible_" + rowId + "'>";
    visibleInputEl += "<label for='visible_" + rowId + "'id='empty-label' class='custom-label' ><span class='sr-only'>emptyLabel</span></fieldset>";
    visibleCellEl.innerHTML = visibleInputEl;
    return visibleCellEl;
}

function enableVisibleBox() {
    $j('input[name=visibleValueIds]').removeAttr('disabled');
}

function disableVisibleBox() {
    $j('input[name=visibleValueIds]').removeAttr('disabled');
    $j('input[name=defaultValueId]:checked').each(function(i, obj) {
        $j('#visible_' + obj.value).prop('checked', true).prop('disabled', true);
    });
}

function getMoveRowLink(moveText, functionName, rowId) {
    var linkEl = document.createElement("a");
    linkEl.href = "JavaScript: " + functionName + "('" + rowId + "');";
    linkEl.appendChild(document.createTextNode(moveText));
    linkEl.id = functionName + "_" + rowId;

    return linkEl;
}

var _ROW_ID_MAP = new Array();
var _ROW_VALUE_MAP = new Array();
var _FIRST_ROW_INDEX = -1;
var _LAST_ROW_INDEX = -1;

function setRowValue(rowId, value) {
    _ROW_ID_MAP[_ROW_ID_MAP.length] = rowId;
    _ROW_VALUE_MAP[_ROW_VALUE_MAP.length] = value;
}

function removeRowValue(rowId) {
    var newIdMap = new Array();
    var newValueMap = new Array();

    for (var i = 0; i < _ROW_ID_MAP.length; i++) {
        if (_ROW_ID_MAP[i] != rowId) {
            newIdMap[newIdMap.length] = _ROW_ID_MAP[i];
            newValueMap[newValueMap.length] = _ROW_VALUE_MAP[i];
        }
    }

    _ROW_ID_MAP = newIdMap;
    _ROW_VALUE_MAP = newValueMap;
}


/************************************************************
 *                                                          *
 * The methods below deal with adding and moving value rows *
 *                                                          *
 ************************************************************/

var _ROW_COUNT = 0;
var _ROW_CLASSES = new Array();
_ROW_CLASSES[0] = "EvenRow";
_ROW_CLASSES[1] = "OddRow";
var idCounter = 0;

/**
 * Check to see if the row boundaries for the table have been set.
 */
function initRowBoundaries(isCreate) {
    var firstRow = false;

    if (_FIRST_ROW_INDEX < 0) {
	var footerEl = document.getElementById("FieldValueListTableFooter");
	var tableEl = footerEl.parentNode;

        firstRow = true;
        _FIRST_ROW_INDEX = 0;
        for (var i = 0; i < tableEl.childNodes.length; i++) {
	    _LAST_ROW_INDEX = i;
            if (isCreate) {
                _FIRST_ROW_INDEX = i;
            }
            if (tableEl.childNodes[i].id == footerEl.id) {
                break;
            }
            if (!isCreate) {
                _FIRST_ROW_INDEX = i;
            }
        }
	_LAST_ROW_INDEX--;

	if (_LAST_ROW_INDEX < _FIRST_ROW_INDEX) {
	    _LAST_ROW_INDEX = _FIRST_ROW_INDEX;
	}
    }

    return firstRow;
}

/**
 * Check if a row is valid.
 */
function isValidValueRow(rowEl) {
    return rowEl.tagName != null && rowEl.tagName.toLowerCase() == "tr" &&
           rowEl.id != null && rowEl.id != "" && rowEl.id != "noneRow" && rowEl.id != "FieldValueListTableFooter" &&
	   rowEl.id != "ValueListHeader";
}

/**
 * initialize a row that was manually created in the jsp file.
 */
function initFieldValueRows(rowCount) {
    if (initRowBoundaries(false)) {
	var footerEl = document.getElementById("FieldValueListTableFooter");
	var tableEl = footerEl.parentNode;
	var found = 0;

        for (var i = tableEl.childNodes.length - 1; i--; i > 0) {
            var childEl = tableEl.childNodes[i];
	    if (childEl.id == "noneRow" || childEl.id == "ValueListHeader") {
	        break;
	    }
            _FIRST_ROW_INDEX--;
            if (isValidValueRow(childEl)) {
                var valueEl = document.getElementById("value_" + childEl.id);

		checkDummyRowCounter(childEl.id);
		setRowValue(childEl.id, valueEl.value);
                found++;
                if (found >= rowCount) {
                    break;
                }
            }
        }
    }

    currentDisplayPos += rowCount;
    resetDisplayPositions();
}

/**
 * Examine an id.  If it is a dummy id, see if the number is >= to our current id counter.  If so, increment our
 * internal dmmy row counter.
 */
function checkDummyRowCounter(rowId) {
    if (rowId.match(/^dmmy/)) {
	var id = parseInt(rowId.substr(4));
        if (idCounter <= id) {
            idCounter = id + 1;
        }
    }
}

/**
 * This adds a field value that will be displayed in the field value table
 * @param rowId The id of the row that is being displayed
 * @param value The value of the field value
 * @param valueClass The value class for this field value
 * @param isDefault true if the value is the default
 * @param showVisibleColumn true for tracker fields
 * @param visible boolean value
 */
function addFieldValueRow(rowId, value, valueClass, isDefault, showVisibleColumn, visible) {
    checkDummyRowCounter(rowId);
    setRowValue(rowId, value);
    removeNoValuesRow();

    var footerEl = document.getElementById("FieldValueListTableFooter");
    var displayType = document.getElementById('selectedDisplayType').value;
    var tableEl = footerEl.parentNode;
    var firstRow = initRowBoundaries(true);

    // Now create the row
    var valueRow = document.createElement("tr");
    valueRow.id = rowId;
    valueRow.className = _ROW_CLASSES[_ROW_COUNT++ % 2];

    var checkboxCellEl = document.createElement("td");
    checkboxCellEl.setAttribute("headers", "checkbox_head");
    var fieldsetEl = document.createElement("fieldset");
    var legendEl = document.createElement("legend");
    legendEl.className = "legend-overwrite";
    fieldsetEl.appendChild(legendEl);
    fieldsetEl.appendChild(getRowSelectElement(rowId));
    fieldsetEl.appendChild(getRowSelectElementLabel(rowId));
    checkboxCellEl.appendChild(fieldsetEl);
    checkboxCellEl.appendChild(getDisplayOrderElement(rowId));
    valueRow.appendChild(checkboxCellEl);

    var valueCellEl = document.createElement("td");
    valueCellEl.setAttribute("headers", "values_head");
    valueCellEl.setAttribute("class", "ItemDetailValue");
    valueCellEl.appendChild(getValueElement(rowId, value));
    valueCellEl.appendChild(getLabelElement(rowId));

    if (hasErrors(rowId)) {
        valueCellEl.appendChild(document.createElement("br"));
        valueCellEl.appendChild(getValueErrorsElement(rowId));
    }
    valueRow.appendChild(valueCellEl);

    if (_USE_VALUE_CLASSES) {
        var valueClassCellEl = document.createElement("td");
        valueClassCellEl.appendChild(getValueClassSelectElement(rowId, valueClass));
        valueRow.appendChild(valueClassCellEl);
    }

    if (_IS_STATUS_FIELD) {
        valueRow.appendChild(getStatusSubmittableTD(rowId, value));
    }

    if (_USE_HIERARCHICAL_VALUES) {
        var hierarchicalCellEl = document.createElement("td");
        hierarchicalCellEl.setAttribute("headers", "fvr_head");
        hierarchicalCellEl.setAttribute("class", "fvr");
        hierarchicalCellEl.setAttribute("className", "fvr");
        hierarchicalCellEl.style.display = "none";
        var hierarchicalSelectEl = document.createElement("select");
        hierarchicalSelectEl.setAttribute("multiple", "multiple");
        hierarchicalSelectEl.setAttribute("size", "5");
        hierarchicalSelectEl.setAttribute("name", "parentValues(" + rowId + ")");
        hierarchicalSelectEl.setAttribute("class", "fvr_select");
        hierarchicalSelectEl.setAttribute("className", "fvr_select");
        for (var i = 0; i < _HIERARCHICAL_PARENT_FIELD_VALUES.length; ++i) {
            var value = _HIERARCHICAL_PARENT_FIELD_VALUES[i];
            if (value["visible"] === undefined || value["visible"] === true) {
                var hierarchicalSelectOptionEl = document.createElement("option");
                hierarchicalSelectOptionEl.setAttribute("value",value["id"]);
                var hierarchicalSelectOptionValueEl = document.createTextNode(value["name"]);
                hierarchicalSelectOptionEl.appendChild(hierarchicalSelectOptionValueEl);
                hierarchicalSelectEl.appendChild(hierarchicalSelectOptionEl);
            }
        }
        hierarchicalCellEl.appendChild(hierarchicalSelectEl);
        valueRow.appendChild(hierarchicalCellEl);
    }

    var defaultValueCellEl = document.createElement("td");
    
    defaultValueCellEl.setAttribute("headers", "default_value_head");
    defaultValueCellEl.setAttribute("class", "def");
    defaultValueCellEl.setAttribute("className", "def");
    
    var defaultValueSelectorEl = getDefaultValueElement(rowId, isDefault);
    // Since IE does not know how to create a radio button with standard DOM functions, fake it
    var defaultValue = "";
    if (displayType == "MULTISELECT") {
	defaultValue = "<fieldset><legend class='legend-overwrite'></legend><input type='checkbox' class='primary-checkbox' name='" + defaultValueSelectorEl.name + "' value='" + defaultValueSelectorEl.value + "'";
    } else {
       defaultValue = "<fieldset><legend class='legend-overwrite'></legend><input type='radio' class='primary-radio' name='" + defaultValueSelectorEl.name + "' value='" + defaultValueSelectorEl.value + "'";
    }
    if (defaultValueSelectorEl.checked) {
        defaultValue += " checked";
    }
    defaultValue += " id='defaultValue_" + rowId + "' onchange='javascript:disableVisibleBox();'>";
    defaultValue += "<label for='defaultValue_" + rowId + "'id='empty-label' class='custom-label' ><span class='sr-only'>emptyLabel</span></fieldset>";
    defaultValueCellEl.innerHTML = defaultValue;
    valueRow.appendChild(defaultValueCellEl);

    if (showVisibleColumn) {
        var visibleCellEl = getVisibleCellEl(rowId, visible);
        valueRow.appendChild(visibleCellEl);
    }

    var moveUpCellEl = document.createElement("td");
    moveUpCellEl.setAttribute("headers", "up_head");
    moveUpCellEl.appendChild(getMoveRowLink(_MOVE_UP, "moveUp", rowId));
    valueRow.appendChild(moveUpCellEl);

    var moveDownCellEl = document.createElement("td");
    moveDownCellEl.setAttribute("headers", "down_head");
    moveDownCellEl.appendChild(getMoveRowLink(_MOVE_DOWN, "moveDown", rowId));
    valueRow.appendChild(moveDownCellEl);

    // Now make sure that the "no data" row is gone and add the new row
    var noValuesRowEl = document.getElementById("NoValuesRow");
    if (noValuesRowEl != null) {
        tableEl.removeChild(noValuesRowEl);
    }
    tableEl.insertBefore(valueRow, footerEl);

    if (!firstRow) {
        _LAST_ROW_INDEX++;
    }

    resetDisplayPositions();
}

var fieldValueErrors = new Array();
function addValueError(rowId, message) {
    var errorMessages = fieldValueErrors[rowId];
    if (errorMessages == null) {
        errorMessages = new Array();
    }
    errorMessages[errorMessages.length] = message;
    fieldValueErrors[rowId] = errorMessages;
//    errorMessages.push(message);
}

function hasErrors(rowId) {
    return fieldValueErrors[rowId] != null;
}

function getErrorMessages(rowId) {
    return fieldValueErrors[rowId];
}

function resetDisplayPositions() {
    var tableEl = document.getElementById("FieldValueListTableFooter").parentNode;
    var formEl = document.getElementById(getFormId());

    var position = 1;
    for (var i = _FIRST_ROW_INDEX; i <= _LAST_ROW_INDEX; i++) {
        var valueRowEl = tableEl.childNodes[i];

        if (!isValidValueRow(valueRowEl)) {
            continue;
        }

        if (valueRowEl.id == "NoValuesRow") {
            // No data in the table
            break;
        }

        var positionElId = "displayOrder_" + valueRowEl.id;
        var positionEl = document.getElementById(positionElId);

        positionEl.value = position++;
        valueRowEl.className = _ROW_CLASSES[position % 2];
    }
}

function addNewRow(showVisibleColumn) {
    var newId = "dmmy" + idCounter++;
    addFieldValueRow(newId, "", "", false, showVisibleColumn, true);
}

function processRowDeletions() {
    // Get the checked rows
    for (var i = _ROW_ID_MAP.length - 1; i >= 0; i--) {
        var rowId = _ROW_ID_MAP[i];
        var checkboxEl = document.getElementById("rowSelect_" + rowId);
        if (checkboxEl != null && checkboxEl.checked) {
            deleteRow(rowId);
        }
    }    
}

function deleteRow(rowId) {
    var tableEl = document.getElementById("FieldValueListTableFooter").parentNode;
    var formEl = document.getElementById(getFormId());
    var rowEl = document.getElementById(rowId);

    if (rowEl != null && rowEl.parentNode == tableEl) {
	tableEl.removeChild(rowEl);
	_LAST_ROW_INDEX--;
    }

    toggleNoValuesRow();
    resetDisplayPositions();
}

function convertDefaultFieldToCheckbox() {
    var tableEl = document.getElementById("FieldValueListTableFooter").parentNode;
    var formEl = document.getElementById(getFormId());

    if (_FIRST_ROW_INDEX > -1) {
	for (var i = _FIRST_ROW_INDEX; i <= _LAST_ROW_INDEX; i++) {
	    var thisId = tableEl.childNodes[i].id;
	    defaultValueEl = document.getElementById("defaultValue_" + thisId);
	    defaultValueEl.type="checkbox";
	    defaultValueEl.className="primary-checkbox";
	}
	resetDisplayPositions();
    }

    var noneRowEl = document.getElementById("noneRow");
    if (noneRowEl != null) {
	noneRowEl.style.display = "none";
    }
}

function convertDefaultFieldToRadioButton() {
    var tableEl = document.getElementById("FieldValueListTableFooter").parentNode;
    var formEl = document.getElementById(getFormId());

    if (_FIRST_ROW_INDEX > -1) {
	for (var i = _FIRST_ROW_INDEX; i <= _LAST_ROW_INDEX; i++) {
	    var thisId = tableEl.childNodes[i].id;
	    defaultValueEl = document.getElementById("defaultValue_" + thisId);
	    defaultValueEl.type="radio";
	    defaultValueEl.className="primary-radio";
	    
	}
	resetDisplayPositions();
    }
    var defaultValueEl = document.getElementById("defaultValueId");
    if (defaultValueEl != null) {
	defaultValueEl.type = "radio";
	defaultValueEl.className = "primary-radio";
    }
    var noneRowEl = document.getElementById("noneRow");
    if (noneRowEl != null) {
	noneRowEl.style.display = "";
    }

}

function moveUp(rowId) {
    var tableEl = document.getElementById("FieldValueListTableFooter").parentNode;

    var topRowId = null;
    var rowIndex = -1;
    for (var i = _FIRST_ROW_INDEX + 1; i <= _LAST_ROW_INDEX; i++) {
        if ((tableEl.childNodes[i] != null) && (tableEl.childNodes[i].id == rowId)) {
            rowIndex = i;
            break;
        }
    }

    if (rowIndex <= 0) {
        return;
    }

    for (var i = rowIndex - 1; i >= _FIRST_ROW_INDEX; i--) {
        if (isValidValueRow(tableEl.childNodes[i])) {
            topRowId = tableEl.childNodes[i].id;
            break;
        }
    }

    if (topRowId != null && topRowId != "") {
	swapValueRow(topRowId, rowId);
	resetDisplayPositions();
    }
}

function moveDown(rowId) {
    var tableEl = document.getElementById("FieldValueListTableFooter").parentNode;
    var bottomRowId = null;

    for (var i = _FIRST_ROW_INDEX; i < _LAST_ROW_INDEX; i++) {
        if (tableEl.childNodes[i].id == rowId) {
            for (var j = i + 1; j <= _LAST_ROW_INDEX; j++) {
                if (isValidValueRow(tableEl.childNodes[j])) {
                    bottomRowId = tableEl.childNodes[j].id;
                    break;
                }
            }
            break;
        }
    }

    if (bottomRowId == null) {
        return;
    }

    swapValueRow(rowId, bottomRowId);
    resetDisplayPositions();
}

function swapValueRow(topRowId, bottomRowId) {
    if (topRowId == bottomRowId) {
        return;
    }

    var tableEl = document.getElementById("FieldValueListTableFooter").parentNode;

    var topRow = document.getElementById(topRowId);
    var bottomRow = document.getElementById(bottomRowId);

    var isCheckedTop = document.getElementById("defaultValue_" + topRowId).checked;
    var isCheckedBottom = document.getElementById("defaultValue_" + bottomRowId).checked;

    tableEl.removeChild(bottomRow);
    tableEl.insertBefore(bottomRow, topRow);

    // For some reason, IE drops the checked status of the default value check box so reset it here
    document.getElementById("defaultValue_" + topRowId).checked = isCheckedTop;
    document.getElementById("defaultValue_" + bottomRowId).checked = isCheckedBottom;
}

function sortCaseInsensetive(a, b) {
    var x = a.toLowerCase();
    var y = b.toLowerCase();
    if (x == y) {
        return 0;
    } else if ( x < y ) {
        return -1;
    } else {
        return 1;
    }
}

function alphabetizeRows() {
    var footerEl = document.getElementById("FieldValueListTableFooter");
    var tableEl = footerEl.parentNode;

    var firstRowIndex = _LAST_ROW_INDEX;
    var nameArray = new Array();
    for (var j = _FIRST_ROW_INDEX; j <= _LAST_ROW_INDEX; j++) {
        if (!isValidValueRow(tableEl.childNodes[j])) {
            continue;
        }

        var thisRowId = tableEl.childNodes[j].id;

	// We need to update the first row index based on updated table information.
	firstRowIndex = Math.min(firstRowIndex, j);

        var value = "a" + document.getElementById("value_" + thisRowId).value;
        nameArray.push(value);
    }

    // Re-initialize the first row based on updated table information.
    _FIRST_ROW_INDEX = firstRowIndex;
    nameArray.sort(sortCaseInsensetive);

    for (var i = 0; i < nameArray.length; i++) {
        var value = nameArray[i].substring(1);
        var newPos = _FIRST_ROW_INDEX;
        var skipped = 0;
        while (skipped < i) {
            newPos++;
            if (tableEl.childNodes[newPos].tagName != null) {
                skipped++;
            }
        }

        var newPosId = tableEl.childNodes[newPos].id;

        var targetRowId = null;
        for (var j = newPos; j <= _LAST_ROW_INDEX; j++) {
            var childEl = tableEl.childNodes[j];
            if (!isValidValueRow(childEl)) {
                continue;
            }

            targetRowId = childEl.id;
            var targetValue = document.getElementById("value_" + targetRowId).value;

            if (targetValue == value) {
                break;
            }
        }

        swapValueRow(newPosId, targetRowId);
    }

    resetDisplayPositions();
}

function confirmOrQuit(message) {
    if (!confirm(message)) {
        throw new Exception("Aborting execution!");
    }
}

/**
* Given a field, determine whether the value passes the validation setup for the field.
* @param field the field dom element
* @param resultFieldPattern extra param for the input field to be validated
*/
function validateText(field, resultFieldPattern) {
  var fieldEl = $j(field);
  var inputName = fieldEl.attr("name");
  var prevVal = fieldEl.attr("prevVal");
  var resultSpanNamePatern = '#fv_result_';
  
  if (resultFieldPattern != null){
	  resultSpanNamePatern = '#' + fieldEl.attr("id") + resultFieldPattern;
  }

  if (fieldEl.val() == prevVal) {
    // if the field value hasn't changed, just abort
    return;
  } else {
    fieldEl.attr("prevVal", fieldEl.val());
  }

  var startingOffset = inputName.indexOf("(") + 1; // for extracting field id from the input field "name"
  var endingOffset = inputName.indexOf(")");

  var fieldId = inputName.substring(startingOffset, endingOffset);

  if (fieldEl.val() == "") {
    // if we're clearing the value, remove the validation imgs
    $j(resultSpanNamePatern + fieldId).html("");
    return;
  }

  var params = {"fieldId" : fieldId, "value" : fieldEl.val()};

  $j.ajax({
    url: '/sf/tracker/do/validateField',
    data: params,
    dataType: 'json',

    error: function(xhr, text, err) {},

    success: function(data) {
      if (data.action == 'render') {
        if (data.fieldId  != undefined) {
          var resultEl = $j(resultSpanNamePatern + data.fieldId);
        // Handle the success and update the right panel
        var result = (data.match == true) ? 'tick.png' : 'close.png';
        resultEl.html('<img alt="" src="/sf-images/misc/' + result + '" style="vertical-align:middle; padding-right: 5px"/>');
        }
      } else if (data.action == 'error') {
        // throw alert to alert of the error
        alert(INVALID_FIELD_VALIDATION_RESPONSE);
      }
    },

    complete: function(xhr, text) {}
  });
}
