/*
 * CollabNet TeamForge(r) Enterprise Edition
 * Copyright 2016 CollabNet, Inc.  All rights reserved.
 * http://www.collab.net
 */

var _NONE_MESSAGE = "None";

var _INCONSISTENCY_MESSAGE = "Error loading the field information.";

var _UNCHANGED_FIELD_VALUE = "Unchanged";

if (_FIELD_HIERARCHY_INCONSISTENT_MESSAGE == undefined) {
  var _FIELD_HIERARCHY_INCONSISTENT_MESSAGE = "This value is not allowed because it conflicts with the value selected in its parent field"
}


if (typeof CTF == "undefined" || !CTF) {
  var CTF = {};
}

function setInconsistencyMessage(message) {
      _INCONSISTENCY_MESSAGE = message;
}

function setNoneMessage(message) {
    _NONE_MESSAGE = message;
}

function setUnchangedValue(unchangedValue) {
    _UNCHANGED_FIELD_VALUE = unchangedValue;
}

function checkCTFinitialization() {
  if (typeof CTF.fromParentToChild == "undefined" || !CTF.fromParentToChild) {
    CTF.fromParentToChild = {};
  }
  if (typeof CTF.fromChildToParent == "undefined" || !CTF.fromChildToParent) {
      CTF.fromChildToParent = {};
    }
  if (typeof CTF.allFields == "undefined" || !CTF.allFields) {
        // this is a lookup map where [fieldId][fieldValueValue] = fieldValueId
        CTF.allFields = {};
      }
}


 /* Register a field value id in a lookup map. This way given a field id and field value, you can look up field value id.
 * @param fieldId field id
 * @param fieldValueValue field value
 * @param fieldValueId field value id
 */
function registerFieldValue(fieldId, fieldValueValue, fieldValueId) {
    checkCTFinitialization();
    if (typeof CTF.allFields[fieldId] == "undefined" || !CTF.allFields[fieldId]) {
      CTF.allFields[fieldId] = {};
    }
    CTF.allFields[fieldId][fieldValueValue] = fieldValueId;
}

/**
 * When a value is not consistent with the current field hierarchal mapping, an inconsistency warning message appears.
 * If that value has been removed due to new loading of values after change to the parent, this warning/binding
 * should no longer apply.
 * @param fieldId the field id
 */
function unbindAndRemoveWarning(fieldId) {
  var warningId = "invalid_" + fieldId; // the id of the field "inconsistent" notification div
  // no inconsistent value - unbind if there were any
  jQuery("#fv_id_" + fieldId).unbind('change.warn_' + fieldId);
  // remove any notifications if exist since there is no inconsistent value
  jQuery("#" + warningId).hide();
}

/**
 * Load the valid values for the drop down for a given field.
 * @param childId the field id to load
 * @param folderPath current tracker folder path
 * @param currentSelectedValue the current selected value
 * @param suppressWarning true to suppress warning for conflicts
 */
function loadValidValues(childId, folderPath, currentSelectedValue, suppressWarning) {
  if (childId == undefined) {
      return;
  }
  var parentId = CTF.fromChildToParent[childId];
  if (parentId == undefined) {
      return;
  }
  // register an error to be invoked when there is an error
  jQuery(document).ajaxError(function(event, request, settings) {
    alert(inconsistencyMessage);
  });

  var parentValueName = $j("select[name='flexFields(" + parentId + ")']").val();
  if (parentValueName == '') {
      // Disable the child field as the parent is undefined
      $j("select[name='flexFields(" + childId + ")']").prop("disabled", true).html('<option value="' + parentValueName + '">' +
              (parentValueName == '' ? _NONE_MESSAGE : _UNCHANGED_FIELD_VALUE) + '</option>').val(parentValueName);
    unbindAndRemoveWarning(childId); // remove any warning messages
      // now load the grandchild assuming child value is undefined
      loadValidValues(CTF.fromParentToChild[childId], folderPath, parentValueName, suppressWarning);
  } else {
    var parentValueId = CTF.allFields[parentId][parentValueName];
    var currentChildValue = $j("select[name='flexFields(" + childId + ")']").val();
    // alert("parentId " + parentId + "\nparentValueName:" + parentValueName + "\nparentValueId:" + parentValueId);
    var handlerURL = "/sf/docman/do/getChildFieldValuesJSON/" + folderPath + "?childid=" + childId;

    // the parent value can be undefined if it's no longer a valid selection
    if (parentValueId != undefined) {
      handlerURL = handlerURL + "&parentfv=" + parentValueId;
    }

    $j.ajax( {
      url : handlerURL,
      dataType : 'json',
      success : function(data) {
        if (data.action === undefined) {
          // We had an issue.
          alert(_INCONSISTENCY_MESSAGE);
        } else if (data.action == "render") {
          // We are good
          $j("select[name='flexFields(" + childId + ")']").removeAttr("disabled").each( function(xx) {
            // Clean-up the current value
            this.innerHTML = "";

            // need to handle inconsistent state where currently selected value isn't a "valid" option
            var foundCurSelectedVal = false;

            // Insert the new values. Note we're using document.createElement to guard against JS injection
            var hasValidOption = false;
            var selectedOption = null;
            var selectedOptionEl = null;
            var firstOptionEl = null;
            var isValidCurrentChild = false;
            
            for(var i = 0; i < data.values.length; ++i) {
                var value = data.values[i];
                if(value["name"] == currentChildValue) {
                    isValidCurrentChild = true;
                }
            }
            if(!isValidCurrentChild) {
            	currentChildValue = "";
            }
            
            for (var i = 0; i < data.values.length; ++i) {
              var value = data.values[i];
              var isSelected = false;
              var optionVal = value["name"];
              if (optionVal == currentSelectedValue) {
                foundCurSelectedVal = true;
              }
              if (optionVal == currentChildValue) {
                  selectedOption = optionVal;
                  isSelected = true;
              }

              var fieldOptionEl = document.createElement("option");
              fieldOptionEl.setAttribute("value", optionVal);
              if (isSelected) {
                fieldOptionEl.setAttribute("selected", "selected");
                selectedOptionEl = fieldOptionEl;
              }
              var fieldOptionValueEl = document.createTextNode(optionVal);
              fieldOptionEl.appendChild(fieldOptionValueEl);
              this.appendChild(fieldOptionEl);
              if (firstOptionEl == null) {
                firstOptionEl = fieldOptionEl;
              }

              registerFieldValue(childId, optionVal, value["id"]);
              hasValidOption = true;
            }

            var hasRenderedNoneValue = false;

            // if the field is not required, then none is considered a valid selection
            if (!data.fieldIsRequired && currentSelectedValue == "") {
              foundCurSelectedVal = true;
            }

            // if current state is inconsistent according to field hierarchy configuration, we display a notification
            if (!foundCurSelectedVal && !suppressWarning && currentSelectedValue != undefined) {
              // being here means we have a value that is not in the "legal" list of options
              var currentSelectedDisplay = (currentSelectedValue == '') ? _NONE_MESSAGE : currentSelectedValue;
              var curFieldOptionEl = document.createElement("option");
              curFieldOptionEl.setAttribute("value", currentSelectedValue);
              curFieldOptionEl.setAttribute("selected", "selected");
              var curFieldOptionValueEl = document.createTextNode(currentSelectedDisplay);
              curFieldOptionEl.appendChild(curFieldOptionValueEl);
              if (firstOptionEl != null) {
                this.insertBefore(curFieldOptionEl, firstOptionEl);
              } else {
                this.appendChild(curFieldOptionEl);
              }
              hasValidOption = true;
              //ie related
              selectedOption = currentSelectedValue;
              selectedOptionEl = curFieldOptionEl;

              var warningId = "invalid_" + childId; // the id of the field "inconsistent" notification div
              var selectEl = jQuery("#fv_id_" + childId).after(generateInvalidStateWarning(warningId, data.fieldParentName));
              // make the warning appear/disappear whenever we select/deselect the invalid value
              selectEl.bind('change.warn_' + childId, function(){
                var thisEl = jQuery(this);
                if (thisEl.val() == currentSelectedValue) {
                  jQuery("#" + warningId).show();
                } else {
                  jQuery("#" + warningId).hide();
                }
              });

              hasRenderedNoneValue = (currentSelectedValue == '');
            } else {
              unbindAndRemoveWarning(childId);
            }

            // insert "none" if "none" isn't already rendered and is either not required or has no other possible values
            if (!hasRenderedNoneValue && (data.fieldIsRequired == false || !hasValidOption)) {
              var noneFieldOptionEl = document.createElement("option");
              noneFieldOptionEl.setAttribute("value", "");
              var noneFieldOptionValueEl = document.createTextNode(_NONE_MESSAGE);
              noneFieldOptionEl.appendChild(noneFieldOptionValueEl);
              if (currentChildValue == "") {
                selectedOption = "";
                selectedOptionEl = noneFieldOptionEl;
              }
              if (firstOptionEl != null) {
                this.insertBefore(noneFieldOptionEl, firstOptionEl);
              } else {
                this.appendChild(noneFieldOptionEl);
              }
            }

            // only set the value if a selection is made (since if the value is not a valid option, browsers like IE7 will create the extra dom)
            // XXX: This is a very odd IE6 hack! Do not touch it unless you really know what you are doing!
            if (selectedOption != null) {
              this.setAttribute("value", selectedOption);
              this.value = selectedOption;
            }
            if (selectedOptionEl != null) {
                selectedOptionEl.setAttribute("selected", "selected");
            }

            // Trigger the update for the child values
            var grandChildId = CTF.fromParentToChild[childId];
            loadValidValues(grandChildId, folderPath, $j("select[name='flexFields(" + grandChildId + ")']").attr('selectedValue'), suppressWarning);
          });
        } else {
          // again, we had an issue.
          alert(_INCONSISTENCY_MESSAGE);
        }
      },
      cache : false,
      async : false
    });
  }

}

/**
 * Initialize parent child field for field hierarchy.
 * @param childId the child field id
 * @param parentId parent field id
 * @param folderPath current folder path
 * @param suppressWarning true to suppress hierarchy inconsistency warning
 */
function initializeParentChild(childId, parentId, folderPath, suppressWarning) {
  checkCTFinitialization();
  CTF.fromParentToChild[parentId] = childId;
  CTF.fromChildToParent[childId] = parentId;
  var childEl = $j("select[name='flexFields(" + childId + ")']");
  loadValidValues(childId, folderPath, childEl.attr('selectedValue'), suppressWarning);
  // bind 'loadValidValues' to change events but under special namespaces so they can be more easily removed
  $j("select[name='flexFields(" + parentId + ")']").bind('change.load_' + childId, function(event) {
      loadValidValues(childId, folderPath, childEl.attr('selectedValue'), true); // warning always suppress for user action
  });
}

