/*
 * CollabNet TeamForge(r)
 * Copyright 2014 CollabNet, Inc.  All rights reserved.
 * http://www.collab.net
 */

/*
 * Set the point field value when autosummingPoints is on  
 */

function pointsChange() {
	$j('#pointsFld').val($j('#points').val());
}

function pointsInputChange() {
	$j('#points').val($j('#pointsFld').val());
}