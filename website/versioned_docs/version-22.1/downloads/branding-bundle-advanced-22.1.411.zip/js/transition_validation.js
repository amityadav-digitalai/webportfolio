/*
 * CollabNet TeamForge(r) Enterprise Edition
 * Copyright 2007-2016 CollabNet, Inc.  All rights reserved.
 * http://www.collab.net
 */
function displayIfTransitionRequiredField(currentStatus, fieldId, statusChanged) {
  currentStatus = this.escapeHtml(currentStatus);
  var reqFieldsForCurrentStatus = statusToFieldsMap[currentStatus];
  var reqFieldMark = document.getElementById('trf_' + fieldId);

  if (reqFieldMark != null) {
    if(reqFieldsForCurrentStatus[fieldId]){ // if it is found int he reqFieldsForCurrentStatus array
      // make it appear - change color instead of making the span disappear to prevent shifting          
      reqFieldMark.style.color = "#cc3300"; // make it appear
      reqFieldMark.style.backgroundColor = "0 none"; // make it appear
      reqFieldCount++;
    } else {
      // make it disappear
      reqFieldMark.style.color = "transparent"; // make it disappear
      reqFieldMark.style.backgroundColor = "0 none"; // make it disappear
    }
  }
  var reqFieldError = document.getElementById('err_' + fieldId);
  if (reqFieldError != null) {
    if (statusChanged != 'true') {
      // make it appear - change color instead of making the span disappear to prevent shifting
      reqFieldError.style.display = "";
    } else { //error message doesn't need to be displayed
      // make it disappear
      reqFieldError.style.display = "none";
    }
  }
}

function escapeHtml(unsafe) {
  return unsafe
           .replace(/"/g, "&#034;")
           .replace(/'/g, "&#039;");
}
